模型×思考强度追加压力测试与异常核查

本轮增加10道新题、3道原题锚题、2道原表达题，覆盖35个可执行请求配置，每格1次。
原35配置包括6luna的5档，其余5个请求模型各6档；gpt-5.6-sol后端身份仍未独立核验。
所有实例fork_turns=none，同一prompt.txt、同一题序、同一输出协议，只允许读题/写答卷。
温度、模型种子、实际思考预算、路由和后端身份不暴露；不能声称所有变量都可控。

主结果：H01—H10每题1分，题内按冻结的结构子项分配；总和/10*100。
H10按8组固定功能用例的组内通过率平均计分，8组各12例；复杂度单独审阅。
A01/A02/A03对应上一轮Q01/Q10/Q07，保持原始整题精确评分，独立报告，不混入新题总分。
旧题包使用整题评分，本轮新题用部分分，且题目数量/内容不同，不能把两轮总分相减解释为能力升降。
置信度Brier以整题全部正确为1，否则0。部分分不直接作为概率目标。

异常解释遵循三层：直接可观察证据；与证据相容但未确认的机制；现有数据不能推出的结论。
不把相同错误当成同一后端证明；不把每格一两次的倒挂当成高强度使模型变笨；不择优丢弃低分。

相对上轮的变化：题包更长、锚题位于10道新题之后，style字段要求更明确。
因此锚题变化存在上下文/题序影响，字段改善也可能由指令强化解释；不能只归因于模型或强度。

极大整数诊断：主轮已冻结并启动6个请求、收到1份但尚未查看正文时，独立审计发现原用例不覆盖
任意大整数。另固定4个10^60量级权重用例，统一用于全部答卷，单独展示，不计入主分。
原因、时间、文件状态和哈希见diagnostic_amendment.json，未改主评分与96个固定用例。

主要文件：
prompt.txt、controller_prompt.txt：相同题包及启动消息
preregistration.json：开跑前冻结的输入、评分器和哈希
run_plan.json：随机启动顺序与请求模型/强度映射
answer_key.json、fixtures.json：标准答案、构造与枚举证据
scoring_rules.json、code_cases.json：主评分规则及96个固定用例
diagnostic_code_cases.json、diagnostic_amendment.json：单列极大权重诊断
raw/sNNN.json：逐次原始提交字节，不包含不可见思维链或服务端轨迹
analysis/prior_anomalies.json：上一轮7项异常的证据与解释层级
analysis/key_audit.json、code_case_audit.json：独立标准答案和用例审计
analysis/runs.csv、items.csv、parts.csv：逐运行、逐题、逐评分子项结果
analysis/anchor_comparison.csv：原两次与新一次的相同内容锚题比较
analysis/observable_error_flags.json：排列违约、费用自相矛盾、可行但次优等可观察错误
analysis/style_metrics.csv：表达原文、长度与字段位置记录
analysis/abstention_probe_results.json：s024触发的4次独立诊断，含3份答卷与1次null拒绝
abstention_probe_protocol.json：事后诊断登记，不以新结果覆盖主成绩
raw/d002.refusal.txt、execution_events.json：模型拒绝的原文及来源，未伪造答案JSON
analysis/posthoc_huge_integer_audit.json：统一10^1000死端反例的事后审计，不进主分
analysis/h10_static_final_audit.json、final_audit.json：逐运行代码审阅与最终复算审计
analysis/fraction_equivalence_audit.json：精确有理数等价的单列敏感性分析，原主分不变
analysis/code_test_details.json、diagnostic_code_results.json：全部代码用例结果
delivery/report.html、report.txt：可阅读报告及原始答卷浏览
delivery/results.csv：完整配置矩阵
delivery/model_comparison_updated.zip：上一轮和补测全部数据、报告及脚本

复算：保留model-comparison和model-comparison-stress两个目录为同级。
依次运行python scripts/score.py、python scripts/diagnostics.py、python scripts/aggregate.py。
无需联网，评分脚本只需Python标准库。不要覆盖冻结输入重跑prepare系列脚本。
重新生成报告图需要matplotlib、numpy；参考答案生成另用sympy。原模型输出不能离线重生成。

占位诊断共4次尝试：完整题包2次均有答卷，短包1份答卷、1次拒绝。拒绝记null，不当0分，
不删去，也不补抽到得到好答案为止。s024主成绩原样保留；完整/短包只比较相同三题的子项分。
全部诊断为事后探索，不能凭n=2和缺失答卷确定题包长度的因果作用。

代码审阅进一步发现float(inf)+超大整数的潜在溢出后，对全部35份代码统一运行同一
10^1000死端反例：27通过、7抛OverflowError、s024恒定函数错误。此项是事后审计，
不改变96个固定主用例、原4个10^60诊断或分数；“通过现有用例”不等于满足全部输入规格。

分数表示复核：s035把61/11写成等价但未约分的427/77，按已冻结“最简分数字符串”规则失分。
在单列有理数等价敏感性分析中，该答卷为100而主分仍95；其他答卷没有等价表示导致的分差。
