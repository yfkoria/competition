import collections
import datetime
import functools
import hashlib
import heapq
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MOD = 1000000007


def independent(c):
    n, edges, s, t = c['n'], c['edges'], c['s'], c['t']
    graph = [[] for _ in range(n)]
    for u, v, w in edges:
        graph[u].append((v, w))
    distance = [float('inf')] * n
    distance[s] = 0
    queue = [(0, s)]
    while queue:
        du, u = heapq.heappop(queue)
        if du != distance[u]:
            continue
        for v, w in graph[u]:
            nd = du + w
            if nd < distance[v]:
                distance[v] = nd
                heapq.heappush(queue, (nd, v))
    if distance[t] == float('inf'):
        return [None, 0], {'shortest_relevant_nodes': [], 'exact_finite_count': 0}
    tight = [[] for _ in range(n)]
    reverse = [[] for _ in range(n)]
    for u, v, w in edges:
        if distance[u] != float('inf') and distance[u] + w == distance[v]:
            tight[u].append(v)
            reverse[v].append(u)
    relevant, stack = {t}, [t]
    while stack:
        v = stack.pop()
        for u in reverse[v]:
            if u not in relevant:
                relevant.add(u)
                stack.append(u)
    color = {}

    def cycle(u):
        color[u] = 1
        for v in tight[u]:
            if v not in relevant:
                continue
            if color.get(v) == 1:
                return True
            if color.get(v, 0) == 0 and cycle(v):
                return True
        color[u] = 2
        return False

    if cycle(s):
        return [distance[t], 'INF'], {'shortest_relevant_nodes': sorted(relevant), 'relevant_tight_cycle': True}

    @functools.lru_cache(None)
    def count(u):
        return int(u == t) + sum(count(v) for v in tight[u] if v in relevant)

    exact = count(s)
    return [distance[t], exact % MOD], {'shortest_relevant_nodes': sorted(relevant), 'relevant_tight_cycle': False, 'exact_finite_count': exact, 'modulo_wrap_exercised': exact >= MOD}


cases = json.loads((ROOT / 'code_cases.json').read_text())
rows, mismatches = [], []
groups = collections.defaultdict(list)
for index, case in enumerate(cases):
    result, info = independent(case)
    counts = collections.Counter(tuple(edge) for edge in case['edges'])
    row = {'case_index': index, 'group': case['group'], 'expected': case['expected'], 'independent_result': result, 'match': result == case['expected'], 'n': case['n'], 'm': len(case['edges']), 'source_equals_target': case['s'] == case['t'], 'has_zero_weight_edge': any(w == 0 for u, v, w in case['edges']), 'has_zero_weight_self_loop': any(u == v and w == 0 for u, v, w in case['edges']), 'has_identical_parallel_edges': any(v > 1 for v in counts.values()), **info}
    rows.append(row)
    groups[case['group']].append(row)
    if not row['match']:
        mismatches.append({'case_index': index, 'expected': case['expected'], 'independent_result': result})
coverage = {}
for group, group_rows in groups.items():
    coverage[group] = {'cases': len(group_rows), 'unreachable': sum(r['independent_result'][0] is None for r in group_rows), 'finite_reachable': sum(r['independent_result'][0] is not None and type(r['independent_result'][1]) is int for r in group_rows), 'infinite': sum(r['independent_result'][1] == 'INF' for r in group_rows), 'source_equals_target': sum(r['source_equals_target'] for r in group_rows), 'identical_parallel_edge_cases': sum(r['has_identical_parallel_edges'] for r in group_rows), 'modulo_wrap_cases': sum(r.get('modulo_wrap_exercised', False) for r in group_rows), 'zero_self_loop_cases': sum(r['has_zero_weight_self_loop'] for r in group_rows)}
report = {
    'audit_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'pass' if not mismatches else 'fail',
    'inputs_modified': False,
    'reference_script_modified': False,
    'case_count': len(cases),
    'group_count': len(groups),
    'independent_method': 'Dijkstra from s; source-distance-tight edge multigraph; reverse reachability from t; DFS color cycle detection; exact integer memoized DAG walk count then modulo. No Floyd-Warshall or Kahn algorithm used.',
    'expected_matches': sum(r['match'] for r in rows),
    'mismatches': mismatches,
    'group_coverage': coverage,
    'semantic_checks': {
        'unreachable_returns_None_0': coverage['unreachable']['unreachable'] == 12,
        's_equals_t_finite_and_infinite': coverage['source_equals_target']['finite_reachable'] > 0 and coverage['source_equals_target']['infinite'] > 0,
        'zero_weight_dag_finite_counts': coverage['zero_weight_dag']['finite_reachable'] == 12,
        'relevant_zero_cycles_infinite': coverage['relevant_zero_cycle']['infinite'] == 12,
        'irrelevant_zero_cycles_finite': coverage['irrelevant_zero_cycle']['finite_reachable'] == 12,
        'parallel_edge_multiplicity_exercised': coverage['parallel_edges']['identical_parallel_edge_cases'] == 12,
        'modulo_actual_wrap': coverage['modulo_large_count']['modulo_wrap_cases'] > 0,
        'singleton_empty_walk': any(c['n'] == 1 and not c['edges'] and c['expected'] == [0, 1] for c in cases),
        'singleton_zero_loop_infinite': any(c['n'] == 1 and c['edges'] == [[0, 0, 0]] and c['expected'] == [0, 'INF'] for c in cases),
        'singleton_positive_loop_finite': any(c['n'] == 1 and c['edges'] == [[0, 0, 1]] and c['expected'] == [0, 1] for c in cases),
        'empty_graph_unreachable': any(c['s'] != c['t'] and not c['edges'] and c['expected'] == [None, 0] for c in cases),
        'large_integer_weight_case': any(any(w >= 10**12 for _, _, w in c['edges']) for c in cases),
        'explicit_zero_dag_order_counterexample': cases[36]['edges'] == [[0, 1, 0], [0, 2, 0], [2, 1, 0], [1, 3, 1], [2, 3, 1]] and cases[36]['expected'] == [1, 3]
    },
    'reference_algorithm_review': {
        'correct_for_final_fixed_inputs': True,
        'reason': 'Nonnegative Floyd-Warshall distances identify edges with ds[u]+w+dt[v]=D. Such edges are on shortest s-to-t walks. Every relevant directed cycle has zero total weight and can be repeated indefinitely. Kahn detects these cycles; preserving repeated adjacency entries correctly counts distinct parallel edges in the finite case.',
        'sentinel_limit': 'The 10**50 sentinel is safe for all final frozen cases, including 10**12 edge weights. It is not a universal reference for arbitrarily large legal integers without a weight bound; candidate static review should not infer general correctness solely from these tests.',
        'complexity_note': 'The reference O(n^3) generator is used only for tiny fixed expected values; it is not an H10 candidate satisfying the required runtime.'
    },
    'coverage_limits': ['Finite functional cases do not prove asymptotic complexity.', 'The final suite covers n=1, empty edges, relevant/irrelevant zero cycles, finite zero DAGs, s=t, parallel edge multiplicity and actual modular wrap. It does not exhaust all legal graphs.', 'Largest tested edge weight is 3*10**12; finite sentinels above the tested shortest distances remain unchallenged by functional cases.'],
    'sources_hashed': {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in ['code_cases.json', 'scripts/prepare_code_cases.py', 'prompt.txt']},
    'cases': rows
}
(ROOT / 'analysis/code_case_audit.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'expected_matches': report['expected_matches'], 'semantic_checks': report['semantic_checks'], 'group_coverage': coverage, 'code_cases_sha256': report['sources_hashed']['code_cases.json']}, ensure_ascii=False, indent=2))
