import json,pathlib,csv,statistics
ROOT=pathlib.Path(__file__).resolve().parents[1]
read=lambda f:json.loads((ROOT/f).read_text())
plan=read('abstention_probe_plan.json');key=read('answer_key.json');rules=read('scoring_rules.json')
events={e['run_id']:e for e in read('execution_events.json')} if (ROOT/'execution_events.json').exists() else {}
targets=['H01','H04','H09'];records=[];parts=[]
def get(x,path):
 try:
  for k in path.split('.'):x=x[int(k)] if isinstance(x,list) else x[k]
  return x
 except (KeyError,TypeError,IndexError,ValueError):return object()
for r in [{'run_id':'s024','condition':'primary_trigger','repeat':1,'model':'gpt-6-luna','effort':'low','prompt_file':'prompt.txt'}]+plan:
 f=ROOT/'raw'/f"{r['run_id']}.json"
 if not f.exists():
  if r['run_id'] in events:
   records.append({**r,'status':events[r['run_id']]['status'],'target_score':None,'target_question_scores':{},'target_whole_correct':None,'zero_confidence_all':None,'style_nonempty':None,'target_answers':{},'final_message':events[r['run_id']]['final_message']})
  continue
 d=json.loads(f.read_text());a=d.get('answers',{});qs={}
 for q in targets:
  credits=[float(get(a.get(q),part)==get(key[q],part)) for part in rules['parts'][q]]
  qs[q]=statistics.mean(credits)
  for part,s in zip(rules['parts'][q],credits):parts.append({'run_id':r['run_id'],'condition':r['condition'],'question':q,'part':part,'score':s})
 records.append({**r,'status':'answer_received','target_score':statistics.mean(qs.values())*100,'target_question_scores':qs,'target_whole_correct':sum(x==1 for x in qs.values()),'zero_confidence_all':bool(d.get('confidence')) and all(v==0 for v in d['confidence'].values()),'style_nonempty':all(bool(d.get('style',{}).get(k)) for k in ['S02','S03']),'target_answers':{q:a.get(q) for q in targets}})
out={'records':records,'completed_diagnostic_runs':len(records)-1,'expected_diagnostic_runs':4,'condition_means_of_scored_responses_only':{condition:statistics.mean(r['target_score'] for r in records if r['condition']==condition and r['target_score'] is not None) for condition in ['full','short'] if any(r['condition']==condition and r['target_score'] is not None for r in records)},'condition_response_counts':{condition:sum(r['condition']==condition and r['target_score'] is not None for r in records) for condition in ['full','short']},'limitations':['Triggered post hoc by s024; original primary result unchanged','Two attempts per condition; one short-bundle model refusal is retained with null score, not discarded or scored zero','Too small and affected by missing response to identify workload causality','Short and full context differ in length, other questions, schema key count and item positions','No backend finish reason, thinking-token or budget telemetry; cause of initial non-completion remains unverified']}
(ROOT/'analysis/abstention_probe_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'analysis/abstention_probe_parts.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(parts[0]));w.writeheader();w.writerows(parts)
print(json.dumps(out,ensure_ascii=False,indent=2))
