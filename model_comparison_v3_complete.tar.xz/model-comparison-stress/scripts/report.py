"""Build a standalone report from the latest scored stress-round snapshot.

This script only writes delivery artifacts. It never changes inputs, raw answers,
scores, or narrative conclusions. Run score.py and aggregate.py before rerunning.
"""
from __future__ import annotations

import base64
import collections
import csv
import datetime
import hashlib
import html
import json
import os
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "delivery"
OUT.mkdir(exist_ok=True)
os.environ.setdefault("MPLCONFIGDIR", "/tmp/model-comparison-stress-mpl")
os.environ.setdefault("XDG_CACHE_HOME", "/tmp/model-comparison-stress-cache")

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

MODELS = ["gpt-6-astra", "gpt-6.1-sol", "gpt-6-sol", "gpt-6.1-terra", "gpt-6-luna", "gpt-5.6-sol"]
EFFORTS = ["low", "medium", "high", "xhigh", "max", "ultra"]
LABELS = dict(zip(MODELS, ["6Astra", "6.1sol", "6sol", "6.1terra", "6luna", "5.6sol*"]))
QUESTION_NAMES = {
    "H01": "八字符约束排列", "H02": "混合袋条件概率", "H03": "重叠模式与等待时间",
    "H04": "局部因果效应与总体界", "H05": "最小反模型与传递性", "H06": "极小极大混合策略",
    "H07": "SQL空值与窗口排序", "H08": "事务冲突与最小删除", "H09": "约束覆盖与三级择优",
    "H10": "最短游走与相关零环", "A01": "原Q01：约束排列", "A02": "原Q10：最小覆盖",
    "A03": "原Q07：观察与因果",
}
FLAG_LABELS = {
    "incorrect_count": "计数错误", "invalid_first_order": "候选排列违反约束",
    "cost_does_not_match_chosen_sets": "费用与所选集合不一致", "infeasible_cover": "覆盖或附加约束未满足",
    "optimal_cost_but_tiebreak_wrong": "费用正确但并列择优错误",
    "LATE_correct_but_ATE_bounds_wrong": "LATE正确、ATE界错误",
}


def read_json(name, default=None):
    path = ROOT / name
    return json.loads(path.read_text(encoding="utf-8")) if path.exists() else default


def read_csv(name):
    path = ROOT / name
    if not path.exists():
        return []
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def esc(value):
    return html.escape(str(value))


def num(value, digits=1):
    if value is None or value == "":
        return "—"
    return f"{float(value):.{digits}f}"


def truth(value):
    return value is True or str(value).lower() == "true"


def table(headers, rows, table_id=None):
    ident = f' id="{esc(table_id)}"' if table_id else ""
    header = "".join(f"<th>{esc(h)}</th>" for h in headers)
    body = "".join("<tr>" + "".join(f"<td>{v}</td>" for v in row) + "</tr>" for row in rows)
    return f'<div class="table-wrap"><table{ident}><thead><tr>{header}</tr></thead><tbody>{body}</tbody></table></div>'


def paragraphs(values):
    return "".join(f"<p>{esc(value)}</p>" for value in values)


def bullets(values):
    return "<ul>" + "".join(f"<li>{esc(value)}</li>" for value in values) + "</ul>" if values else ""


def pretty(value):
    return esc(json.dumps(value, ensure_ascii=False, indent=2))


def main():
    aggregate = read_json("analysis/aggregate.json", {})
    summary = read_json("analysis/summary.json", {})
    plan = read_json("run_plan.json", [])
    prereg = read_json("preregistration.json", {})
    rules = read_json("scoring_rules.json", {})
    amendment = read_json("diagnostic_amendment.json", {})
    prior = read_json("analysis/prior_anomalies.json", {})
    flags = read_json("analysis/observable_error_flags.json", [])
    diagnostics = read_json("analysis/diagnostic_code_results.json", {})
    abstention_protocol = read_json("abstention_probe_protocol.json", {})
    abstention_plan = read_json("abstention_probe_plan.json", [])
    abstention_results = read_json("analysis/abstention_probe_results.json", {})
    execution_events = read_json("execution_events.json", [])
    abstention_trigger = abstention_protocol.get("trigger_run")
    main_code_details = read_json("analysis/code_test_details.json", {}) if abstention_trigger else {}
    items = read_csv("analysis/items.csv")
    parts = read_csv("analysis/parts.csv")
    styles = read_csv("analysis/style_metrics.csv")
    anchors = read_csv("analysis/anchor_comparison.csv")
    records = summary.get("records", [])
    completed = len(records)
    expected = summary.get("expected", prereg.get("formal_runs", len(plan)))
    if aggregate.get("completed", completed) != completed:
        raise RuntimeError("Scored and aggregated snapshots differ; rerun aggregate.py before report.py.")
    cells = aggregate.get("cells", [])
    lookup = {(c["model"], c["effort"]): c for c in cells}
    planned = {(r["model"], r["effort"]): r for r in plan}
    for model in MODELS:
        for effort in EFFORTS:
            lookup.setdefault((model, effort), {"model": model, "effort": effort, "available": (model, effort) in planned,
                "new_10q_partial_score": None, "new_10q_whole_correct": None, "new_3anchor_correct_out_of_3": None,
                "old_3anchor_correct_out_of_6": None, "run_id": None})
    cells = [lookup[m, e] for m in MODELS for e in EFFORTS]
    record_by_id = {r["run_id"]: r for r in records}
    raw = []
    for run in records:
        path = ROOT / "raw" / f"{run['run_id']}.json"
        blob = path.read_bytes()
        digest = hashlib.sha256(blob).hexdigest()
        if run.get("raw_sha256") and digest != run["raw_sha256"]:
            raise RuntimeError(f"Scored raw hash mismatch: {run['run_id']}")
        raw.append({"run_id": run["run_id"], "model": run["model"], "effort": run["effort"],
                    "repeat": run.get("repeat", 1), "sha256": digest,
                    "new_score": run["new_score"], "new_complete_correct": run["new_complete_correct"],
                    "anchor_correct": run["anchor_correct"], "response": json.loads(blob)})
    (OUT / "all_raw.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in raw), encoding="utf-8")

    # Fixed 0–100 scale; unavailable and pending cells are both missing observations,
    # but their text labels are distinct. The bottom rectangle reserves footnote space.
    values = np.array([[lookup[m, e].get("new_10q_partial_score")
                        if lookup[m, e].get("new_10q_partial_score") is not None else np.nan
                        for e in EFFORTS] for m in MODELS], dtype=float)
    fig, ax = plt.subplots(figsize=(11, 6.7), layout="constrained")
    fig.set_layout_engine("constrained", rect=(0, .14, 1, .86))
    cmap = plt.get_cmap("Blues").copy()
    cmap.set_bad("#edf1f6")
    im = ax.imshow(values, cmap=cmap, vmin=0, vmax=100)
    ax.set_xticks(range(6), EFFORTS)
    ax.set_yticks(range(6), [LABELS[m] for m in MODELS])
    ax.set_title(f"Stress battery: partial-credit score (0–100), {completed}/{expected} runs", pad=16, fontsize=14)
    for i, model in enumerate(MODELS):
        for j, effort in enumerate(EFFORTS):
            cell = lookup[model, effort]
            value = values[i, j]
            label = "N/A" if not cell["available"] else "Pending" if np.isnan(value) else f"{value:.1f}"
            if cell.get("run_id") == abstention_trigger and abstention_trigger:
                label += "†"
            ax.text(j, i, label, ha="center", va="center", color="white" if not np.isnan(value) and value >= 65 else "#172338", fontsize=11)
    fig.colorbar(im, ax=ax, shrink=.82)
    fig.text(.02, .080, "One run per configuration. Different questions and scoring from the original battery; do not subtract totals.", fontsize=8)
    fig.text(.02, .050, "* Requested gpt-5.6-sol accepted; resolved backend identity unverified. Luna ultra explicitly unsupported.", fontsize=8)
    if abstention_trigger in record_by_id:
        fig.text(.02, .020, f"† {abstention_trigger}: objective placeholders with zero confidence; retained protocol score, not a normal ability sample.", fontsize=8)
    fig.savefig(OUT / "stress_scores.png", dpi=170)
    fig.savefig(OUT / "stress_scores.svg")
    plt.close(fig)
    plot_base64 = base64.b64encode((OUT / "stress_scores.png").read_bytes()).decode("ascii")

    narrative = read_json("analysis/narrative.json", None)
    if narrative is None:
        narrative = {"findings": ["结果叙述尚未定稿。下方数字来自当前已评分的样本；全部配置完成前，不据此建立模型排序。"],
                     "anomalies": [], "style_findings": ["语言部分的最终解释待全部样本与字段核验完成后补充。"]}
    findings_html = paragraphs(narrative.get("findings", []))
    style_html = paragraphs(narrative.get("style_findings", []))
    anomaly_html = ""
    for anomaly in narrative.get("anomalies", []):
        anomaly_html += f'<article class="panel anomaly"><h3>{esc(anomaly.get("title", "异常分析"))}</h3>'
        for key, label in [("evidence", "可观察证据"), ("interpretation", "解释"), ("limits", "尚不能确定")]:
            if anomaly.get(key):
                anomaly_html += f'<p><span class="tag">{label}</span> {esc(anomaly[key])}</p>'
        anomaly_html += "</article>"
    if not anomaly_html:
        anomaly_html = '<p class="muted">跨轮异常解释尚未定稿。上一轮的独立证据登记保留在下方折叠区。</p>'

    initial_matrix = []
    for model in MODELS:
        row = [esc(LABELS[model])]
        for effort in EFFORTS:
            cell = lookup[model, effort]
            value = cell.get("new_10q_partial_score")
            marker = "†" if cell.get("run_id") == abstention_trigger and abstention_trigger else ""
            row.append("不支持" if not cell["available"] else "待完成" if value is None else
                       f'<strong>{num(value)}{marker}</strong><small>{esc(cell["run_id"])}</small>')
        initial_matrix.append(row)
    matrix_html = table(["请求模型"] + EFFORTS, initial_matrix, "scoreMatrix")

    model_summary = {r["model"]: r for r in aggregate.get("models_common_low_through_max", [])}
    model_rows = []
    for model in MODELS:
        row = model_summary.get(model, {})
        n = row.get("common_effort_runs", 0)
        model_rows.append([esc(LABELS[model]), f"{n}/5", num(row.get("new_mean"), 2),
                           num(row.get("new_whole_correct_mean_100"), 2),
                           f'{row.get("new_perfect_runs", 0)}/{n}' if n else "—",
                           num(row.get("new_brier"), 4), str(row.get("new_high_confidence_incomplete", "—"))])

    question_rows = [[esc(q["question"] + " · " + QUESTION_NAMES.get(q["question"], "")), str(q["n"]),
                      num(100 * q["mean_credit"]), f'{q["full_correct"]}/{q["n"]}',
                      str(q["high_confidence_incomplete"]), esc(", ".join(q["failed_runs"]) or "—")]
                     for q in aggregate.get("questions", [])]
    part_groups = collections.defaultdict(list)
    for row in parts:
        part_groups[row["question"], row["part"]].append(float(row["score"]))
    part_rows = [[esc(q), esc(part), len(scores), num(statistics.mean(scores) * 100)]
                 for (q, part), scores in sorted(part_groups.items())]

    flag_counts = collections.Counter(row.get("kind", "unknown") for row in flags)
    flags_summary = table(["可观察错误类型", "标记数"], [[esc(FLAG_LABELS.get(k, k)), v] for k, v in flag_counts.most_common()])
    flag_rows = [[esc(r["run_id"]), esc(LABELS.get(r["model"], r["model"])), esc(r["effort"]), esc(r["question"]),
                  esc(FLAG_LABELS.get(r["kind"], r["kind"])), f'<code>{esc(r.get("observable_evidence", ""))}</code>'] for r in flags]

    prior_blocks = ""
    for anomaly in prior.get("anomalies", []):
        prior_blocks += f'<details><summary>{esc(anomaly.get("title", anomaly.get("id", "上一轮异常")))}</summary>'
        prior_blocks += '<h4>原始证据及独立复算</h4><pre>' + pretty(anomaly.get("observed", {})) + "</pre>"
        prior_blocks += '<h4>证据支持的解释</h4>' + paragraphs([anomaly.get("supported_interpretation", "")])
        prior_blocks += '<h4>与证据相容，但尚未识别的原因</h4>' + bullets(anomaly.get("compatible_hypotheses", []))
        prior_blocks += '<h4>当前不能作出的结论</h4>' + bullets(anomaly.get("not_established", [])) + "</details>"

    anchor_rows = []
    for q, stats in aggregate.get("anchor_stats", {}).items():
        n = stats["pairs"]
        anchor_rows.append([esc(q + " · " + QUESTION_NAMES.get(q, "")), n,
                            f'{stats["old_correct_out_of_2n"]}/{2*n}', f'{stats["new_correct_out_of_n"]}/{n}',
                            stats["wrong_and_exactly_repeated_old_error"]])
    anchor_detail_rows = [[esc(r["run_id"]), esc(LABELS.get(r["model"], r["model"])), esc(r["effort"]), esc(r["question"]),
                           "✓" if truth(r["old_r1_correct"]) else "×", "✓" if truth(r["old_r2_correct"]) else "×",
                           "✓" if truth(r["new_correct"]) else "×",
                           f'<code>{esc(r["new_answer"])}</code>'] for r in anchors]

    style_rows = []
    for model in MODELS:
        selected = [r for r in styles if r["model"] == model and r["effort"] != "ultra"]
        row = [esc(LABELS[model])]
        for sid in ["S02", "S03"]:
            texts = [r for r in selected if r["style_id"] == sid]
            row += [str(len(texts)), num(statistics.mean(int(r["nonspace_chars"]) for r in texts)) if texts else "—",
                    f'{sum(truth(r["length_compliant"]) for r in texts)}/{len(texts)}' if texts else "—"]
        style_rows.append(row)
    style_issues = {"长度不合要求": aggregate.get("style_length_failures", []), "正文出现于错误字段": aggregate.get("style_wrong_field_runs", [])}

    extreme_rows = []
    for rid, detail in diagnostics.items():
        run = record_by_id.get(rid)
        if run is None:
            continue
        outcomes = detail.get("outcomes", [])
        extreme_rows.append([esc(rid), esc(LABELS.get(run["model"], run["model"])), esc(run["effort"]),
                             f'{sum(truth(x.get("passed")) for x in outcomes)}/{len(outcomes)}',
                             esc(detail.get("error", "")) or "—"])
    submissions_at_diagnostic = amendment.get("submissions_present_at_definition", [])
    diagnostic_note = (f'追加登记时间：{amendment.get("created_utc", "未记录")}。当时已启动'
                       f'{amendment.get("formal_runs_started", "—")}次正式请求，已有'
                       f'{len(submissions_at_diagnostic)}份提交文件'
                       + (f'（{", ".join(submissions_at_diagnostic)}）' if submissions_at_diagnostic else "")
                       + '；登记记录称主代理尚未查看提交答案。四个极大整数权重用例统一检查所有提交，单独报告，不进入冻结主分。')

    criteria_rows = [[q, esc("、".join(values))] for q, values in rules.get("parts", {}).items()]
    probe_records = abstention_results.get("records", [])
    probe_by_id = {r["run_id"]: r for r in probe_records}
    probe_events = {r["run_id"]: r for r in execution_events if r.get("run_id")}
    probe_rows = []
    refusal_blocks = []
    for probe in abstention_plan:
        measured = probe_by_id.get(probe["run_id"])
        status = measured.get("status", "answer_received") if measured else "pending"
        refused = status == "model_refusal_no_answer_file"
        status_label = "拒绝答题（无JSON）" if refused else "已提交答卷" if status == "answer_received" else "待完成" if status == "pending" else status
        target_label = "拒绝答题／无可比成绩" if refused else num(measured.get("target_score"), 2) if measured and measured.get("target_score") is not None else "待完成" if not measured else "无可比成绩"
        def probe_bool(field):
            if not measured:
                return "待完成"
            if measured.get(field) is None:
                return "无答卷" if refused else "未记录"
            return "是" if truth(measured[field]) else "否"
        probe_rows.append([esc(probe["run_id"]), "完整题包" if probe["condition"] == "full" else "三题短包",
                           esc(status_label), target_label, probe_bool("zero_confidence_all"), probe_bool("style_nonempty")])
        if refused:
            event = probe_events.get(probe["run_id"], {})
            message = event.get("final_message", measured.get("final_message", ""))
            refusal_blocks.append((probe["run_id"], message))
    probe_raw = []
    for probe in abstention_plan:
        path = ROOT / "raw" / f"{probe['run_id']}.json"
        if path.exists():
            blob = path.read_bytes()
            probe_raw.append({**probe, "record_type": "model_submitted_answer", "sha256": hashlib.sha256(blob).hexdigest(), "response": json.loads(blob)})
        elif probe_by_id.get(probe["run_id"], {}).get("status") == "model_refusal_no_answer_file":
            event = probe_events.get(probe["run_id"], {})
            refusal_path = ROOT / "raw" / f"{probe['run_id']}.refusal.txt"
            refusal_blob = refusal_path.read_bytes() if refusal_path.exists() else None
            entry = {**probe, "record_type": "observed_refusal", "status": "model_refusal_no_answer_file",
                     "target_score": None, "source": event.get("source", "Observed final message recorded by lead; not a model-submitted answer JSON"),
                     "observed_final_message": event.get("final_message", probe_by_id[probe["run_id"]].get("final_message", "")),
                     "answer_file_exists": False, "execution_event": event}
            if refusal_blob is not None:
                entry.update(refusal_file=str(refusal_path.relative_to(ROOT)),
                             refusal_file_sha256=hashlib.sha256(refusal_blob).hexdigest(),
                             refusal_file_text=refusal_blob.decode("utf-8"))
            probe_raw.append(entry)
    if abstention_plan:
        (OUT / "abstention_probes_raw.jsonl").write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in probe_raw), encoding="utf-8")
    probe_limits = abstention_results.get("limitations", abstention_protocol.get("limits", []))
    probe_html = ""
    placeholder_note = ""
    if abstention_protocol:
        trigger_record = record_by_id.get(abstention_trigger, {})
        trigger_outcomes = main_code_details.get(abstention_trigger, {}).get("outcomes", [])
        passed = sum(truth(r.get("passed")) for r in trigger_outcomes)
        placeholder_note = (f'{abstention_trigger}（6luna low）的客观字段为零/空占位、13项置信度全0，代码恒定返回[None,0]，但中文表达仍有正文。'
                            f'其冻结主分为{num(trigger_record.get("new_score"), 2)}，来自恒定代码碰巧通过{passed}/{len(trigger_outcomes)}个主用例。'
                            '该分原样保留，但不能直接当作正常作答时的能力估计。')
        probe_html = '<h3 id="placeholder-probe">占位答卷的独立事后诊断</h3><div class="note">' + esc(placeholder_note) + '</div>'
        probe_html += paragraphs([f'诊断登记于{abstention_protocol.get("created_utc", "未记录")}，触发后才制定：同一6luna low请求做两次全题包、两次短题包，均为全新上下文并随机顺序。短包只保留H01/H04/H09及相同表达任务。只比较这三题按原冻结子项规则所得的0—100分，不把全题包额外题目混入对照。'])
        probe_html += table(["诊断运行", "条件", "状态", "匹配三题分/100", "所交置信度全0", "表达字段非空"], probe_rows)
        for rid, refusal_message in refusal_blocks:
            probe_html += '<div class="panel"><h4>'+esc(rid)+'的原始拒绝消息</h4><p class="rawtext">'+esc(refusal_message)+'</p><p class="small-note">来自主代理记录的子智能体最终消息，不是提交的答案JSON。这里显示的是子智能体给出的拒绝理由，不证明环境实际禁止读题。该次保留为空成绩，不按零分计入，也不从尝试记录中删去。</p></div>'
        probe_html += paragraphs(['诊断提交独立保存；不替换'+str(abstention_trigger)+'、不进入35格主结果、不择优重跑。短包同时改变题目数量、上下文和位置；每组仅两次，不能确认题包负荷、服务器截断、预算耗尽或路由是原因。'])
        if refusal_blocks:
            probe_html += paragraphs(['短包存在拒绝答题造成的缺失。这里逐次展示结果，不据少量有效答卷的平均数认定短包更好或更差。'])
        if probe_limits:
            probe_html += '<details><summary>诊断登记的具体限制</summary>' + bullets(probe_limits) + '</details>'
    generated = datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")
    prereg_time = prereg.get("created_utc", "未记录")
    is_complete = completed == expected
    progress_note = "全部计划配置已形成评分记录。" if is_complete else f"这是中间快照：已评分{completed}/{expected}次。未完成格不能记为零分，模型均值的档位组成尚未齐全。"
    payload = json.dumps({"raw": raw, "cells": cells, "items": items, "parts": parts, "labels": LABELS,
                          "abstention_trigger": abstention_trigger,
                          "models": MODELS, "efforts": EFFORTS}, ensure_ascii=False).replace("<", "\\u003c")
    total_high_conf = sum(int(q.get("high_confidence_incomplete", 0)) for q in aggregate.get("questions", []) if q["question"].startswith("H"))
    total_whole = sum(int(r["new_complete_correct"]) for r in records)
    method_paragraphs = [
        f"新轮在{prereg_time}冻结题包、答案、评分规则、主代码用例和随机启动顺序。35个可执行请求配置各一次，fork_turns=none；题目、顺序、语言、JSON协议和工具限制在本轮内相同。仅允许读取题包及提交答案，不允许用工具解题或互相联系；此限制通过提示实施，未获得逐调用轨迹作独立审计。",
        "新题H01—H10各占1分，合计除以10再乘100；H01—H09按预先登记的结构子项等权给分。H07必须恰有三行，否则该题为0分。H10按八类固定功能用例的通过比例等权平均，每类12例；输入被修改则该例失败。函数测试本身不证明复杂度，复杂度审阅应另列。",
        "整题正确数按10道新题是否全部子项正确统计，范围0—10。A01/A02/A03为原Q01/Q10/Q07，保持旧轮的整题精确匹配，单列0—3题正确，不混入新题总分。Brier的正确性目标也是整题正确，不是部分得分；高置信不完整指置信度≥90但整题未完全正确。",
        "两轮题型、难度、题包长度与计分颗粒度不同，不能把新轮主分减去旧轮总分解释成能力升降。锚题文字未变，但现在排在十道难题之后，所处上下文和题序已改变；每格新增一次也不能识别波动的因果机制。",
        "本轮S02/S03保留原表达任务，但JSON字段提醒更明确：要求实际正文仅放style字段。字段错误减少不能单独归因于模型改善。长度按去除空白后的Unicode字符数计算，包含标点；S02要求60—140，S03要求80—160。表达不计客观分。",
        "模型名与强度均指请求参数。温度、模型随机种子、实际思考token、输出预算、路由与后端版本未暴露；同名强度不表示跨模型消耗相同资源。5.6sol请求路径可执行，而故意无效的模型名被接口拒绝，这只能排除任意名称一律接受，不能排除5.6是特定别名或回退。6luna ultra仍为明确不支持。",
        "每格只有一个新样本，题型数量有限且共同使用同一题包。较难题仍可能存在上限效应，也可能出现普遍失败的下限效应；不能据细小分差给出通用智能等级、显著性结论、价格效率或纯推理速度排名。"
    ]

    css = """
    :root{--ink:#172338;--muted:#5c6d83;--line:#d9e2ee;--accent:#16588c;--paper:#fff;--back:#f3f6fa;--warn:#fff7e5}
    *{box-sizing:border-box}body{margin:0;background:var(--back);color:var(--ink);font:16px/1.75 system-ui,-apple-system,'Noto Sans CJK SC','Microsoft YaHei',sans-serif}
    main{max-width:1190px;padding:38px 28px 80px;margin:auto}h1{font-size:34px;line-height:1.3;margin:12px 0 20px}h2{font-size:25px;margin-top:42px}h3{font-size:19px;margin:22px 0 10px}h4{font-size:15px;margin:20px 0 8px}
    p{max-width:96ch}a{color:var(--accent)}small,.muted{color:var(--muted)}small{display:block;font-size:12px}.eyebrow{letter-spacing:.1em;text-transform:uppercase;font-size:12px;color:var(--accent)}
    .panel{padding:20px 24px;margin:18px 0;background:var(--paper);border:1px solid var(--line);border-radius:13px}.panel h2:first-child,.panel h3:first-child{margin-top:0}.note{border-left:4px solid #b88120;padding:12px 18px;background:var(--warn);margin:18px 0}.note.blue{border-color:#3b7fab;background:#eaf3fb}
    nav{display:flex;gap:10px 20px;flex-wrap:wrap;margin:20px 0}nav a{text-decoration:none}.stats{display:grid;grid-template-columns:repeat(4,minmax(130px,1fr));gap:12px}.stat{background:white;border:1px solid var(--line);border-radius:12px;padding:15px}.stat b{display:block;font-size:27px;line-height:1.3}.stat span{font-size:13px;color:var(--muted)}
    .table-wrap{max-width:100%;overflow:auto;margin:16px 0}table{width:100%;border-collapse:collapse;background:white;font-size:14px}th,td{padding:10px 12px;border:1px solid var(--line);text-align:left;vertical-align:top}th{background:#e9f0f8;white-space:nowrap}td:first-child{font-weight:600}td code{overflow-wrap:anywhere;white-space:normal}.metric-cell{font-size:17px;white-space:nowrap}
    .filters{display:flex;gap:12px;flex-wrap:wrap;align-items:center;padding:14px 18px;background:white;border:1px solid var(--line);border-radius:10px}select{padding:7px 10px;border:1px solid var(--line);border-radius:6px;font:inherit;background:white;max-width:100%}
    details{background:white;border:1px solid var(--line);padding:12px 18px;border-radius:9px;margin:10px 0}summary{cursor:pointer;font-weight:600}pre,code{font:13px/1.6 ui-monospace,SFMono-Regular,Consolas,monospace}pre{white-space:pre-wrap;overflow-wrap:anywhere;padding:16px;background:#f2f5f8;border-radius:7px;max-height:520px;overflow:auto}.rawtext{white-space:pre-wrap}.tag{display:inline-block;border-radius:5px;padding:1px 7px;background:#eaf0f7;font-size:12px;font-weight:600;margin-right:4px}.run-head{display:flex;gap:10px;flex-wrap:wrap;margin:15px 0}.chip{font-size:12px;border:1px solid var(--line);border-radius:12px;padding:3px 10px}.small-note{font-size:13px;color:var(--muted)}
    img{max-width:100%;height:auto;background:white;border-radius:9px}li{margin:6px 0}.source-list{font:13px/1.7 ui-monospace,monospace;overflow-wrap:anywhere}.anomaly p{margin:10px 0}.raw-count{margin:10px 0;color:var(--muted);font-size:13px}
    @media(max-width:680px){main{padding:24px 16px 60px}h1{font-size:27px}.stats{grid-template-columns:repeat(2,minmax(0,1fr))}.panel{padding:16px}.filters{align-items:stretch;flex-direction:column}}
    @media print{body{background:white}main{max-width:none;padding:0}nav,.filters{display:none}.panel,details{break-inside:avoid}pre{max-height:none}h2{break-after:avoid}}
    """
    body = [f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>高难度补测与异常解释</title><style>{css}</style></head><body><main>']
    body += ['<div class="eyebrow">Controlled stress follow-up · 请求配置级比较</div>', '<h1>高难度补测：结果与异常解释</h1>',
             f'<p class="muted">生成于 {esc(generated)} · 原轮70份答卷 · 新轮计划{expected}份 · 每个可执行配置新增一次</p>',
             '<div class="stats">', f'<div class="stat"><b>{completed}/{expected}</b><span>已评分的新轮答卷</span></div>',
             f'<div class="stat"><b>{aggregate.get("new_perfect_runs", 0)}</b><span>新题主分满分答卷</span></div>',
             f'<div class="stat"><b>{total_whole}/{10*completed}</b><span>新题完整正确题次</span></div>',
             f'<div class="stat"><b>{total_high_conf}</b><span>新题高置信不完整题次</span></div></div>',
             f'<div class="note blue">{esc(progress_note)}</div>',
             '<div class="note">这是更换题包后的补测，不是同一量尺上的复测。新题主分有部分得分；原轮总分不能与它直接相减。5.6sol为可执行请求名称，实际后端身份仍未核验。</div>',
             '<nav><a href="#results">新题矩阵</a><a href="#questions">逐题结果</a><a href="#anomalies">异常解释</a><a href="#anchors">锚题复测</a><a href="#style">表达与格式</a><a href="#method">方法与限制</a><a href="#raw">原始答卷</a></nav>',
             '<section class="panel"><h2>当前证据支持的结论</h2>', findings_html, '</section>',
             '<h2 id="results">35个配置的新题结果</h2>',
             '<p>下拉选项同时切换矩阵与原始答卷摘要。主分范围0—100；完整正确数范围0—10；锚题范围0—3。每格只有一个新样本，未完成格不会当作零分。</p>',
             ('<div class="note">† '+esc(placeholder_note)+' <a href="#placeholder-probe">查看单独诊断</a></div>') if placeholder_note else '',
             '<div class="filters"><label>显示指标 <select id="metricSelect"><option value="new_score">新题主分（0—100）</option><option value="new_complete_correct">新题完整正确数（0—10）</option><option value="anchor_correct">锚题正确数（0—3）</option></select></label><span id="metricHint" class="small-note">按预登记子项给分；不含锚题与表达。</span></div>',
             matrix_html, f'<img src="data:image/png;base64,{plot_base64}" alt="新题主分热图，采用固定0到100色标，按请求模型与思考强度排列">',
             '<h3>共同low—max五档汇总</h3><p>完整快照时每个模型均为五档各一次。新题主分与整题正确率同时列出；样本未齐时必须结合完成档位数阅读，不能按不齐全的均值比较模型。</p>',
             table(["请求模型", "完成共同档位", "新题主分均值", "整题正确率%", "满分答卷", "Brier", "高置信不完整"], model_rows),
             '<h2 id="questions">题目与子项：分差来自哪里</h2><p>高置信不完整指提交置信度≥90，但该题不是所有子项都正确。新题与锚题的分母、计分方式分别保留。</p>',
             table(["题目", "样本数", "平均得分率%", "整题正确", "高置信不完整", "未完整答对的运行"], question_rows),
             '<details><summary>展开所有预登记子项的平均得分率</summary>', table(["题目", "子项/代码组", "样本数", "平均得分率%"], part_rows), '</details>',
             '<h3>输出层面能直接核对的错误</h3><p>以下标记描述答案的计数、可行性、自洽性或择优规则，不声称知道内部推理。一个答卷题目可能有多个标记，标记数不能当成独立错题数。</p>', flags_summary,
             '<details><summary>展开逐条错误证据</summary>', table(["运行", "请求模型", "强度", "题号", "可观察类型", "证据"], flag_rows), '</details>',
             '<h3>代码主用例与追加诊断</h3>',
             f'<p>已评分代码的冻结主用例通过 {aggregate.get("code_cases_passed", 0)}/{aggregate.get("code_cases_total", 0)}，其中 {aggregate.get("code_all_pass_runs", 0)}/{completed} 份全部通过。功能测试通过不自动证明渐近复杂度。</p>',
             f'<div class="note">{esc(diagnostic_note)}</div>',
             f'<p>追加诊断目前通过 {aggregate.get("extreme_code_passed", 0)}/{aggregate.get("extreme_code_total", 0)}。未全部通过的运行：{esc(", ".join(aggregate.get("extreme_failed_runs", [])) or "无") }。它们不改变主分。</p>',
             '<details><summary>展开每份代码的极大权重诊断</summary>', table(["运行", "请求模型", "强度", "追加用例通过", "执行错误"], extreme_rows), '</details>',
             '<h2 id="anomalies">异常数据：证据、解释与不能确定的部分</h2>', anomaly_html, probe_html,
             '<details><summary>上一轮异常的独立证据登记（含候选解释，未视作确定因果）</summary>', prior_blocks, '</details>',
             '<h2 id="anchors">同题锚点的复测</h2><p>A01/A02/A03分别对应原Q01/Q10/Q07。旧轮每格两次、新轮每格一次；表中只纳入已有新轮答卷的配对配置。内容相同，但新轮锚题位于十道难题之后，不能视为只有思考强度改变的实验。</p>',
             table(["锚题", "配对配置数", "旧轮正确/两次题次", "新轮正确/一次题次", "新错解与至少一个旧错解完全相同"], anchor_rows),
             '<details><summary>展开逐配置、逐锚题的三次记录</summary>', table(["新运行", "请求模型", "强度", "锚题", "旧第一次", "旧第二次", "新一次", "新答案"], anchor_detail_rows), '</details>',
             '<h2 id="style">中文表达与字段遵循</h2>', style_html,
             '<p>下表只比较共同low—max五档；分别列样本数、非空白Unicode字符数均值和长度合规数。语气、任务完成与格式问题分开解释，长度不是质量分。本轮强化了实际正文放入style的提醒。</p>',
             table(["请求模型", "S02样本", "S02均长", "S02长度合规", "S03样本", "S03均长", "S03长度合规"], style_rows),
             '<details><summary>展开表达长度与字段异常</summary><pre>', pretty(style_issues), '</pre></details>',
             '<h2 id="method">实验方法、评分口径与限制</h2>', paragraphs(method_paragraphs),
             '<details><summary>展开新题结构子项的冻结规则</summary>', table(["题号", "等权子项"], criteria_rows), '<pre>', pretty(rules), '</pre></details>',
             '<details><summary>展开完整原始题包</summary><pre>', esc((ROOT / 'prompt.txt').read_text(encoding='utf-8')), '</pre></details>',
             '<h2 id="raw">原始答卷浏览器</h2><p>所有答案与中文正文直接来自提交JSON；逐题成绩、置信度、运行ID和哈希同时保留。顶部指标切换会改变摘要中的成绩口径，不改原文。</p>',
             '<div class="filters"><label>请求模型 <select id="modelFilter"><option value="">全部</option>',
             ''.join(f'<option value="{esc(m)}">{esc(LABELS[m])}</option>' for m in MODELS), '</select></label><label>思考强度 <select id="effortFilter"><option value="">全部</option>',
             ''.join(f'<option value="{e}">{e}</option>' for e in EFFORTS), '</select></label></div><div class="raw-count" id="rawCount"></div><div id="rawContainer"></div>',
             '<noscript><p>当前未启用JavaScript。所有主表、图表、结论与方法仍可阅读；逐次原文可打开同目录all_raw.jsonl。</p></noscript>',
             '<h2>数据与复算文件</h2><p>完整实验包保留原始JSON、冻结输入与哈希、逐题/逐子项CSV、锚题配对、代码逐用例结果、追加诊断登记和独立审计。模型内部思维链、实际推理token及服务端路由日志未提供。</p>',
             '<div class="source-list">raw/sNNN.json · raw/dNNN.json（独立事后诊断）<br>analysis/runs.csv · items.csv · parts.csv · cells.csv<br>analysis/anchor_comparison.csv · observable_error_flags.json · prior_anomalies.json<br>analysis/style_metrics.csv · diagnostic_code_results.json · abstention_probe_results.json<br>preregistration.json · scoring_rules.json · diagnostic_amendment.json · abstention_probe_protocol.json<br>scripts/score.py · aggregate.py · report.py<br>delivery/all_raw.jsonl（正式答卷）· abstention_probes_raw.jsonl（事后诊断）· report.txt · stress_scores.png / .svg</div>',
             f'<script type="application/json" id="payload">{payload}</script>']
    script = r"""
    const payload=JSON.parse(document.getElementById('payload').textContent);
    const byRun=Object.fromEntries(payload.raw.map(r=>[r.run_id,r]));
    const metrics={new_score:{name:'新题主分',max:100,key:'new_10q_partial_score',hint:'按预登记子项给分；不含锚题与表达。'},new_complete_correct:{name:'新题完整正确',max:10,key:'new_10q_whole_correct',hint:'只有全部子项正确才计1题；不含锚题。'},anchor_correct:{name:'锚题正确',max:3,key:'new_3anchor_correct_out_of_3',hint:'沿用旧轮整题精确匹配，单列0—3题。'}};
    const metricSelect=document.getElementById('metricSelect');
    function metricText(r,key){const v=Number(r[key]);return key==='new_score'?v.toFixed(2)+'/100':String(v)+'/'+metrics[key].max;}
    function renderMatrix(){const metric=metrics[metricSelect.value],tbody=document.querySelector('#scoreMatrix tbody');tbody.replaceChildren();for(const model of payload.models){const tr=document.createElement('tr'),name=document.createElement('td');name.textContent=payload.labels[model];tr.append(name);for(const effort of payload.efforts){const c=payload.cells.find(c=>c.model===model&&c.effort===effort),td=document.createElement('td');if(!c.available){td.textContent='不支持';}else if(c[metric.key]===null||c[metric.key]===undefined){td.textContent='待完成';}else{const strong=document.createElement('strong');strong.className='metric-cell';strong.textContent=(metricSelect.value==='new_score'?Number(c[metric.key]).toFixed(1):Number(c[metric.key])+'/'+metric.max)+(c.run_id===payload.abstention_trigger?'†':'');const small=document.createElement('small');small.textContent=c.run_id;td.append(strong,small);}tr.append(td);}tbody.append(tr);}document.getElementById('metricHint').textContent=metric.hint;}
    function renderRaw(){const model=document.getElementById('modelFilter').value,effort=document.getElementById('effortFilter').value,metric=metricSelect.value,container=document.getElementById('rawContainer');container.replaceChildren();let count=0;for(const r of payload.raw){if((model&&r.model!==model)||(effort&&r.effort!==effort))continue;count++;const detail=document.createElement('details');detail.id='raw-'+r.run_id;const title=document.createElement('summary');title.textContent=r.run_id+' · '+payload.labels[r.model]+' · '+r.effort+' · '+metrics[metric].name+' '+metricText(r,metric);detail.append(title);const head=document.createElement('div');head.className='run-head';for(const key of Object.keys(metrics)){const chip=document.createElement('span');chip.className='chip';chip.textContent=metrics[key].name+' '+metricText(r,key);head.append(chip);}detail.append(head);for(const [sid,text] of Object.entries(r.response.style||{})){const h=document.createElement('h3'),p=document.createElement('p');h.textContent=sid;p.className='rawtext';p.textContent=typeof text==='string'?text:JSON.stringify(text);detail.append(h,p);}const scored=document.createElement('details'),summary=document.createElement('summary');summary.textContent='逐题得分、整题正确性与提交置信度';scored.append(summary);const pre=document.createElement('pre');pre.textContent=payload.items.filter(x=>x.run_id===r.run_id).map(x=>x.question+' | 得分 '+Number(x.score).toFixed(3)+'/1 | 完整正确 '+x.complete_correct+' | 置信度 '+x.confidence).join('\n');scored.append(pre);detail.append(scored);const original=document.createElement('details'),originalTitle=document.createElement('summary'),json=document.createElement('pre');originalTitle.textContent='完整原始JSON（含代码）';json.textContent=JSON.stringify(r.response,null,2);original.append(originalTitle,json);detail.append(original);const hash=document.createElement('p');hash.className='small-note';hash.textContent='原始文件SHA-256：'+r.sha256;detail.append(hash);container.append(detail);}document.getElementById('rawCount').textContent='当前显示 '+count+' / '+payload.raw.length+' 份已评分答卷。';}
    metricSelect.addEventListener('change',()=>{renderMatrix();renderRaw();});document.getElementById('modelFilter').addEventListener('change',renderRaw);document.getElementById('effortFilter').addEventListener('change',renderRaw);renderMatrix();renderRaw();
    """
    body += ["<script>", script, "</script></main></body></html>"]
    document = "".join(body)
    (OUT / "report.html").write_text(document, encoding="utf-8")

    lines = ["高难度补测：结果与异常解释", f"生成于 {generated}", progress_note,
             f"新轮每配置一次，计划{expected}份答卷；10道新题、3道旧锚题、2道中文表达。",
             "5.6sol仅为可执行请求名称，后端身份未核验；6luna ultra明确不支持。",
             "两轮题包与计分不同，不直接相减。", "", "结论", *narrative.get("findings", []), "", "完整配置结果"]
    lines.append("请求模型 | 强度 | 新题主分/100 | 完整正确/10 | 锚题正确/3 | 运行ID")
    for cell in cells:
        if not cell["available"]:
            lines.append(f'{cell["model"]} | {cell["effort"]} | 不支持')
        else:
            lines.append(" | ".join([cell["model"], cell["effort"], num(cell.get("new_10q_partial_score"), 2),
                                       num(cell.get("new_10q_whole_correct"), 0), num(cell.get("new_3anchor_correct_out_of_3"), 0),
                                       cell.get("run_id") or "待完成"]))
    lines += ["", "异常解释"]
    for anomaly in narrative.get("anomalies", []):
        lines += [anomaly.get("title", ""), "证据：" + anomaly.get("evidence", ""), "解释：" + anomaly.get("interpretation", ""), "限制：" + anomaly.get("limits", "")]
    lines += ["", "表达与格式", *narrative.get("style_findings", []), "", "锚题配对统计"]
    for q, stats in aggregate.get("anchor_stats", {}).items():
        lines.append(f'{q}：{stats["pairs"]}个配对配置；旧轮正确{stats["old_correct_out_of_2n"]}/{2*stats["pairs"]}，新轮正确{stats["new_correct_out_of_n"]}/{stats["pairs"]}，完全重现至少一个旧错解{stats["wrong_and_exactly_repeated_old_error"]}次。')
    lines += ["", "追加极大权重诊断（不计主分）", diagnostic_note,
              f'通过{aggregate.get("extreme_code_passed", 0)}/{aggregate.get("extreme_code_total", 0)}；未全通过运行：'+(", ".join(aggregate.get("extreme_failed_runs", [])) or "无"),
              "", "方法与限制", *method_paragraphs, "", "上一轮独立异常登记"]
    if abstention_protocol:
        lines += ["", "占位答卷的独立事后诊断", placeholder_note,
                  "完整题包2次与三题短包2次，只比较H01/H04/H09；每组n=2且事后触发，不识别内部因果，不替换主样本。",
                  "诊断运行 | 条件 | 状态 | 匹配三题分/100 | 置信度全0 | 表达字段非空"]
        lines += [" | ".join(map(str, row)) for row in probe_rows]
        for rid, refusal_message in refusal_blocks:
            lines += [rid+"原始拒绝消息（由主代理记录，不是模型答案JSON）：", refusal_message,
                      "该次为空成绩，不记0分，不删除，不伪造答案对象；拒绝所述理由不能证明环境实际禁止读题。"]
        lines += list(probe_limits)
    for anomaly in prior.get("anomalies", []):
        lines += [anomaly.get("title", ""), "支持的解释：" + anomaly.get("supported_interpretation", ""),
                  "候选原因（未识别）：" + "；".join(anomaly.get("compatible_hypotheses", [])),
                  "不能确定：" + "；".join(anomaly.get("not_established", []))]
    (OUT / "report.txt").write_text("\n\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"completed": completed, "expected": expected, "report_bytes": len(document.encode("utf-8")),
                      "raw_jsonl_records": len(raw), "narrative_present": (ROOT / "analysis/narrative.json").exists(),
                      "written": ["delivery/report.html", "delivery/report.txt", "delivery/stress_scores.png", "delivery/stress_scores.svg", "delivery/all_raw.jsonl"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
