import pathlib,json,csv,subprocess,sys,collections,statistics,hashlib
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parents[1];OLD=ROOT.parent/'model-comparison'
read=lambda p:json.loads(p.read_text())
plan=read(ROOT/'run_plan.json');key=read(ROOT/'answer_key.json');fixtures=read(ROOT/'fixtures.json')
codecases=read(ROOT/'diagnostic_code_cases.json');codeout={};rows=[];flags=[]
oldplan=read(OLD/'run_plan_extended.json');om={(r['model'],r['effort'],r['repeat']):r['run_id'] for r in oldplan}
def fail(r,q,kind,evidence):flags.append({'run_id':r['run_id'],'model':r['model'],'effort':r['effort'],'question':q,'kind':kind,'observable_evidence':evidence,'causal_note':'Output-level diagnosis, not evidence of hidden reasoning or backend identity.'})
for r in plan:
 f=ROOT/'raw'/f"{r['run_id']}.json"
 if not f.exists():continue
 d=read(f);a=d.get('answers',{})
 try:
  p=subprocess.run([sys.executable,'-I',str(ROOT/'scripts/code_runner.py')],input=json.dumps({'source':a.get('H10',''),'cases':codecases}),capture_output=True,text=True,timeout=8)
  cd=json.loads(p.stdout)
 except Exception as e:cd={'error':str(e),'outcomes':[]}
 codeout[r['run_id']]=cd
 for nq,oq in [('A01','Q01'),('A02','Q10'),('A03','Q07')]:
  prev=[]
  for rep in [1,2]:
   rid=om[r['model'],r['effort'],rep];answer=read(OLD/'raw'/f'{rid}.json')['answers'][oq]
   prev.append({'run_id':rid,'answer':answer,'correct':answer==key[nq]})
  rows.append({**r,'question':nq,'old_question':oq,'old_r1_correct':prev[0]['correct'],'old_r2_correct':prev[1]['correct'],'new_correct':a.get(nq)==key[nq],'new_equals_old_r1':a.get(nq)==prev[0]['answer'],'new_equals_old_r2':a.get(nq)==prev[1]['answer'],'old_r1_answer':json.dumps(prev[0]['answer'],ensure_ascii=False),'old_r2_answer':json.dumps(prev[1]['answer'],ensure_ascii=False),'new_answer':json.dumps(a.get(nq),ensure_ascii=False)})
 placeholder=(len(d.get('confidence',{}))==13 and all(v==0 for v in d['confidence'].values()) and a.get('H01')=={'count':0,'first':''} and a.get('H07')==[] and a.get('H06',{}).get('probabilities')==['0','0','0'])
 if placeholder:
  fail(r,'submission','placeholder_objective_submission','Zero/empty objective placeholders and all 13 confidences zero; analyze non-completion separately from substantive wrong reasoning.')
  continue
 expected_keys={f'H{i:02d}' for i in range(1,11)}|{'A01','A02','A03'}
 missing=sorted(expected_keys-set(a))
 empty_examples={'H01':{'count':0,'first':''},'H02':{'urn_B':'0','next_red':'0'},'H03':{'p_HHT_first':'0','expected_tosses':'0'},'H04':{'LATE':'0','ATE_bounds':['0','0']},'H05':{'n':0,'rows':[],'transitivity_suffices':False},'H06':{'probabilities':['0','0','0'],'worst_expected_cost':'0'},'H07':[],'H08':{'abort':[],'serial_order_count':0,'first_order':[]},'H09':{'cost':0,'sets':[]},'A01':{'count':0,'first':''},'A02':{'cost':0,'sets':[]},'A03':{'A':0,'B':0,'supported':[]}}
 empty_keys=[q for q,value in empty_examples.items() if a.get(q)==value and d.get('confidence',{}).get(q)==0]
 nonattempt=set(missing+empty_keys)
 if nonattempt:
  fail(r,'submission','partial_noncompletion',json.dumps({'missing_answers':missing,'zero_or_empty_with_zero_confidence':empty_keys,'note':'Separate missing/placeholder responses from substantive wrong attempts.'},ensure_ascii=False))
  for q in missing:fail(r,q,'missing_answer','No submitted answer; not a substantive wrong solution.')
  for q in empty_keys:fail(r,q,'zero_confidence_placeholder','Zero/empty answer pattern with zero submitted confidence; excluded from substantive-constraint error classification.')
 for q,letters in [('H01','ABCDEFGH'),('A01','ABCDEFG')]:
  if q in nonattempt:continue
  x=a.get(q,{})
  if not isinstance(x,dict):continue
  first=x.get('first','')
  if len(first)!=len(letters) or set(first)!=set(letters):fail(r,q,'malformed_permutation',first);continue
  ix={x:first.index(x)+1 for x in first}
  if q=='H01':cons={'A_before_D':ix['A']<ix['D'],'C_immediately_before_G':ix['G']==ix['C']+1,'B_position_2_or_6':ix['B'] in [2,6],'E_before_A':ix['E']<ix['A'],'H_equals_D_plus_2':ix['H']==ix['D']+2,'F_before_H':ix['F']<ix['H'],'G_not_adjacent_H':abs(ix['G']-ix['H'])!=1}
  else:cons={'A_before_D':ix['A']<ix['D'],'C_immediately_before_F':ix['F']==ix['C']+1,'B_position_2_or_5':ix['B'] in [2,5],'E_before_A':ix['E']<ix['A'],'G_not_adjacent_D':abs(ix['G']-ix['D'])!=1,'D_before_F':ix['D']<ix['F']}
  violations=[k for k,v in cons.items() if not v]
  if violations:fail(r,q,'returned_permutation_violates_conditions',json.dumps({'first':first,'violations':violations},ensure_ascii=False))
  if x.get('count')!=key[q]['count']:fail(r,q,'incorrect_count',json.dumps({'submitted':x.get('count'),'expected':key[q]['count']}))
 sets={s['name']:s for s in fixtures['sets']}
 x=a.get('H09',{})
 if 'H09' not in nonattempt and isinstance(x,dict) and isinstance(x.get('sets'),list) and all(s in sets for s in x['sets']):
  chosen=x['sets'];actual=sum(sets[s]['cost'] for s in chosen);covered=set().union(*(set(sets[s]['elements']) for s in chosen));constraints=('B' not in chosen or 'F' in chosen) and not ('D' in chosen and 'H' in chosen) and ('C' in chosen or 'J' in chosen)
  if x.get('cost')!=actual:fail(r,'H09','cost_does_not_match_chosen_sets',json.dumps({'reported':x.get('cost'),'actual':actual}))
  if covered!=set(range(1,11)) or not constraints or len(chosen)!=len(set(chosen)):fail(r,'H09','infeasible_cover',json.dumps({'covered':sorted(covered),'side_constraints_pass':constraints,'sets':chosen}))
  elif actual>key['H09']['cost']:fail(r,'H09','feasible_but_nonoptimal',json.dumps({'cost':actual,'sets':chosen}))
  elif actual==key['H09']['cost'] and chosen!=key['H09']['sets']:fail(r,'H09','optimal_cost_but_tiebreak_wrong',json.dumps(chosen))
 x=a.get('H06',{})
 try:
  if 'H06' in nonattempt:continue
  probs=[Fraction(v) for v in x['probabilities']];val=Fraction(x['worst_expected_cost'])
  if len(probs)!=3 or any(p<0 for p in probs) or sum(probs)!=1:fail(r,'H06','invalid_probability_distribution',str(probs))
  else:
   costs=[[0,9,6,4],[7,0,5,8],[6,4,0,7]];actual=max(sum(probs[i]*costs[i][j] for i in range(3)) for j in range(4))
   if val!=actual:fail(r,'H06','reported_value_inconsistent_with_strategy',json.dumps({'reported':str(val),'actual_worst':str(actual)}))
   if actual>Fraction(key['H06']['worst_expected_cost']):fail(r,'H06','valid_but_nonoptimal_strategy',str(actual))
 except Exception:fail(r,'H06','unparseable_probability_answer',json.dumps(x,ensure_ascii=False))
 x=a.get('H04',{})
 if isinstance(x,dict) and x.get('LATE')==key['H04']['LATE'] and x.get('ATE_bounds')!=key['H04']['ATE_bounds']:fail(r,'H04','LATE_correct_but_ATE_bounds_wrong',json.dumps(x,ensure_ascii=False))
 if set(d)!= {'answers','confidence','style'} or set(a)!={f'H{i:02d}' for i in range(1,11)}|{'A01','A02','A03'} or set(d.get('style',{}))!={'S02','S03'}:fail(r,'schema','unexpected_or_missing_keys',json.dumps({'root':list(d),'answers':list(a),'style':list(d.get('style',{}))}))
for name,obj in [('diagnostic_code_results.json',codeout),('observable_error_flags.json',flags)]:
 (ROOT/'analysis'/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
if rows:
 with (ROOT/'analysis/anchor_comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
print(json.dumps({'runs':len(codeout),'diagnostic_full_pass':sum(len(v['outcomes'])==4 and all(o['passed'] for o in v['outcomes']) for v in codeout.values()),'error_flags':len(flags),'flag_types':dict(collections.Counter(f['kind'] for f in flags))},ensure_ascii=False))
