import pathlib,json,itertools,math,random,hashlib,datetime,sqlite3
from fractions import Fraction
import sympy as sp
ROOT=pathlib.Path(__file__).resolve().parents[1]
def dump(name,x):(ROOT/name).write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
valid=[]
for p in itertools.permutations('ABCDEFGH'):
 d={x:p.index(x)+1 for x in p}
 if d['A']<d['D'] and d['G']==d['C']+1 and d['B'] in [2,6] and d['E']<d['A'] and d['H']==d['D']+2 and d['F']<d['H'] and abs(d['G']-d['H'])!=1:
  valid.append(''.join(p))
h01={'count':len(valid),'first':min(valid)}
prior=[Fraction(2,5),Fraction(3,5)];urns=[(4,3,2),(2,4,3)];event=[];nextred=[]
for urn in urns:
 den=math.comb(sum(urn),4);ev=nr=Fraction(0)
 for r,b,g in itertools.product(range(5),range(5),range(5)):
  if r+b+g!=4 or any(t>u for t,u in zip((r,b,g),urn)):continue
  if sum(t>0 for t in (r,b,g))!=2 or g<1 or r%2!=1:continue
  mass=Fraction(math.prod(math.comb(u,t) for u,t in zip(urn,(r,b,g))),den)
  ev+=mass;nr+=mass*Fraction(urn[0]-r,5)
 event.append(ev);nextred.append(nr)
den=sum(a*b for a,b in zip(prior,event))
h02={'urn_B':str(prior[1]*event[1]/den),'next_red':str(sum(a*b for a,b in zip(prior,nextred))/den)}
states=['','H','HH','HT'];pH=sp.Rational(2,3);P=sp.zeros(4,4);bprob=sp.zeros(4,1)
for i,s in enumerate(states):
 for ch,p in [('H',pH),('T',1-pH)]:
  ns=s+ch
  if ns.endswith('HHT'):bprob[i]+=p
  elif ns.endswith('HTH'):pass
  else:
   tail=max((x for x in states if ns.endswith(x)),key=len)
   P[i,states.index(tail)]+=p
M=sp.eye(4)-P
h03={'p_HHT_first':str((M.inv()*bprob)[0]),'expected_tosses':str((M.inv()*sp.ones(4,1))[0])}
costs=[[0,9,6,4],[7,0,5,8],[6,4,0,7]]
sols=[]
pa,pb,pc,v=sp.symbols('pa pb pc v');vars=[pa,pb,pc,v]
ineq=[pa,pb,pc]+[v-sum(vars[i]*costs[i][j] for i in range(3)) for j in range(4)]
for active in itertools.combinations(range(7),3):
 sol=sp.solve([pa+pb+pc-1]+[ineq[i] for i in active],vars)
 if set(sol)!=set(vars):continue
 if all(expr.subs(sol)>=0 for expr in ineq):sols.append(sol)
best=min(sols,key=lambda s:s[v]);h06={'probabilities':[str(best[x]) for x in [pa,pb,pc]],'worst_expected_cost':str(best[v])}
customers=[(1,'A',1),(2,'A',1),(3,'B',1),(4,'B',1),(5,'C',1),(6,'C',0),(7,'D',1)]
orders=[(101,1,12,'paid',1),(102,1,30,'pending',3),(103,1,None,'paid',2),(201,2,9,'pending',4),(202,2,100,'void',5),(203,2,20,'paid',None),(301,3,99,None,9),(401,4,10,'paid',5),(402,4,-5,'paid',5),(403,4,10,'paid',None),(501,5,50,'pending',1),(601,6,77,'paid',8)]
query="""WITH ranked AS (
 SELECT oid,cid,amount,status,
 ROW_NUMBER() OVER(PARTITION BY cid ORDER BY CASE WHEN ts IS NULL THEN 1 ELSE 0 END,ts DESC,oid DESC) AS rn
 FROM orders WHERE status <> 'void'
)
SELECT c.grp,COUNT(*) AS rows_n,COUNT(r.oid) AS kept_n,
 SUM(CASE WHEN r.amount>10 THEN 1 ELSE 0 END) AS large_n,
 COALESCE(SUM(r.amount),0) AS total,COUNT(DISTINCT r.amount) AS distinct_n
FROM customers c LEFT JOIN ranked r ON r.cid=c.cid AND r.rn<=2
WHERE c.active=1 AND (r.status='paid' OR r.oid IS NULL)
GROUP BY c.grp ORDER BY c.grp;"""
db=sqlite3.connect(':memory:');db.execute('CREATE TABLE customers(cid,grp,active)');db.execute('CREATE TABLE orders(oid,cid,amount,status,ts)');db.executemany('INSERT INTO customers VALUES(?,?,?)',customers);db.executemany('INSERT INTO orders VALUES(?,?,?,?,?)',orders)
h07=[list(x) for x in db.execute(query)]
edges=[(1,2),(2,3),(3,1),(4,5),(5,6),(6,4),(2,4),(5,1),(3,6),(6,2)]
choices=[]
for k in range(7):
 for aborted in itertools.combinations(range(1,7),k):
  remain=[x for x in range(1,7) if x not in aborted]
  orders_ok=[list(order) for order in itertools.permutations(remain) if all(a in aborted or b in aborted or order.index(a)<order.index(b) for a,b in edges)]
  if orders_ok:choices.append((k,list(aborted),orders_ok))
 if choices:break
choice=min(choices);h08={'abort':choice[1],'serial_order_count':len(choice[2]),'first_order':min(choice[2])}
rng=random.Random(20261120)
for attempt in range(10000):
 sets=[{'name':chr(65+i),'elements':sorted(rng.sample(range(1,11),rng.randint(3,5))),'cost':rng.randint(3,8)} for i in range(12)]
 covers=[]
 for mask in range(1,4096):
  names=[s['name'] for i,s in enumerate(sets) if mask>>i&1]
  if 'B' in names and 'F' not in names or 'D' in names and 'H' in names or not ('C' in names or 'J' in names):continue
  chosen=[s for s in sets if s['name'] in names]
  if set.union(*(set(s['elements']) for s in chosen))!=set(range(1,11)):continue
  covers.append((sum(s['cost'] for s in chosen),len(chosen),names))
 if not covers:continue
 best=min(covers);ties=[x for x in covers if x[0]==best[0]]
 if len(ties)>=3 and len(set(x[1] for x in ties))>1 and sum(x[1]==best[1] for x in ties)>1:break
else:raise RuntimeError('No fixture')
h09={'cost':best[0],'sets':best[2]}
key={'H01':h01,'H02':h02,'H03':h03,'H04':{'LATE':'3/10','ATE_bounds':['-7/20','13/20']},'H05':{'n':3,'rows':['101','110','011'],'transitivity_suffices':True},'H06':h06,'H07':h07,'H08':h08,'H09':h09}
old=json.loads((ROOT.parent/'model-comparison/answer_key.json').read_text())
key.update(A01=old['Q01'],A02=old['Q10'],A03=old['Q07'])
dump('answer_key.json',key)
dump('fixtures.json',{'customers':customers,'orders':orders,'sql':query,'conflict_edges':edges,'sets':sets,'H09_optimal_ties':ties,'H09_generation_attempt':attempt,'H01_valid_orders':valid})
cells=json.loads((ROOT.parent/'model-comparison/availability_extended.json').read_text());plan=[{'model':c['model'],'effort':c['effort'],'repeat':1} for c in cells if c['status']!='unsupported_effort']
random.Random(20261121).shuffle(plan)
for i,r in enumerate(plan,1):r['run_id']=f's{i:03d}'
dump('run_plan.json',plan)
print(json.dumps({'key':key,'sets':sets,'ties':ties,'plan':plan},ensure_ascii=False,indent=2))
