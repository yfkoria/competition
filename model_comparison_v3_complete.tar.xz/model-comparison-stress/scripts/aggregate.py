import pathlib,json,csv,collections,statistics
ROOT=pathlib.Path(__file__).resolve().parents[1];OLD=ROOT.parent/'model-comparison'
read=lambda p:json.loads(p.read_text())
def csvread(p):return list(csv.DictReader(p.open(encoding='utf-8-sig')))
runs=csvread(ROOT/'analysis/runs.csv');items=csvread(ROOT/'analysis/items.csv');anchors=csvread(ROOT/'analysis/anchor_comparison.csv');styles=csvread(ROOT/'analysis/style_metrics.csv')
oldruns=csvread(OLD/'analysis/runs.csv');olditems=csvread(OLD/'analysis/items.csv');models=['gpt-6-astra','gpt-6.1-sol','gpt-6-sol','gpt-6.1-terra','gpt-6-luna','gpt-5.6-sol'];efforts=['low','medium','high','xhigh','max','ultra']
cells=[];mod=[];qs=[]
for m in models:
 for e in efforts:
  prior=[r for r in oldruns if r['model']==m and r['effort']==e];new=next((r for r in runs if r['model']==m and r['effort']==e),None)
  old_anchor=[int(x['complete_correct']) for x in olditems if x['model']==m and x['effort']==e and x['question'] in ['Q01','Q10','Q07']]
  cells.append({'model':m,'effort':e,'available':bool(prior),'old_12q_mean':statistics.mean(float(r['score_100']) for r in prior) if prior else None,'new_10q_partial_score':float(new['new_score']) if new else None,'new_10q_whole_correct':int(new['new_complete_correct']) if new else None,'old_3anchor_correct_out_of_6':sum(old_anchor) if prior else None,'new_3anchor_correct_out_of_3':float(new['anchor_correct']) if new else None,'run_id':new['run_id'] if new else None})
 common=[r for r in runs if r['model']==m and r['effort']!='ultra'];prior=[r for r in oldruns if r['model']==m and r['effort']!='ultra'];mi=[x for x in items if x['model']==m and x['effort']!='ultra' and x['question'].startswith('H')]
 if common:mod.append({'model':m,'common_effort_runs':len(common),'old_mean':statistics.mean(float(r['score_100']) for r in prior),'new_mean':statistics.mean(float(r['new_score']) for r in common),'new_whole_correct_mean_100':statistics.mean(int(r['new_complete_correct'])*10 for r in common),'new_perfect_runs':sum(float(r['new_score'])==100 for r in common),'new_high_confidence_incomplete':sum(x['complete_correct']=='False' and int(x['confidence'])>=90 for x in mi),'new_brier':statistics.mean(float(x['brier']) for x in mi if x['brier'])})
for q in [f'H{i:02d}' for i in range(1,11)]+['A01','A02','A03']:
 rows=[x for x in items if x['question']==q]
 if rows:qs.append({'question':q,'n':len(rows),'mean_credit':statistics.mean(float(x['score']) for x in rows),'full_correct':sum(x['complete_correct']=='True' for x in rows),'high_confidence_incomplete':sum(x['complete_correct']=='False' and int(x['confidence'])>=90 for x in rows),'failed_runs':[x['run_id'] for x in rows if x['complete_correct']!='True']})
anchor_stats={}
for q in ['A01','A02','A03']:
 xs=[x for x in anchors if x['question']==q]
 if xs:anchor_stats[q]={'pairs':len(xs),'old_correct_out_of_2n':sum(x['old_r1_correct']=='True' for x in xs)+sum(x['old_r2_correct']=='True' for x in xs),'new_correct_out_of_n':sum(x['new_correct']=='True' for x in xs),'wrong_and_exactly_repeated_old_error':sum(x['new_correct']!='True' and (x['new_equals_old_r1']=='True' or x['new_equals_old_r2']=='True') for x in xs)}
codes=read(ROOT/'analysis/code_test_details.json');extra=read(ROOT/'analysis/diagnostic_code_results.json')
out={'models_common_low_through_max':mod,'cells':cells,'questions':qs,'completed':len(runs),'new_perfect_runs':sum(float(r['new_score'])==100 for r in runs),'old_perfect_runs':sum(float(r['score_100'])==100 for r in oldruns),'old_total_runs':len(oldruns),'anchor_stats':anchor_stats,'code_cases_passed':sum(t['passed'] for v in codes.values() for t in v['outcomes']),'code_cases_total':len(codes)*96,'code_all_pass_runs':sum(len(v['outcomes'])==96 and all(t['passed'] for t in v['outcomes']) for v in codes.values()),'extreme_code_passed':sum(t['passed'] for v in extra.values() for t in v['outcomes']),'extreme_code_total':len(extra)*4,'extreme_failed_runs':[rid for rid,v in extra.items() if len(v['outcomes'])!=4 or not all(t['passed'] for t in v['outcomes'])],'style_length_failures':[{'run_id':x['run_id'],'style_id':x['style_id'],'chars':x['nonspace_chars']} for x in styles if x['length_compliant']!='True'],'style_wrong_field_runs':sorted(set(x['run_id'] for x in styles if x['answers_has_style_key']=='True'))}
(ROOT/'analysis/aggregate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
with (ROOT/'analysis/cells.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(cells[0]));w.writeheader();w.writerows(cells)
print(json.dumps(out,ensure_ascii=False,indent=2))
