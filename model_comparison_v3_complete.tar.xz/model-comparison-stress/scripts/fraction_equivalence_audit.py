import pathlib,json,csv,statistics
from fractions import Fraction
ROOT=pathlib.Path(__file__).resolve().parents[1]
read=lambda f:json.loads((ROOT/f).read_text())
plan=read('run_plan.json');key=read('answer_key.json');rules=read('scoring_rules.json')
items=list(csv.DictReader((ROOT/'analysis/items.csv').open(encoding='utf-8-sig')))
rawscores={(x['run_id'],x['question']):float(x['score']) for x in items}
rational={'H02':{'urn_B','next_red'},'H03':{'p_HHT_first','expected_tosses'},'H04':{'LATE','ATE_bounds.0','ATE_bounds.1'},'H06':{'probabilities','worst_expected_cost'}}
def get(x,path):
 try:
  for k in path.split('.'):x=x[int(k)] if isinstance(x,list) else x[k]
  return x
 except (KeyError,IndexError,TypeError,ValueError):return None
def norm(x):
 if isinstance(x,list):return [norm(v) for v in x]
 if isinstance(x,str):
  try:return Fraction(x)
  except (ValueError,ZeroDivisionError):return x
 return x
changes=[];rows=[]
for r in plan:
 answers=read(f"raw/{r['run_id']}.json").get('answers',{});credits={q:rawscores[r['run_id'],q] for q in [f'H{i:02d}' for i in range(1,11)]}
 for q,paths in rational.items():
  part_values=[]
  for part in rules['parts'][q]:
   a=get(answers.get(q),part);expected=get(key[q],part);raw=a==expected;equivalent=(norm(a)==norm(expected)) if part in paths else raw
   part_values.append(float(equivalent))
   if equivalent and not raw:changes.append({**r,'question':q,'part':part,'submitted':a,'required':expected,'diagnosis':'Mathematically equivalent exact rational but violates required simplest-fraction string format; frozen primary score unchanged.'})
  credits[q]=statistics.mean(part_values)
 primary=sum(rawscores[r['run_id'],f'H{i:02d}'] for i in range(1,11))*10
 rows.append({**r,'primary_score':primary,'rational_equivalence_sensitivity_score':sum(credits.values())*10})
out={'posthoc':True,'changes_primary_scores':False,'scope':'Exact rational equivalence only, no tolerance for approximate floats; retains all other frozen rules. This is a sensitivity analysis, not replacement grading.','equivalent_but_format_noncompliant_parts':changes,'records':rows,'models_common_five':[{'model':m,'primary_mean':statistics.mean(r['primary_score'] for r in rows if r['model']==m and r['effort']!='ultra'),'sensitivity_mean':statistics.mean(r['rational_equivalence_sensitivity_score'] for r in rows if r['model']==m and r['effort']!='ultra')} for m in dict.fromkeys(r['model'] for r in rows)]}
(ROOT/'analysis/fraction_equivalence_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'changes':changes,'means':out['models_common_five']},ensure_ascii=False,indent=2))
