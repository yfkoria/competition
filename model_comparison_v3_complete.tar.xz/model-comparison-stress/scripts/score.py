import pathlib,json,csv,subprocess,sys,statistics,re,hashlib,collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
read=lambda f:json.loads((ROOT/f).read_text())
plan=read('run_plan.json');key=read('answer_key.json');cases=read('code_cases.json');rules=read('scoring_rules.json')
def getpart(x,path):
 try:
  for k in path.split('.'):x=x[int(k)] if isinstance(x,list) else x[k]
  return x
 except (KeyError,IndexError,TypeError,ValueError):return object()
records=[];items=[];parts=[];styles=[];errors=[];codes={}
for run in plan:
 f=ROOT/'raw'/f"{run['run_id']}.json"
 if not f.exists():continue
 try:d=json.loads(f.read_text())
 except Exception as e:errors.append({'run_id':run['run_id'],'error':str(e)});continue
 answers=d.get('answers',{});conf=d.get('confidence',{});qs={}
 for q in [f'H{i:02d}' for i in range(1,11)]+['A01','A02','A03']:
  if q=='H10':
   try:
    proc=subprocess.run([sys.executable,'-I',str(ROOT/'scripts/code_runner.py')],input=json.dumps({'source':answers.get(q,''),'cases':cases}),text=True,capture_output=True,timeout=8)
    outcome=json.loads(proc.stdout)
   except Exception as e:outcome={'error':str(e),'outcomes':[]}
   codes[run['run_id']]=outcome
   gs={g:sum(t['passed'] for t in outcome['outcomes'] if t['group']==g)/12 for g in sorted(set(c['group'] for c in cases))}
   score=statistics.mean(gs.values())
   for name,val in gs.items():parts.append({**run,'question':q,'part':name,'score':val})
  elif q.startswith('A'):score=float(answers.get(q)==key[q])
  else:
   values=[]
   for part in rules['parts'][q]:
    good=getpart(answers.get(q),part)==getpart(key[q],part)
    if q=='H07' and (not isinstance(answers.get(q),list) or len(answers[q])!=3):good=False
    values.append(float(good));parts.append({**run,'question':q,'part':part,'score':float(good)})
   score=statistics.mean(values)
  qs[q]=score;c=conf.get(q);b=(c/100-int(score==1))**2 if type(c)==int and 0<=c<=100 else None
  items.append({**run,'question':q,'score':score,'complete_correct':score==1,'confidence':c,'brier':b,'answer_json':json.dumps(answers.get(q),ensure_ascii=False)})
 rec={**run,'new_score':sum(qs[f'H{i:02d}'] for i in range(1,11))*10,'new_complete_correct':sum(qs[f'H{i:02d}']==1 for i in range(1,11)),'anchor_correct':sum(qs[x] for x in ['A01','A02','A03']),'raw_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'answers_extra_keys':','.join(sorted(set(answers)-set(qs)))}
 records.append(rec)
 for sid,lo,hi in [('S02',60,140),('S03',80,160)]:
  text=d.get('style',{}).get(sid,'');n=len(re.sub(r'\s','',text))
  styles.append({**run,'style_id':sid,'source_field':'style.'+sid,'nonspace_chars':n,'length_compliant':lo<=n<=hi,'text':text,'answers_has_style_key':sid in answers})
def csvout(name,rows):
 if not rows:return
 with (ROOT/'analysis'/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
csvout('runs.csv',records);csvout('items.csv',items);csvout('parts.csv',parts);csvout('style_metrics.csv',styles)
(ROOT/'analysis/code_test_details.json').write_text(json.dumps(codes,ensure_ascii=False,indent=2)+'\n')
(ROOT/'analysis/summary.json').write_text(json.dumps({'completed':len(records),'expected':35,'errors':errors,'records':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'completed':len(records),'errors':errors,'runs':[{'id':r['run_id'],'score':r['new_score'],'anchors':r['anchor_correct']} for r in records]},ensure_ascii=False))
