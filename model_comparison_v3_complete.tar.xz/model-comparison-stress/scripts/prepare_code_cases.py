import pathlib,json,random,collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
rng=random.Random(20261122);MOD=1000000007
def oracle(n,edges,s,t):
 inf=10**50;d=[[inf]*n for _ in range(n)]
 for i in range(n):d[i][i]=0
 for a,b,w in edges:d[a][b]=min(d[a][b],w)
 for k in range(n):
  for i in range(n):
   for j in range(n):d[i][j]=min(d[i][j],d[i][k]+d[k][j])
 D=d[s][t]
 if D==inf:return [None,0]
 nodes=[v for v in range(n) if d[s][v]+d[v][t]==D];adj={v:[] for v in nodes};indeg={v:0 for v in nodes}
 for a,b,w in edges:
  if d[s][a]+w+d[b][t]==D:adj[a].append(b);indeg[b]+=1
 ready=collections.deque(v for v in nodes if indeg[v]==0);top=[]
 while ready:
  a=ready.popleft();top.append(a)
  for b in adj[a]:
   indeg[b]-=1
   if indeg[b]==0:ready.append(b)
 if len(top)!=len(nodes):return[D,'INF']
 ways={v:0 for v in nodes};ways[s]=1
 for a in top:
  for b in adj[a]:ways[b]=(ways[b]+ways[a])%MOD
 return[D,ways[t]]
cases=[]
def add(group,n,e,s,t):cases.append({'group':group,'n':n,'edges':e,'s':s,'t':t,'expected':oracle(n,e,s,t)})
for i in range(12):
 if i==0:
  add('unreachable',2,[],0,1);continue
 n=4+i%4;e=[[rng.randrange(n-1),rng.randrange(n-1),rng.randrange(4)] for _ in range(8)]
 add('unreachable',n,e,0,n-1)
for i in range(12):
 if i<3:
  add('source_equals_target',1,[] if i==0 else [[0,0,i-1]],0,0);continue
 n=4;e=[[0,1,0],[1,2,i%3],[2,0,0]] if i%2 else [[0,1,1],[1,2,0],[2,1,0]]
 if i%3==0:e.append([0,0,i%2])
 add('source_equals_target',n,e,0,0)
for i in range(12):
 if i==0:
  add('positive_weights',3,[[0,1,10**12],[1,2,10**12],[0,2,3*10**12]],0,2);continue
 n=rng.randrange(3,9);e=[[rng.randrange(n),rng.randrange(n),rng.randrange(1,8)] for _ in range(3*n)];add('positive_weights',n,e,0,n-1)
for i in range(12):
 if i==0:
  add('zero_weight_dag',4,[[0,1,0],[0,2,0],[2,1,0],[1,3,1],[2,3,1]],0,3);continue
 n=6;order=list(range(n));rng.shuffle(order);e=[]
 for j in range(n-1):e.append([order[j],order[j+1],0 if j<n-2 else 1])
 for j in range(n):
  for k in range(j+2,n):
   if rng.random()<.5:e.append([order[j],order[k],0 if k<n-1 else 1])
 add('zero_weight_dag',n,e,order[0],order[-1])
for i in range(12):
 e=[[0,1,2],[1,2,0],[2,1,0],[2,3,3],[0,3,5+i]]
 if i%2:e.append([1,1,0])
 add('relevant_zero_cycle',4,e,0,3)
for i in range(12):
 e=[[0,3,2],[0,1,3],[1,2,0],[2,1,0]]
 if i%2:e.append([2,3,1])
 if i%3==0:e.extend([[3,4,1],[4,4,0]])
 add('irrelevant_zero_cycle',5,e,0,3)
for i in range(12):
 e=[[0,1,0]]*(i+1)+[[1,2,2]]*(13-i)+[[0,2,2],[0,1,3],[2,3,0]]
 add('parallel_edges',4,e,0,3)
for i in range(12):
 n=18+i;e=[]
 for j in range(n-1):e.extend([[j,j+1,j%2]]*(2+i%4))
 add('modulo_large_count',n,e,0,n-1)
add_cases=[]
assert len(cases)==96
(ROOT/'code_cases.json').write_text(json.dumps(cases,ensure_ascii=False,indent=2)+'\n')
print('Fixed code cases',len(cases),'groups',dict(collections.Counter(c['group'] for c in cases)))
