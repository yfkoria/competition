import pathlib,json,re
ROOT=pathlib.Path(__file__).resolve().parents[1]
f=json.loads((ROOT/'fixtures.json').read_text())
old=(ROOT.parent/'model-comparison/prompt.txt').read_text()
q1=re.search(r'Q01：(.*?)\n\nQ02',old,re.S).group(1)
q10=re.search(r'Q10：(.*?)\n\nQ11',old,re.S).group(1)
q7=re.search(r'Q07：(.*?)\n\nQ08',old,re.S).group(1)
s2=re.search(r'S02：(.*?)\nS03',old,re.S).group(1)
s3=old.split('S03：',1)[1].strip()
settext='\n'.join(f"{s['name']}={{{','.join(map(str,s['elements']))}}}，费用{s['cost']}" for s in f['sets'])
schedule='；'.join(f'w{a}({chr(97+i)})，r{b}({chr(97+i)})' for i,(a,b) in enumerate(f['conflict_edges']))
prompt=f'''你正在参加固定题包测评。请独立作答，不猜测自己的模型身份，不查资料，不运行代码、计算器或任何工具解题，不读取其他文件，不联系其他智能体。唯一例外：完成答案后使用apply_patch记录最终JSON；若写入失败，只可修复同一答案文件。不要提问，不输出思维链，只提交最终答案与所要求的代码。

请将合法UTF-8 JSON写入 /workspace/model-comparison-stress/raw/你的任务名最后一段.json。根对象只能有 answers、confidence、style。answers包含且仅包含H01—H10、A01—A03，值的格式见题面。confidence含相同13个键，值为你认为整题完整正确的概率百分数（0—100整数）。style包含且仅包含S02、S03，必须存放实际中文正文，不能用风格标签或摘要代替；不要把S02/S03放进answers。不要写入模型名或强度猜测。写入后最终回复仅为“已记录”。

以下H01—H10为新题，A01—A03是独立计分的锚题。

H01：将A、B、C、D、E、F、G、H各用一次排成一行，位置为1至8。约束同时成立：A在D前；C紧挨在G前；B在第2或第6位；E在A前；D与H之间恰有一个元素且D在H前；F在H前；G与H不相邻。求排列总数及字典序最小排列。返回{{"count":整数,"first":"8个字母"}}。

H02：先以2/5概率选袋A、3/5概率选袋B。袋A含4红3蓝2绿，袋B含2红4蓝3绿。选定袋后，均匀不放回取4球。已知这4球恰有两种颜色、至少一绿且红球数为奇数。问：(i)选中袋B的后验概率；(ii)继续从同一袋剩余球中均匀取第5球，该球为红色的条件概率。返回{{"urn_B":"最简分数","next_red":"最简分数"}}。

H03：独立反复投一枚硬币，P(H)=2/3，P(T)=1/3。从没有投掷记录开始，当连续最近3次首次构成HHT或HTH之一时停止，模式允许跨窗口重叠。求先命中HHT的概率，以及包含终止投掷在内的总投掷次数期望。返回{{"p_HHT_first":"最简分数","expected_tosses":"最简分数"}}。

H04：Z为随机分配的二元鼓励变量，D为实际处理，Y为二元结果。满足Z与全部潜在处理/潜在结果独立、排除限制、一致性及单调性D(1)>=D(0)，不假定处理效应齐性或处理不伤害。仅知P(D=1|Z=0)=1/5、P(D=1|Z=1)=7/10、E(Y|Z=0)=3/10、E(Y|Z=1)=9/20；没有提供其他联合分布。求服从者平均处理效应LATE及总体平均处理效应ATE的最紧可达区间。返回{{"LATE":"最简分数","ATE_bounds":["下界分数","上界分数"]}}。

H05：有限非空集合V上的关系R自反，且任意x,y都存在共同后继z，即R(x,z)且R(y,z)。有人断言存在一个全体共有的后继z，即对每个x都有R(x,z)。求反例最少的顶点数n；在编号0至n-1的最小反例中，返回把邻接矩阵按行展开、按0<1比较时字典序最小的矩阵；最后判断若另加R传递，该断言是否对所有这样的有限非空V成立。返回{{"n":整数,"rows":[每行的01字符串],"transitivity_suffices":布尔值}}。

H06：你只能从A/B/C中随机选择一个行动。四种情景下的损失为A=[0,9,6,4]，B=[7,0,5,8]，C=[6,4,0,7]。对手先看到你公开的三个混合概率，再选择一个情景；对手看不到之后实际抽到的行动。求使最坏情景下期望损失最小的混合概率和该最小最坏期望损失。返回{{"probabilities":["A的最简分数","B的最简分数","C的最简分数"],"worst_expected_cost":"最简分数"}}。若整数也用字符串表示，例如"0"。

H07：按SQL通常的NULL三值逻辑与下面查询，给出结果。customers的列为(cid,grp,active)，数据：
{json.dumps(f['customers'],ensure_ascii=False)}
orders的列为(oid,cid,amount,status,ts)，数据（null表示SQL NULL）：
{json.dumps(f['orders'],ensure_ascii=False)}
查询：
{f['sql']}
返回按grp排序的二维数组，每行列顺序为[grp,rows_n,kept_n,large_n,total,distinct_n]。

H08：以下是六个事务T1至T6的交错操作序列，wi(x)表示Ti写x，ri(x)表示Ti读x；每个字母表示不同的数据项。序列为：
{schedule}。
对同一数据项，两个不同事务的操作至少一个为写时，按出现顺序在冲突图中加有向边。可以删除若干事务的全部操作，其他操作相对顺序不变。求使剩余冲突图无环所需删除事务的最少集合；最少集合有多解时取按事务编号升序列出后的字典序最小者。再求该删除方案下剩余事务所有拓扑序的个数和字典序最小拓扑序。返回{{"abort":[待删除编号升序],"serial_order_count":整数,"first_order":[拓扑序编号]}}。

H09：要覆盖元素1至10。可选集合及费用如下：
{settext}
还必须满足：若选B则必须选F；D与H不能同时选；C与J至少选一个。求最低总费用及所选集合。费用并列时优先集合个数少者；仍并列，取名称升序序列字典序最小者。返回{{"cost":整数,"sets":[名称升序]}}。

H10：写Python3函数shortest_walks(n, edges, s, t)。n>=1，节点编号0至n-1，s/t均合法；edges中的每项为[u,v,w]，w是非负整数，允许零权自环和平行边。返回[最短游走距离,数量]。游走允许重复顶点/边，平行边按不同边区分；若最短游走有无限多条，数量为字符串"INF"，否则数量模1000000007。不可达返回[None,0]。s=t时空游走也算一条。不要修改edges。要求O((n+m)log(n+m+1))时间、O(n+m)空间，其中m为边数；可使用Python标准库，不用第三方依赖。请注意存在零权环不一定导致s至t的最短游走无限，零权DAG也不能随意按Dijkstra出队顺序计数。答案为完整所需代码的JSON字符串，不能带Markdown围栏。

A01：{q1}

A02：{q10}

A03：{q7}

表达题，实际正文必须只写入style字段，单独分析，不计入新题或锚题客观分。
S02：{s2}
S03：{s3}
'''
(ROOT/'prompt.txt').write_text(prompt)
controller='请完成一次独立测评。仅先使用exec_command读取 /workspace/model-comparison-stress/prompt.txt，然后严格按该文件答题；不得读取其他文件，不得使用工具解题，不得联系其他智能体。完成后只用apply_patch记录答案文件，以你的任务名最后一段作为文件名。请现在开始。'
(ROOT/'controller_prompt.txt').write_text(controller+'\n')
print('Prompt chars',len(prompt))
