import ast,builtins,json,sys,resource,importlib
resource.setrlimit(resource.RLIMIT_CPU,(5,5));resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,256*1024*1024))
data=json.load(sys.stdin)
try:
 tree=ast.parse(data['source'])
 modules={'collections','heapq','math','typing','functools','itertools','bisect'}
 for node in ast.walk(tree):
  if isinstance(node,ast.Import) and any(x.name not in modules for x in node.names):raise ValueError('Non-algorithm import')
  if isinstance(node,ast.ImportFrom) and (node.module not in modules or node.level):raise ValueError('Non-algorithm import')
  if isinstance(node,ast.Attribute) and node.attr.startswith('__'):raise ValueError('dunder access forbidden')
 def imp(name,*a,**kw):
  if name in modules:return importlib.import_module(name)
  raise ImportError(name)
 allowed=['abs','all','any','bool','dict','enumerate','float','int','isinstance','len','list','max','min','range','reversed','set','sorted','str','sum','tuple','zip','map','filter','next','iter','pow','Exception','ValueError','TypeError','object','__build_class__']
 env={'__builtins__':{k:getattr(builtins,k) for k in allowed},'__name__':'submission'};env['__builtins__']['__import__']=imp
 exec(compile(tree,'<submission>','exec'),env)
 outs=[]
 for i,c in enumerate(data['cases']):
  edges=[x[:] for x in c['edges']]
  try:
   got=env['shortest_walks'](c['n'],edges,c['s'],c['t'])
   passed=isinstance(got,(list,tuple)) and list(got)==c['expected'] and edges==c['edges']
   outs.append({'case':i,'group':c['group'],'passed':passed,'got':repr(got),'expected':c['expected'],'input_mutated':edges!=c['edges']})
  except Exception as e:outs.append({'case':i,'group':c['group'],'passed':False,'error':type(e).__name__+': '+str(e)})
 print(json.dumps({'outcomes':outs}))
except Exception as e:print(json.dumps({'error':type(e).__name__+': '+str(e),'outcomes':[]}))
