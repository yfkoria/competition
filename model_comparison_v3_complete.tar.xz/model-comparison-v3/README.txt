第三轮：寻找高区分度测试

最终入口：delivery/report.html（交互报告）、report.txt（纯文本）、scores.svg（可导出图）。
结果：delivery/results.csv、run_scores.csv、case_scores.csv、all_raw.jsonl。
原始源码和执行输出：stage2/raw/、stage2/evaluations/formal/。

第一阶段只完成校准。三个预指定max配置的合并结果为ARC 15/18、BBEH 16/18，均高于预设14/18阈值，原定105次正式运行没有启动。根目录formal_mixed_manifest.json与formal_arc_manifest.json是未执行的候选计划；calibration/raw保留9份答卷，calibration_decision.json记录暂停决定。根目录部分scripts为这一阶段准备，最终结果入口是stage2/scripts。

第二阶段固定Frontier-CS题目：校准47矩形背包、193 Max-2-SAT；正式0多格骨牌装箱、46作业车间调度、192图最大割。校准6份程序；正式35配置各对3题单次生成，共105份程序，每份使用8个固定输入，共840个计划程序—输入组合。八个输入共享同一程序，不能视为八个独立模型生成样本。

正式三题在本阶段模型生成前固定，不据校准胜负换题。首份实际程序跑通后，利用空槽开始固定正式源码生成，剩余校准继续完成；所有本地限时程序仍由同一锁串行执行。见stage2/formal_launch_decision.json。

执行条件：g++ 14.2.0，GNU C++17，-O2；每输入单核、2秒CPU、5秒wall、512MiB，每输出流至多8MiB。代码随机种子2026110305由提示要求，源码不予修正；模型生成温度、种子和真实推理token不可见。模型只读题面，不获所选测试输入、答案、checker和参考程序。禁用解题工具是提示约束，非硬隔离；完整worker工具轨迹不可独立核验。程序执行使用资源限制和源码审查，并非完整安全容器。

先记录可行率与编译、运行、合法性失败原因。自然质量分别是100*占用格数/外框面积、100*负载下界/makespan、100*割边/全边数。无效输出质量0，但合法低质量与无效在状态列分开。界不一定可达到，因此界比值不是已知最优解百分比。官方checker分另列，其对数刻度不是正确率；三域等权均值只是预先约定的描述性汇总，不是IQ、通用能力分或官方全榜分。不用本轮最佳模型归一化，不择优重跑，不修改模型源码。

审计证据：stage2/protocol.json、selection.json、frozen_sha256.json为111文件冻结；judge_validation_freeze.json冻结执行器及验证。40个选定baseline实例和50项控制检查通过；独立基准另检查了全部160个官方输入，见stage2/baselines/validation.json，均非模型样本。stage2/analysis/final_audit.json从保存stdout独立重算合法输出目标、界和汇总，并核验原文与冻结哈希。执行事件、实际提示、源码hash均保留。

不重跑限时程序，确定性复算保存输出：
  python stage2/scripts/audit_results.py
此脚本支持解压到其他目录后的路径映射，仅依赖Python标准库，测试版本为Python3.12.14。原始超时/退出状态由保存日志作为证据。
复算描述统计、重建报告和SVG可依次运行stage2/scripts/analyze_results.py、report.py、chart.py。stage2/scripts/validate_delivery.py还使用Node执行JavaScript语法检查；不代表浏览器交互测试。独立审阅复算脚本为stage2/scripts/independent_review_audit.py。
完整重新编译运行可用stage2/scripts/judge.py，但需把manifest/selection原绝对路径映射到解压目录，并指定新的results-root。计时搜索程序即使固定seed，也可能随硬件和迭代次数产生不同结果；新运行应单独保存，不覆盖旧证据。

只有3个正式任务、每配置每任务1次生成，不能建立稳定通用智能排序或effort因果关系。校准193与正式192有4组可还原的同底图，已记录；不同ID并非数学独立，正式选题也不据校准胜负改变。所有题目公开，不能证明模型训练未见。5.6 Sol是接口接受的未文档化请求名称，后端未核验；Luna ultra是不支持而非零分。

完整ZIP包含前两轮model-comparison、model-comparison-stress及本轮两阶段证据；前两轮写作风格答卷与盲评保留，本轮没有另加自然写作任务。排除完整多GB Frontier-CS克隆、编译ELF、缓存与旧ZIP副本，实际用于模型评测的40组输入/答案、所选题面和判题器完整保留；其余baseline验证输入可从固定commit仓库获取。源代码、题面、固定输入、stdout/stderr、checker日志、编译诊断、规则、分析均归档。

Frontier-CS GitHub仓库MIT，commit 59687e5428266a22a49cf51f981b912103bfa91d；HF另以Apache-2.0发布题面/config，不把该许可扩展到HF未含testdata。ARC-AGI-2为Apache-2.0；BBEH材料CC-BY-4.0，软件Apache-2.0。归属见各source_snapshots/ATTRIBUTION.txt、README和LICENSE。SHA256SUMS.txt与bundle_manifest.json列出包内文件哈希，archive.sha256给出ZIP哈希。
