"""Apply the predeclared calibration decision, without model-specific scores."""
import datetime
import hashlib
import json
import shutil
from pathlib import Path

base=Path(__file__).resolve().parents[1]
path=base/'analysis/calibration/summary.json'
s=json.loads(path.read_text())
assert s['ready'] and s['observed_runs']==9, 'Calibration is not complete.'
counts={k:v['correct'] for k,v in s['domains_pooled_across_configuration'].items()}
assert all(v['planned_items']==18 for v in s['domains_pooled_across_configuration'].values())
if counts['arc']>14 and counts['bbeh']>14:
    selected=None
elif 4<=counts['arc']<=14 and counts['bbeh']>14:
    selected='formal_arc_manifest.json'
else:
    selected='formal_mixed_manifest.json'
assert selected==s['selected_formal_manifest']
record={'selected_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'calibration_summary_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
        'pooled_counts_out_of_18':counts,'selected_candidate':selected,
        'difficulty_target_met':s['difficulty_target_met'],
        'reason':s['selection_reason'],
        'selection_information':'Only two domain-pooled counts, never per-model win/loss patterns.',
        'formal_inputs_preexisted_calibration':True,
        'calibration_items_excluded_from_formal':True}
if selected:
    source=base/selected
    frozen=json.loads((base/'frozen_sha256.json').read_text())['files'][selected]
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    assert digest==frozen['sha256']
    destination=base/'formal_manifest.json'
    if destination.exists():
        assert destination.read_bytes()==source.read_bytes(), 'Do not change an already selected suite.'
    else:
        shutil.copyfile(source,destination)
    record['formal_manifest_sha256']=digest
target=base/'calibration_decision.json'
assert not target.exists(), 'Decision already recorded; do not overwrite its timestamp.'
target.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(record,ensure_ascii=False,indent=2))
