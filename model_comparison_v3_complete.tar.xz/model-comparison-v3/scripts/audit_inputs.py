"""Independent reconstruction checks; never reads model answers."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
load = lambda p: json.loads(p.read_text())
gold = load(BASE / 'gold.json')['items']
checks = []
frozen = load(BASE / 'frozen_sha256.json')['files']
for name, info in frozen.items():
    assert hashlib.sha256((BASE / name).read_bytes()).hexdigest() == info['sha256'], name
checks.append({'check': 'frozen_input_hashes', 'n': len(frozen), 'pass': True})

rows = lambda grid: [''.join(map(str, row)) for row in grid]
sources = {}
for iid, item in gold.items():
    repo = 'ARC-AGI-2' if item['domain'] == 'arc' else 'bbeh'
    source = load(BASE / 'research' / repo / item['source_relative_path'])
    if item['domain'] == 'arc':
        assert item['answer'] == [rows(pair['output']) for pair in source['test']], iid
        sources[iid] = {
            'train': [{'input': rows(pair['input']), 'output': rows(pair['output'])}
                      for pair in source['train']],
            'test': [{'input': rows(pair['input'])} for pair in source['test']],
        }
    else:
        example = source['examples'][item['source_index_zero_based']]
        assert item['answer'] == example['target'], iid
        sources[iid] = example['input']
checks.append({'check': 'all_gold_targets_against_pinned_sources', 'n': len(gold), 'pass': True})

for name in ['calibration_manifest.json', 'formal_mixed_manifest.json', 'formal_arc_manifest.json']:
    manifest = load(BASE / name)
    unique_keys = {(r['model'], r['reasoning_effort'], r['pack_id']) for r in manifest['runs']}
    assert len(unique_keys) == manifest['run_count']
    observed_ids = set()
    for pack in manifest['packs']:
        text = Path(pack['pack_path']).read_text()
        assert hashlib.sha256(text.encode()).hexdigest() == pack['sha256']
        sections = text.split('\n\n题号：')[1:]
        assert len(sections) == 4
        ids = []
        for section in sections:
            iid, _, body = section.split('\n', 2)
            ids.append(iid)
            observed_ids.add(iid)
            if gold[iid]['domain'] == 'arc':
                assert json.loads(body.strip()) == sources[iid], (name, iid)
            else:
                assert body.strip() == sources[iid].strip(), (name, iid)
        assert ids == pack['item_ids']
    assert len(observed_ids) == 12
    expected_split = 'calibration' if name.startswith('calibration') else 'holdout'
    assert all(gold[iid]['split'] == expected_split for iid in observed_ids)
    checks.append({'check': name + ': source-faithful packs, unique runs, split isolation',
                   'runs': len(unique_keys), 'unique_items': len(observed_ids), 'pass': True})

result = {'auditor': 'root independent reconstruction; no model outputs read',
          'all_pass': True, 'checks': checks}
(BASE / 'analysis/input_audit.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
