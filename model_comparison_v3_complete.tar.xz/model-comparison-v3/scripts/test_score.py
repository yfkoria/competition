#!/usr/bin/env python3
"""Focused evaluator checks, independent of any candidate answer."""
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("v3_score", HERE / "score.py")
score = importlib.util.module_from_spec(spec)
spec.loader.exec_module(score)


class ScoringTests(unittest.TestCase):
    def test_arc_exact_multiple_tests(self):
        target = [["12", "34"], ["567"]]
        self.assertEqual(score.score_answer(target, target, "arc")["correct"], 1)
        wrong = [["12", "34"], ["568"]]
        scored = score.score_answer(wrong, target, "arc")
        self.assertEqual(scored["correct"], 0)
        self.assertEqual(scored["arc_cells_correct"], 6)
        self.assertEqual(scored["arc_cells_total"], 7)

    def test_arc_semantic_representation(self):
        target = [["12", "34"]]
        for equivalent in (target, [[[1, 2], [3, 4]]], ["12", "34"], [[1, 2], [3, 4]]):
            self.assertEqual(score.score_answer(equivalent, target, "arc")["correct"], 1)
        for wrong in ([["13", "24"]], [["1234"]], [["12", "34"], ["12", "34"]]):
            self.assertEqual(score.score_answer(wrong, target, "arc")["correct"], 0)

    def test_arc_shape_not_overlap(self):
        result = score.score_answer([["12"]], [["12", "34"]], "arc")
        self.assertEqual(result["arc_cells_correct"], 0)

    def test_empty_and_numeric_zero(self):
        for empty in (None, "", "  ", [], {}):
            self.assertEqual(score.score_answer(empty, "0", "bbeh")["status"], "abstention_empty")
        for valid_zero in (0, 0.0, "0"):
            result = score.score_answer(valid_zero, "0", "bbeh")
            self.assertEqual(result["correct"], 1)
            self.assertTrue(result["substantive"])
        result = score.score_answer(0, "1", "bbeh")
        self.assertTrue(result["substantive"])
        self.assertEqual(result["status"], "incorrect")

    def test_official_bbeh_normalization(self):
        samples = [("The final answer is: \\boxed{4}.", "4", True),
                   ("The final answer is: (A)", "a", True),
                   ("The answer is: **25**\nExplanation", "25.0", True),
                   ("2, 3, 4", "2,3,4", True),
                   ("2, 3, 4", "2,3,5", False),
                   ("0", "1", False)]
        for sample, target, expected in samples:
            self.assertEqual(score.BBEH_SCORE(sample, target), expected)
            self.assertEqual(score.score_answer(sample, target, "bbeh")["correct"], int(expected))

    def test_raw_preserved_and_fences(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "answer.json"
            raw = '```json\n{"answers": {"x": {"answer": "0", "confidence": 75}}}\n```\n'
            path.write_text(raw)
            obj, status, repaired, digest = score.parse_raw(path)
            self.assertEqual(status, "parsed")
            self.assertTrue(repaired)
            self.assertEqual(path.read_text(), raw)
            self.assertEqual(obj["answers"]["x"]["answer"], "0")
            self.assertEqual(digest, score.sha256(path))

    def test_infra_vs_refusal(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "answer.json"
            self.assertEqual(score.parse_raw(path)[1], "missing_file")
            path.with_suffix(".refusal.txt").write_text("I decline this task.")
            self.assertEqual(score.parse_raw(path)[1], "observed_refusal")

    def test_every_selected_gold_and_blank(self):
        gold_path = score.BASE / "gold.json"
        if not gold_path.exists():
            self.skipTest("prepare.py has not yet materialized gold.json")
        gold = json.loads(gold_path.read_text())
        self.assertGreater(len(gold["items"]), 0)
        for item_id, item in gold["items"].items():
            result = score.score_answer(item["answer"], item["answer"], item["domain"])
            self.assertEqual(result["correct"], 1, item_id)
            blank = score.score_answer(None, item["answer"], item["domain"])
            self.assertEqual(blank["correct"], 0, item_id)


if __name__ == "__main__":
    unittest.main(verbosity=2)
