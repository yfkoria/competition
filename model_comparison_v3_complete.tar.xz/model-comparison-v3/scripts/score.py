#!/usr/bin/env python3
"""Deterministic, non-mutating scoring for the third model-comparison round.

Calibration prints pooled domain results only. Formal reporting labels all
model identities as requested identifiers, not attested backend identities.
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import hashlib
import importlib.util
import io
import itertools
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parents[1]
BOOTSTRAP_SEED = 2026110304
BOOTSTRAP_REPLICATES = 20000
COMMON_EFFORTS = ["low", "medium", "high", "xhigh", "max"]
ALL_EFFORTS = COMMON_EFFORTS + ["ultra"]
TOP_MODELS = ["gpt-6-astra", "gpt-6.1-sol", "gpt-6-sol"]
ABSTENTION_STRINGS = {
    "i don't know", "i do not know", "abstain", "no answer", "not answered",
    "不知道", "未作答", "无法确定", "无法作答", "放弃作答",
}


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def official_bbeh_scorer():
    path = BASE / "source_snapshots/bbeh/bbeh/evaluate.py"
    spec = importlib.util.spec_from_file_location("v3_official_bbeh_evaluate", path)
    module = importlib.util.module_from_spec(spec)
    # The unmodified official source prints eight self-examples at import.
    with contextlib.redirect_stdout(io.StringIO()):
        spec.loader.exec_module(module)
    return module.evaluate_correctness, str(path), sha256(path)


BBEH_SCORE, BBEH_SCORER_PATH, BBEH_SCORER_SHA256 = official_bbeh_scorer()


def canonical_grid(value):
    """Accept row strings or an equivalent matrix of integer color values."""
    if not isinstance(value, list) or not value:
        return None
    rows = []
    for row in value:
        if isinstance(row, str) and re.fullmatch(r"[0-9]+", row):
            rows.append(row)
        elif isinstance(row, list) and row and all(
            type(cell) is int and 0 <= cell <= 9 for cell in row
        ):
            rows.append("".join(str(cell) for cell in row))
        else:
            return None
    if len({len(row) for row in rows}) != 1:
        return None
    return rows


def canonical_arc(value, n_tests):
    """Return (grids, representation repair). No grid content is repaired."""
    if not isinstance(value, list) or not value:
        return None, False
    grids = [canonical_grid(grid) for grid in value]
    if all(grid is not None for grid in grids):
        canonical = grids
        return canonical, canonical != value
    if n_tests == 1:
        grid = canonical_grid(value)
        if grid is not None:
            return [grid], True
    return None, False


def empty_answer(value):
    if value is None or value == "" or value == [] or value == {}:
        return True
    return isinstance(value, str) and not value.strip()


def explicit_abstention(value):
    return isinstance(value, str) and value.strip().lower().rstrip(".。") in ABSTENTION_STRINGS


def arc_cells(prediction, target):
    """Supplement only: mismatched shapes receive zero on affected target grids.

    Extra predicted grids invalidate this supplement completely. A wrong-size
    prediction never receives credit merely for an overlapping crop.
    """
    total = sum(len(row) for grid in target for row in grid)
    if prediction is None or len(prediction) > len(target):
        return 0, total
    matches = 0
    for pred, gold in zip(prediction, target):
        if len(pred) != len(gold) or any(len(a) != len(b) for a, b in zip(pred, gold)):
            continue
        matches += sum(a == b for prow, grow in zip(pred, gold) for a, b in zip(prow, grow))
    return matches, total


def score_answer(answer, target, domain, present=True):
    result = {
        "correct": 0, "substantive": False, "complete_answer_structure": False,
        "answer_format_recovered": False, "status": "missing_answer",
        "arc_cells_correct": None, "arc_cells_total": None, "arc_cell_accuracy": None,
    }
    if domain == "arc":
        _, total = arc_cells(None, target)
        result.update(arc_cells_correct=0, arc_cells_total=total, arc_cell_accuracy=0.0)
    if not present:
        return result
    if empty_answer(answer):
        result["status"] = "abstention_empty"
        return result
    if explicit_abstention(answer):
        result["status"] = "abstention_explicit"
        return result
    if domain == "arc":
        pred, repaired = canonical_arc(answer, len(target))
        if pred is None:
            result["status"] = "invalid_answer_format"
            return result
        result.update(substantive=True, complete_answer_structure=len(pred) == len(target),
                      answer_format_recovered=repaired)
        result["correct"] = int(pred == target)
        matches, total = arc_cells(pred, target)
        result.update(arc_cells_correct=matches, arc_cells_total=total,
                      arc_cell_accuracy=matches / total if total else None)
        result["status"] = "correct" if result["correct"] else (
            "incorrect" if len(pred) == len(target) else "incomplete_test_predictions")
    elif domain == "bbeh":
        if not isinstance(answer, (str, int, float)) or isinstance(answer, bool):
            result["status"] = "invalid_answer_format"
            return result
        pred = str(answer)
        result.update(substantive=True, complete_answer_structure=True,
                      answer_format_recovered=not isinstance(answer, str))
        result["correct"] = int(BBEH_SCORE(pred, str(target)))
        result["status"] = "correct" if result["correct"] else "incorrect"
    else:
        raise ValueError(f"Unknown domain: {domain}")
    return result


def parse_raw(path):
    """Read exact bytes; never rewrite them. Recover only whole-file fences."""
    path = Path(path)
    if not path.exists():
        refusal = path.with_suffix(".refusal.txt")
        if refusal.exists():
            return None, "observed_refusal", False, sha256(refusal)
        return None, "missing_file", False, None
    original = path.read_text(encoding="utf-8")
    repaired = False
    try:
        obj = json.loads(original)
    except json.JSONDecodeError:
        match = re.fullmatch(r"\s*```(?:json)?\s*\n([\s\S]*?)\n```\s*", original)
        if not match:
            return None, "invalid_json", False, sha256(path)
        try:
            obj = json.loads(match.group(1))
            repaired = True
        except json.JSONDecodeError:
            return None, "invalid_json", False, sha256(path)
    if not isinstance(obj, dict) or not isinstance(obj.get("answers"), dict):
        return obj, "invalid_envelope", repaired, sha256(path)
    return obj, "parsed", repaired, sha256(path)


def score_runs(manifest, gold):
    rows, raw_records, run_records = [], [], []
    for run in manifest["runs"]:
        raw_path = Path(run["output_path"])
        data, raw_status, repaired, raw_hash = parse_raw(raw_path)
        rr = dict(run)
        rr.update(raw_status=raw_status, raw_sha256=raw_hash, file_format_recovered=repaired)
        run_records.append(rr)
        observed_path = raw_path if raw_path.exists() else raw_path.with_suffix(".refusal.txt")
        raw_records.append({"run": run, "raw_status": raw_status, "raw_sha256": raw_hash,
                            "observed_artifact_path": str(observed_path) if observed_path.exists() else None,
                            "raw_text": observed_path.read_text(encoding="utf-8") if observed_path.exists() else None,
                            "parsed": data})
        for item_id in run["item_ids"]:
            item = gold["items"][item_id]
            row = {key: run.get(key) for key in ("run_id", "model", "reasoning_effort", "pack_id")}
            row.update(item_id=item_id, domain=item["domain"], family=item.get("family"),
                       source_id=item.get("source_id"), output_path=str(raw_path), raw_status=raw_status,
                       file_format_recovered=repaired, raw_sha256=raw_hash)
            envelope = data.get("answers", {}) if isinstance(data, dict) else {}
            entry = envelope.get(item_id) if isinstance(envelope, dict) else None
            valid_entry = isinstance(entry, dict)
            present = valid_entry and "answer" in entry
            answer = entry.get("answer") if valid_entry else None
            row.update(score_answer(answer, item["answer"], item["domain"], present))
            if raw_status != "parsed":
                row["status"] = raw_status
            elif item_id in envelope and not valid_entry:
                row["status"] = "invalid_entry_format"
            confidence = entry.get("confidence") if valid_entry else None
            confidence_ok = (type(confidence) in (int, float) and np.isfinite(confidence)
                             and 0 <= confidence <= 100)
            row.update(confidence=confidence if confidence_ok else None,
                       confidence_valid=bool(confidence_ok),
                       brier=(confidence / 100 - row["correct"]) ** 2 if confidence_ok else None)
            rows.append(row)
    return rows, raw_records, run_records


def write_csv(path, rows):
    if not rows:
        Path(path).write_text("", encoding="utf-8")
        return
    fields = list(dict.fromkeys(key for row in rows for key in row))
    with Path(path).open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def summary_group(rows):
    n = len(rows)
    substantive = sum(row["substantive"] for row in rows)
    correct = sum(row["correct"] for row in rows)
    states = Counter(row["status"] for row in rows)
    confidences = [row for row in rows if row["confidence_valid"]]
    return {
        "planned_items": n, "correct": correct, "score_pct": 100 * correct / n if n else None,
        "substantive_answers": substantive, "coverage_pct": 100 * substantive / n if n else None,
        "conditional_accuracy_pct": 100 * correct / substantive if substantive else None,
        "complete_structures": sum(row["complete_answer_structure"] for row in rows),
        "status_counts": dict(sorted(states.items())),
        "confidence_valid_n": len(confidences),
        "brier_mean": float(np.mean([row["brier"] for row in confidences])) if confidences else None,
        "complete_infrastructure": states.get("missing_file", 0) == 0,
    }


def calibration_analysis(rows, run_records):
    domains = {domain: summary_group([r for r in rows if r["domain"] == domain])
               for domain in sorted({r["domain"] for r in rows})}
    ready = all(r["raw_status"] != "missing_file" for r in run_records)
    arc = domains.get("arc", {}).get("correct", 0)
    bbeh = domains.get("bbeh", {}).get("correct", 0)
    # The decision is frozen before seeing calibration outcomes. It is a coarse
    # difficulty screen, not an estimate of item discrimination parameters.
    ceiling_pause = arc > 14 and bbeh > 14
    selected = (None if ceiling_pause else "formal_arc_manifest.json"
                if 4 <= arc <= 14 and bbeh > 14 else "formal_mixed_manifest.json")
    both_in_target = 4 <= arc <= 14 and 4 <= bbeh <= 14
    arc_replacement = 4 <= arc <= 14 and bbeh > 14
    return {
        "phase": "calibration", "planned_runs": len(run_records),
        "observed_runs": sum(r["raw_status"] != "missing_file" for r in run_records),
        "ready": ready, "domains_pooled_across_configuration": domains,
        "difficulty_target_met": both_in_target or arc_replacement,
        "stage_one_ceiling_pause": ceiling_pause,
        "selected_formal_manifest": selected if ready else None,
        "selection_reason": ("Both domains at ceiling: pause formal execution; at most one newly registered second calibration stage"
                             if ceiling_pause else "ARC in target, BBEH ceiling: use preregistered ARC reserve"
                             if arc_replacement else "Use preregistered mixed set"),
        "warning": "Calibration items never contribute to formal scores. Do not inspect model winners to select tasks.",
    }


def bootstrap_interval(values, samples):
    arr = np.asarray(values, dtype=float)
    estimates = arr[samples].mean(axis=1)
    low, high = np.quantile(estimates, [0.025, 0.975])
    return [float(100 * low), float(100 * high)]


def exact_discordant_test(a_only, b_only):
    from scipy.stats import binomtest
    n = a_only + b_only
    return float(binomtest(a_only, n, 0.5, alternative="two-sided").pvalue) if n else 1.0


def holm_adjust(comparisons):
    order = sorted(range(len(comparisons)), key=lambda k: comparisons[k]["discordant_binomial_p_raw"])
    running = 0.0
    for rank, idx in enumerate(order):
        running = max(running, min(1.0, (len(order) - rank) * comparisons[idx]["discordant_binomial_p_raw"]))
        comparisons[idx]["discordant_binomial_p_holm"] = running


def formal_analysis(rows, run_records):
    by_config = defaultdict(list)
    for row in rows:
        by_config[(row["model"], row["reasoning_effort"])].append(row)
    config_rows = []
    for (model, effort), rs in sorted(by_config.items()):
        group = summary_group(rs)
        result = {"model": model, "reasoning_effort": effort, **group}
        result["received_runs"] = sum(r["raw_status"] != "missing_file" for r in run_records
                                      if r["model"] == model and r["reasoning_effort"] == effort)
        for domain in ("arc", "bbeh"):
            sub = summary_group([r for r in rs if r["domain"] == domain])
            result[f"{domain}_correct"] = sub["correct"]
            result[f"{domain}_n"] = sub["planned_items"]
            result[f"{domain}_pct"] = sub["score_pct"]
        config_rows.append(result)

    item_ids = sorted({r["item_id"] for r in rows})
    n_items = len(item_ids)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    samples = rng.integers(0, n_items, (BOOTSTRAP_REPLICATES, n_items))
    scores = {cfg: {r["item_id"]: r["correct"] for r in rs} for cfg, rs in by_config.items()}
    ready = all(r["raw_status"] != "missing_file" for r in run_records)
    same_items = all(set(v) == set(item_ids) for v in scores.values())
    if not same_items:
        raise ValueError("Every configuration must have the same formal item IDs")

    common_means = []
    for model in sorted({m for m, _ in by_config}):
        present = [(model, e) for e in COMMON_EFFORTS if (model, e) in scores]
        values = [np.mean([scores[c][item] for c in present]) for item in item_ids]
        common_means.append({
            "model": model, "efforts": COMMON_EFFORTS, "effort_count": len(present),
            "mean_pct": float(100 * np.mean(values)),
            "question_bootstrap_95pct_ci": bootstrap_interval(values, samples),
            "per_item_mean": dict(zip(item_ids, map(float, values))),
            "complete_infrastructure": all(row["raw_status"] != "missing_file" for row in rows if row["model"] == model),
        })

    # Six planned comparisons: the three previously saturated model requests at
    # max and ultra separately. These are exploratory, not causal effort effects.
    comparisons = []
    for effort in ("max", "ultra"):
        for left, right in itertools.combinations(TOP_MODELS, 2):
            if (left, effort) not in scores or (right, effort) not in scores:
                continue
            av = np.array([scores[(left, effort)][item] for item in item_ids])
            bv = np.array([scores[(right, effort)][item] for item in item_ids])
            a_only = int(np.sum((av == 1) & (bv == 0)))
            b_only = int(np.sum((av == 0) & (bv == 1)))
            comparisons.append({
                "left_model": left, "right_model": right, "reasoning_effort": effort,
                "n_items": n_items, "left_only_correct": a_only, "right_only_correct": b_only,
                "both_correct": int(np.sum((av == 1) & (bv == 1))),
                "both_wrong": int(np.sum((av == 0) & (bv == 0))),
                "difference_percentage_points": float(100 * np.mean(av - bv)),
                "paired_question_bootstrap_95pct_ci": bootstrap_interval(av - bv, samples),
                "discordant_binomial_p_raw": exact_discordant_test(a_only, b_only),
                "left_only_items": [item for i, item in enumerate(item_ids) if av[i] and not bv[i]],
                "right_only_items": [item for i, item in enumerate(item_ids) if bv[i] and not av[i]],
            })
    holm_adjust(comparisons)

    effort_changes = []
    for model in sorted({m for m, _ in scores}):
        available = [effort for effort in ALL_EFFORTS if (model, effort) in scores]
        for lo, hi in zip(available, available[1:]):
            delta = [scores[(model, hi)][item] - scores[(model, lo)][item] for item in item_ids]
            effort_changes.append({"model": model, "from_effort": lo, "to_effort": hi,
                                   "net_more_tasks_solved": sum(delta),
                                   "gained_items": [item for item, d in zip(item_ids, delta) if d == 1],
                                   "lost_items": [item for item, d in zip(item_ids, delta) if d == -1]})
    items = [{"item_id": item, "domain": next(r["domain"] for r in rows if r["item_id"] == item),
              **summary_group([r for r in rows if r["item_id"] == item])} for item in item_ids]
    return {
        "phase": "formal", "ready": ready, "planned_runs": len(run_records),
        "observed_runs": sum(r["raw_status"] != "missing_file" for r in run_records),
        "n_configurations": len(by_config), "n_distinct_items": n_items,
        "overall": summary_group(rows), "configurations": config_rows, "item_statistics": items,
        "common_effort_model_means": common_means, "planned_top_pairs": comparisons,
        "adjacent_effort_changes": effort_changes,
        "bootstrap": {"seed": BOOTSTRAP_SEED, "replicates": BOOTSTRAP_REPLICATES,
                      "unit": "same item ID resampled jointly across compared configurations",
                      "interval": "percentile 95%; item sampling uncertainty only, not generation variability",
                      "limitations": "12 items, no same-item generation repeats; 4 items share a pack. Item bootstrap does not model within-pack dependence, backend/version variability, or broader task sampling. Intervals are exploratory and can be optimistic."},
        "identity_limit": "Model and effort are requested identifiers; backend weights, actual reasoning budget, seeds and routing are unverified. gpt-5.6-sol is an undocumented accepted request. Luna ultra is unsupported, not scored zero.",
        "incomplete_warning": None if ready else "Provisional only: missing infrastructure outputs are zero in planned denominators; do not interpret as model errors or use for rankings.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=["calibration", "formal"], required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--gold", type=Path, default=BASE / "gold.json")
    parser.add_argument("--output-dir", type=Path)
    args = parser.parse_args()
    manifest_path = args.manifest or BASE / ("calibration_manifest.json" if args.phase == "calibration" else "formal_manifest.json")
    output_dir = args.output_dir or BASE / "analysis" / args.phase
    output_dir.mkdir(parents=True, exist_ok=True)
    manifest, gold = read_json(manifest_path), read_json(args.gold)
    rows, raw_records, run_records = score_runs(manifest, gold)
    summary = calibration_analysis(rows, run_records) if args.phase == "calibration" else formal_analysis(rows, run_records)
    summary["inputs"] = {"manifest_path": str(manifest_path), "manifest_sha256": sha256(manifest_path),
                         "gold_path": str(args.gold), "gold_sha256": sha256(args.gold),
                         "score_script_sha256": sha256(__file__), "bbeh_scorer_path": BBEH_SCORER_PATH,
                         "bbeh_scorer_sha256": BBEH_SCORER_SHA256}
    write_json(output_dir / "summary.json", summary)
    write_json(output_dir / "item_scores.json", rows)
    write_json(output_dir / "run_status.json", run_records)
    write_csv(output_dir / "item_scores.csv", rows)
    with (output_dir / "all_raw.jsonl").open("w", encoding="utf-8") as f:
        for record in raw_records:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    if args.phase == "formal":
        flat_configs = [{key: value for key, value in row.items() if not isinstance(value, (dict, list))}
                        for row in summary["configurations"]]
        write_csv(output_dir / "results.csv", flat_configs)
        print(json.dumps({"ready": summary["ready"], "planned_runs": summary["planned_runs"],
                          "observed_runs": summary["observed_runs"], "n_configurations": summary["n_configurations"],
                          "n_distinct_items": summary["n_distinct_items"], "output_dir": str(output_dir)}, ensure_ascii=False))
    else:
        print(json.dumps({key: value for key, value in summary.items() if key != "inputs"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
