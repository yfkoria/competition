"""Archive all three rounds, preserving source evidence and excluding cache/old zips."""
import hashlib
import json
import zipfile
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
ROOT=BASE.parent
summary=json.loads((BASE/'stage2/evaluations/formal/summary.json').read_text())
audit=json.loads((BASE/'stage2/analysis/final_audit.json').read_text())
assert summary['completed_code_samples']==105 and audit['all_pass']
output=BASE/'delivery'
archive=output/'model_comparison_v3_complete.zip'
checksum_file=output/'SHA256SUMS.txt'
bundle_file=output/'bundle_manifest.json'
files=[]
for dirname in ['model-comparison','model-comparison-stress','model-comparison-v3']:
    for path in sorted((ROOT/dirname).rglob('*')):
        relative=path.relative_to(ROOT)
        if not path.is_file() or '.git' in path.parts or '__pycache__' in path.parts or '_build' in path.parts:continue
        if path.is_relative_to(BASE/'research/Frontier-CS'):continue
        if path.name=='.judge-serial.lock':continue
        with path.open('rb') as stream:
            if stream.read(4)==b'\x7fELF':continue
        if path.suffix in ['.zip','.pyc'] or path in [checksum_file,bundle_file,output/'archive.sha256']:continue
        if 'replay' in path.relative_to(ROOT/dirname).parts:continue
        files.append((path,relative.as_posix()))
records=[{'path':name,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
         for path,name in files]
checksum_file.write_text(''.join(f"{r['sha256']}  {r['path']}\n" for r in records))
bundle={'purpose':'All original artifacts from three rounds; no candidate output rewritten.',
        'omitted':'Full multi-GB Frontier-CS clone (selected immutable snapshots included), compiled ELF files/_build directories, Git internals, Python caches, earlier ZIP duplicates, replay outputs, this manifest/checksum file self-hashes.',
        'files':records}
bundle_file.write_text(json.dumps(bundle,ensure_ascii=False,indent=2)+'\n')
files.extend([(checksum_file,checksum_file.relative_to(ROOT).as_posix()),
              (bundle_file,bundle_file.relative_to(ROOT).as_posix())])
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,name in files:z.write(path,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist())==len(files)
    for r in records:
        assert hashlib.sha256(z.read(r['path'])).hexdigest()==r['sha256'],r['path']
digest=hashlib.sha256(archive.read_bytes()).hexdigest()
(output/'archive.sha256').write_text(digest+'  '+archive.name+'\n')
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':digest},indent=2))
