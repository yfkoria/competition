"""Post-score mechanical error descriptions; never change primary scores."""
import json
from collections import Counter
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
load=lambda p:json.loads(p.read_text())
gold=load(BASE/'gold.json')['items']
rows=load(BASE/'analysis/formal/item_scores.json')
raw=[json.loads(s) for s in (BASE/'analysis/formal/all_raw.jsonl').read_text().splitlines()]
data={r['run']['run_id']:r.get('parsed') for r in raw}

def canonical_grid(value):
    if not isinstance(value,list) or not value:return None
    out=[]
    for row in value:
        if isinstance(row,str) and row and all(x in '0123456789' for x in row):out.append(row)
        elif isinstance(row,list) and row and all(type(x) is int and 0<=x<=9 for x in row):out.append(''.join(map(str,row)))
        else:return None
    return out if len({len(x) for x in out})==1 else None

def canonical_arc(value,n):
    if not isinstance(value,list) or not value:return None
    result=[canonical_grid(x) for x in value]
    if all(x is not None for x in result):return result
    single=canonical_grid(value)
    return [single] if n==1 and single is not None else None

arc=[];bbeh=[]
for row in rows:
    obj=data.get(row['run_id']) or {}
    entry=obj.get('answers',{}).get(row['item_id'],{})
    entry=entry if isinstance(entry,dict) else {}
    pred=entry.get('answer');g=gold[row['item_id']];target=g['answer']
    record={k:row[k] for k in ['run_id','model','reasoning_effort','item_id','status','correct','confidence']}
    record['rationale']=entry.get('rationale')
    if row['domain']=='bbeh':
        if not row['correct']:
            record.update(prediction=pred,reference=target,family=g['family'])
            bbeh.append(record)
        continue
    canonical=canonical_arc(pred,len(target))
    if canonical is None:record['error_kind']='unanswered_or_unparseable'
    elif len(canonical)!=len(target):record['error_kind']='wrong_number_of_test_predictions'
    else:
        same_shapes=all(len(p)==len(t) and len(p[0])==len(t[0]) for p,t in zip(canonical,target))
        record['test_outputs_correct']=sum(p==t for p,t in zip(canonical,target))
        record['test_outputs_total']=len(target)
        record['same_shapes']=same_shapes
        if not same_shapes:record['error_kind']='wrong_grid_shape'
        else:
            differences=[{'test':i,'row':r,'column':c,'prediction':a,'target':b}
                         for i,(pp,tt) in enumerate(zip(canonical,target))
                         for r,(pr,tr) in enumerate(zip(pp,tt))
                         for c,(a,b) in enumerate(zip(pr,tr)) if a!=b]
            record['wrong_cells']=len(differences)
            record['total_cells']=sum(len(t)*len(t[0]) for t in target)
            record['first_100_differences_zero_based']=differences[:100]
            record['error_kind']='correct' if not differences else 'one_cell_wrong' if len(differences)==1 else 'multiple_cells_wrong'
    arc.append(record)

out=BASE/'analysis'
(out/'arc_error_diagnostics.json').write_text(json.dumps({'counts':dict(Counter(x['error_kind'] for x in arc)),
    'caution':'Descriptions of output differences, not proven causes. Cell matches often reflect unchanged background; not a replacement for exact task success.',
    'items':arc},ensure_ascii=False,indent=2)+'\n')
(out/'bbeh_wrong_answers.json').write_text(json.dumps(bbeh,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'arc_error_kinds':dict(Counter(x['error_kind'] for x in arc)),
                  'bbeh_not_passed':len(bbeh)},ensure_ascii=False))
