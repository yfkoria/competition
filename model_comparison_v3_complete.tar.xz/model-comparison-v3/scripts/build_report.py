"""Build a self-contained Chinese HTML report from frozen V3 artifacts."""
import csv
import hashlib
import html
import json
import shutil
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
read = lambda name: json.loads((BASE / name).read_text())
summary = read('analysis/formal/summary.json')
assert summary['ready'], 'Do not publish partial results as complete.'
scores = read('analysis/formal/item_scores.json')
gold = read('gold.json')['items']
manifest = read('formal_manifest.json')
calibration = read('analysis/calibration/summary.json')
decision = read('calibration_decision.json')
notes = read('analysis/report_notes.json')
raw = [json.loads(line) for line in (BASE / 'analysis/formal/all_raw.jsonl').read_text().splitlines()]
raw_by_id = {row['run']['run_id']: row for row in raw}
models = ['gpt-6-astra','gpt-6.1-sol','gpt-6-sol','gpt-6.1-terra','gpt-6-luna','gpt-5.6-sol']
efforts = ['low','medium','high','xhigh','max','ultra']
labels = dict(zip(models, ['6 Astra','6.1 Sol','6 Sol','6.1 Terra','6 Luna','5.6 Sol*']))
out = BASE / 'delivery'
out.mkdir(exist_ok=True)
for source, target in [('analysis/formal/results.csv','results.csv'),
                       ('analysis/formal/item_scores.csv','item_scores.csv'),
                       ('analysis/formal/all_raw.jsonl','all_raw.jsonl'),
                       ('analysis/calibration/all_raw.jsonl','calibration_raw.jsonl')]:
    shutil.copyfile(BASE / source, out / target)

def e(value):
    return html.escape(str(value))

configs = {(r['model'],r['reasoning_effort']):r for r in summary['configurations']}
table = '<table class="matrix"><thead><tr><th>请求模型</th>'+''.join(f'<th>{x}</th>' for x in efforts)+'</tr></thead><tbody>'
for model in models:
    table += '<tr><th>'+e(labels[model])+'</th>'
    for effort in efforts:
        r = configs.get((model, effort))
        if r:
            pct = r['score_pct']
            table += f'<td><button class="heat" style="--p:{pct/100:.4f}" data-model="{e(model)}" data-effort="{effort}"><b>{r["correct"]}/{r["planned_items"]}</b><small>{pct:.1f}%</small></button></td>'
        else:
            table += '<td class="na">不支持</td>'
    table += '</tr>'
table += '</tbody></table>'

means = {r['model']:r for r in summary['common_effort_model_means']}
mean_table = '<table><thead><tr><th>请求模型</th><th>共同五档均分</th><th>题目重采样 95% 区间</th></tr></thead><tbody>'
for model in models:
    r = means[model]
    ci = r['question_bootstrap_95pct_ci']
    mean_table += f'<tr><th>{e(labels[model])}</th><td>{r["mean_pct"]:.1f}%</td><td>{ci[0]:.1f} — {ci[1]:.1f}%</td></tr>'
mean_table += '</tbody></table>'
pair_table = '<table><thead><tr><th>档位 / 配对</th><th>左独对 : 右独对</th><th>同对 / 同错</th><th>分差及题目重采样区间</th><th>Holm p</th></tr></thead><tbody>'
for r in summary['planned_top_pairs']:
    ci = r['paired_question_bootstrap_95pct_ci']
    pair_table += f'<tr><td>{r["reasoning_effort"]} · {labels[r["left_model"]]} / {labels[r["right_model"]]}</td><td>{r["left_only_correct"]} : {r["right_only_correct"]}</td><td>{r["both_correct"]} / {r["both_wrong"]}</td><td>{r["difference_percentage_points"]:+.1f} pp [{ci[0]:+.1f}, {ci[1]:+.1f}]</td><td>{r["discordant_binomial_p_holm"]:.3f}</td></tr>'
pair_table += '</tbody></table>'

body_notes = ''.join('<h2>'+e(section['title'])+'</h2>'+''.join('<p>'+e(t)+'</p>' for t in section['paragraphs']) for section in notes['sections'])
item_ids = sorted({r['item_id'] for r in scores})
dataset = {
    'summary':summary, 'scores':scores, 'gold':{k:gold[k] for k in item_ids},
    'raw':raw_by_id, 'labels':labels, 'models':models, 'efforts':efforts,
    'packs':{p['pack_id']:Path(p['pack_path']).read_text() for p in manifest['packs']},
    'runs':{r['run_id']:r for r in manifest['runs']},
}
payload = json.dumps(dataset, ensure_ascii=False).replace('<','\\u003c')
template = r'''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>第三轮模型对比：困难公开题追加测试</title><style>
:root{font:16px/1.7 system-ui,-apple-system,"Noto Sans CJK SC",sans-serif;color:#193442;background:#f3f6f7}body{margin:0}main{max-width:1160px;margin:auto;padding:36px 24px 70px}h1{font-size:32px;line-height:1.3;margin:10px 0 16px}h2{font-size:23px;margin:32px 0 12px}h3{font-size:18px}.kicker{color:#496d7d;font-size:13px;letter-spacing:.12em}.lead{font-size:19px;max-width:990px}.card,section{background:white;border:1px solid #d9e3e7;border-radius:14px;padding:22px;margin:18px 0}.muted,small{color:#5c717c}.metrics{display:flex;gap:16px;flex-wrap:wrap}.metric{flex:1;min-width:150px;background:#e9f1f3;padding:16px;border-radius:10px}.metric b{display:block;font-size:26px}.scroll{overflow:auto}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th,td{border-bottom:1px solid #e4eaed;padding:10px 12px;text-align:left}thead{color:#49616d}th{white-space:nowrap}button,select{font:inherit;cursor:pointer;border:1px solid #bdd0d9;border-radius:7px;padding:7px 12px;background:white;color:inherit}button:hover{outline:2px solid #f2b95d}.matrix td{padding:5px}.heat{width:100%;min-width:88px;background:color-mix(in srgb,#359a95 calc(var(--p)*70%),#f0f4f4);padding:13px 8px}.heat b,.heat small{display:block;color:#123a3c}.na{color:#829098;text-align:center}.filters{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.comparison{display:grid;grid-template-columns:1fr 1fr;gap:18px}.grid{display:inline-grid;border:1px solid #70818b;margin:4px 12px 10px 0;vertical-align:top}.pixel{width:14px;height:14px;box-sizing:border-box;border:.3px solid #ffffff20}.grids{overflow:auto}.status{padding:8px 13px;border-radius:6px;background:#edf1f3}.correct{background:#d9f0e7}.wrong{background:#fbe6df}pre{white-space:pre-wrap;word-break:break-word;font:13px/1.6 ui-monospace,monospace;background:#f4f6f7;border-radius:8px;padding:14px;max-height:530px;overflow:auto}a{color:#076b8d}details{margin:12px 0}footer{margin-top:32px;color:#5b707a;font-size:14px}@media(max-width:700px){main{padding:20px 12px}h1{font-size:26px}.comparison{grid-template-columns:1fr}.card,section{padding:15px}.pixel{width:10px;height:10px}}
</style><main><div class="kicker">LOCAL EXPLORATORY BENCHMARK · 2026-11-03</div><h1>换用困难公开题，检查顶档差距</h1>
<p class="lead">__LEAD__</p><div class="metrics"><div class="metric"><b>35</b>可运行模型 × 思考档位</div><div class="metric"><b>12</b>正式独立题目</div><div class="metric"><b>105</b>全新答题上下文</div><div class="metric"><b>420</b>逐题结果</div></div>
<p class="muted">__SUITE__。每份题包 4 题；每题单次作答。分数是这份公开子集上的正确率，不是 IQ 或官方排行榜分数。</p>
<section><h2>完整结果</h2><p>点击任一分数可查看该配置的原始答案。每格显示解出题数 / 12；更深颜色表示正确率更高。</p><div class="scroll">__MATRIX__</div><p class="muted">* 5.6 Sol 是接口接受的请求名称，后端身份未核验。Luna ultra 不支持，未计为零分。</p></section>
<section><h2>共同档位比较</h2><p>所有模型均只纳入 low、medium、high、xhigh、max 五档，等权汇总。区间按同一题目联合重采样 20,000 次，反映这 12 题的抽样敏感性。</p><div class="scroll">__MEANS__</div><p class="muted">这些区间不含重复生成波动，也没有充分处理同题包内的依赖，因此不能据小分差宣称稳定排序。</p></section>
<section>__NOTES__</section>
<section><h2>顶档逐题配对</h2><p>这六组比较在正式测试前固定。相比只看总分，“左独对 : 右独对”能显示双方是否各有擅长题目。p 值做六组 Holm 校正，仍仅作探索性参考。</p><div class="scroll">__PAIRS__</div></section>
<section id="inspector"><h2>逐题检查原始答案</h2><div class="filters"><label>模型 <select id="model"></select></label><label>档位 <select id="effort"></select></label><label>题目 <select id="item"></select></label></div><p id="status" class="status"></p><div class="comparison"><div><h3>模型答案</h3><div id="prediction"></div></div><div><h3>冻结标准答案</h3><div id="target"></div></div></div><p id="rationale"></p><p id="source" class="muted"></p><details><summary>查看原始输出文件全文（保留原字节文本）</summary><pre id="raw"></pre></details><details><summary>查看该配置收到的题包全文</summary><pre id="prompt"></pre></details></section>
<section><h2>原始数据与复现</h2><p><a href="results.csv">配置结果 CSV</a> · <a href="item_scores.csv">逐题分数 CSV</a> · <a href="all_raw.jsonl">正式原始输出 JSONL</a> · <a href="calibration_raw.jsonl">校准原始输出 JSONL</a> · <a href="model_comparison_v3_complete.zip">三轮完整资料包</a></p><p>完整包保留预注册协议、抽样种子、源版本、题包、标准答案、原始文件、执行异常、冻结哈希、评分器、自测及独立审查。旧轮的语言风格测试和异常解释也在包内；本轮没有另加自然写作任务。</p><p>源数据：<a href="https://github.com/arcprize/ARC-AGI-2">ARC-AGI-2</a>（Apache-2.0）与 <a href="https://github.com/google-deepmind/bbeh">BBEH</a>（题目 CC-BY-4.0，代码 Apache-2.0）。公开题可能已进入训练；本实验的留出只指没有用于本次校准。</p></section>
<footer>统一变量：题面、顺序、格式、工具提示限制、候选数与重试规则。不同模型的实际推理预算、版本、温度和种子不可见；共享文件系统下的禁用解题工具规则是提示限制，未独立验证完整工具轨迹。各轮题目及评分不同，不宜直接把总分增减解释为模型能力变化。</footer>
<script id="data" type="application/json">__DATA__</script><script>
const D=JSON.parse(document.getElementById('data').textContent), el=id=>document.getElementById(id);
const color=['#111111','#1674d1','#ed3a31','#35a849','#f2d22f','#999999','#e74ba3','#f39425','#65cce5','#8a2441'];
function options(node,arr,label){node.replaceChildren(...arr.map(x=>{let o=document.createElement('option');o.value=x;o.textContent=label(x);return o;}));}
options(el('model'),D.models,m=>D.labels[m]); options(el('item'),Object.keys(D.gold).sort(),x=>x+' · '+D.gold[x].domain.toUpperCase());
function updateEfforts(){const old=el('effort').value;options(el('effort'),D.efforts.filter(x=>D.summary.configurations.some(c=>c.model===el('model').value&&c.reasoning_effort===x)),x=>x);if([...el('effort').options].some(o=>o.value===old))el('effort').value=old;}
function gridShape(value){return Array.isArray(value)&&value.length&&value.every(r=>typeof r==='string'&&/^[0-9]+$/.test(r))&&value.every(r=>r.length===value[0].length);}
function showAnswer(node,value,domain){node.replaceChildren();let grids=value;if(domain==='arc'&&gridShape(grids))grids=[grids];if(domain==='arc'&&Array.isArray(grids)&&grids.length&&grids.every(gridShape)){let wrap=document.createElement('div');wrap.className='grids';grids.forEach((g,i)=>{const cap=document.createElement('p');cap.textContent='测试输出 '+(i+1)+' · '+g.length+' × '+g[0].length;wrap.append(cap);let t=document.createElement('div');t.className='grid';t.style.gridTemplateColumns='repeat('+g[0].length+',1fr)';g.forEach(row=>[...row].forEach(cell=>{let c=document.createElement('span');c.className='pixel';c.style.background=color[+cell];c.title=cell;t.append(c);}));wrap.append(t);});node.append(wrap);}else{let p=document.createElement('pre');p.textContent=JSON.stringify(value,null,2);node.append(p);}}
function render(){const row=D.scores.find(r=>r.model===el('model').value&&r.reasoning_effort===el('effort').value&&r.item_id===el('item').value);if(!row)return;const g=D.gold[row.item_id], raw=D.raw[row.run_id];const parsed=raw.parsed;const ans=parsed?.answers?.[row.item_id];const value=ans?.answer??null;showAnswer(el('prediction'),value,g.domain);showAnswer(el('target'),g.answer,g.domain);el('status').textContent=(row.correct?'整题正确':'整题未通过')+' · '+row.run_id+' · 状态：'+row.status+' · confidence：'+(row.confidence??'缺失');el('status').className='status '+(row.correct?'correct':'wrong');el('rationale').textContent='简短说明：'+(ans?.rationale??'未提供');el('source').textContent='题源：'+g.source_id+' · '+g.family;el('raw').textContent=raw.raw_text??JSON.stringify(raw,null,2);el('prompt').textContent=D.packs[D.runs[row.run_id].pack_id];}
el('model').addEventListener('change',()=>{updateEfforts();render();});el('effort').addEventListener('change',render);el('item').addEventListener('change',render);document.querySelectorAll('.heat').forEach(b=>b.addEventListener('click',()=>{el('model').value=b.dataset.model;updateEfforts();el('effort').value=b.dataset.effort;render();el('inspector').scrollIntoView({behavior:'smooth'});}));updateEfforts();el('effort').value='max';render();
</script></main></html>'''
replacements = {'__LEAD__':e(notes['lead']), '__SUITE__':e(notes['suite_description']),
                '__MATRIX__':table, '__MEANS__':mean_table, '__NOTES__':body_notes,
                '__PAIRS__':pair_table, '__DATA__':payload}
for key, value in replacements.items():
    template = template.replace(key,value)
(out/'report.html').write_text(template)
lines = ['第三轮模型对比：困难公开题追加测试', notes['lead'], notes['suite_description'],
         '', '模型 / low / medium / high / xhigh / max / ultra']
for m in models:
    lines.append(labels[m]+' / '+' / '.join(f"{configs[m,ef]['correct']}/12" if (m,ef) in configs else '不支持' for ef in efforts))
for section in notes['sections']:
    lines.extend(['', section['title'], *section['paragraphs']])
lines.extend(['', '公开题源与许可：ARC-AGI-2 https://github.com/arcprize/ARC-AGI-2 Apache-2.0；BBEH https://github.com/google-deepmind/bbeh CC-BY-4.0（材料）/Apache-2.0（代码）。',
              '完整方法、交互逐题检查和数据链接见 report.html；各轮原始数据和语言风格测试在完整资料包内。'])
(out/'report.txt').write_text('\n\n'.join(lines)+'\n')
print(json.dumps({'report_bytes':(out/'report.html').stat().st_size,
                  'report_sha256':hashlib.sha256((out/'report.html').read_bytes()).hexdigest()}))
