#!/usr/bin/env python3
"""Freeze the third comparison's sampling, question packs, and run manifests.

This program never launches or scores a model. Selection does not inspect gold
answers or model responses. Existing artifacts must match exactly on re-run.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import random
import subprocess


ROOT = Path(__file__).resolve().parents[1]
SEED = 2026110303
ARC_ROOT = ROOT / "research/ARC-AGI-2"
BBEH_ROOT = ROOT / "research/bbeh"
ARC_COMMIT = "f3283f727488ad98fe575ea6a5ac981e4a188e49"
BBEH_COMMIT = "80d12ca916b7158f22293fcf3144f4d3d854d4be"
FAMILIES = [
    "boolean_expressions", "linguini", "web_of_lies",
    "multistep_arithmetic", "dyck_languages", "temporal_sequence",
]
MODELS = [
    "gpt-6-astra", "gpt-6.1-sol", "gpt-6-sol", "gpt-6.1-terra",
    "gpt-6-luna", "gpt-5.6-sol",
]
EFFORTS = ["low", "medium", "high", "xhigh", "max", "ultra"]


def encode_json(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode()


def immutable_write(path: Path, data: bytes):
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_bytes() != data:
            raise RuntimeError(f"Refusing to replace nonidentical frozen artifact: {path}")
    else:
        path.write_bytes(data)


def write_json(path: Path, value):
    immutable_write(path, encode_json(value))


def digest(data: bytes):
    return hashlib.sha256(data).hexdigest()


def revision(path):
    return subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip()


PROTOCOL = {
    "version": "v3.1-preregistered",
    "registration_date_utc": "2026-11-03",
    "purpose": "Reduce the observed high-configuration ceiling using independently sourced difficult tasks; do not select items to favor a requested model ranking.",
    "requested_model_ids": MODELS,
    "efforts": EFFORTS,
    "supported_cells": 35,
    "unsupported_cell": {"model": "gpt-6-luna", "reasoning_effort": "ultra", "reason": "Explicitly rejected in earlier availability probe; not a scored zero."},
    "model_identity_limit": "Identifiers are requested routing labels, not attested backend weights. gpt-5.6-sol is undocumented in the available override list but previously accepted all six efforts.",
    "sources": {
        "arc": {"repo": "https://github.com/arcprize/ARC-AGI-2", "commit": ARC_COMMIT, "split": "data/evaluation", "population_n": 120, "license": "Apache-2.0"},
        "bbeh": {"repo": "https://github.com/google-deepmind/bbeh", "commit": BBEH_COMMIT, "families": FAMILIES, "materials_license": "CC-BY-4.0", "software_license": "Apache-2.0"},
    },
    "selection": {
        "seed": SEED,
        "generator": "Python random.Random(SEED); single RNG consumed in the order below",
        "order": [
            "Sort the 120 ARC evaluation JSON paths lexicographically, then rng.shuffle once.",
            "Take first 6 ARC IDs for calibration; next 12 for held-out-in-this-experiment items (first 6 core and next 6 reserve).",
            "For each BBEH family in the listed order, rng.sample(range(number_of_examples), 2); first index calibration and second held-out.",
            "Build 9 calibration configurations-by-pack rows, rng.shuffle, then assign c001..c009.",
            "Build 105 formal configurations-by-pack rows, rng.shuffle, then assign v001..v105; both candidate suites share this same mapping/order.",
        ],
        "not_used_for_selection": ["Gold answer value", "Response correctness on an individual item", "Which model wins", "Prompt length", "Observed model ranking"],
        "contamination_limit": "All source tasks are public. Held-out means unused in this experiment's calibration, not proven unseen during model training. Source task IDs are removed from worker packs; that does not establish absence of contamination.",
    },
    "calibration": {
        "requested_configurations": [{"model": model, "reasoning_effort": "max"} for model in MODELS[:3]],
        "items": {"arc": 6, "bbeh": 6},
        "packs": 3,
        "items_per_pack": 4,
        "calls": 9,
        "per_domain_binary_observations": 18,
        "selection_input": "Only domain-pooled counts across all three preselected top configurations; no model-specific success rates or win/loss patterns.",
        "decision_rule": [
            "If both ARC and BBEH counts are 15..18 out of 18, do not launch the 105 formal runs. Record stage-one ceiling and permit one newly registered second calibration stage using new source instances; never select by model-specific winners. At most two calibration stages total.",
            "Otherwise, if ARC solved count is 4..14 inclusive out of 18 and BBEH count is 15..18, choose formal_arc (12 ARC items).",
            "Otherwise choose formal_mixed (6 ARC and 6 BBEH items).",
            "Calibration target is attained when both counts are 4..14, or when the ARC-only condition in the first rule applies.",
            "For other non-ceiling outcomes report calibration target not attained and retain formal_mixed. No other calibration stage, post-hoc difficulty adaptation, or selecting items by model differences is permitted.",
        ],
        "exclusion": "All 12 calibration source instances are excluded from both formal candidate suites and all formal scores.",
    },
    "formal": {
        "configurations": 35, "packs_per_configuration": 3, "items_per_pack": 4,
        "calls": 105, "unique_items": 12, "answers_if_complete": 420,
        "samples_per_item_per_configuration": 1,
        "fresh_context": "Each pack/configuration is a newly spawned child with fork_turns=none and explicit requested model/effort.",
        "pack_composition": {"formal_mixed": "2 ARC and 2 BBEH, interleaved ARC/BBEH/ARC/BBEH", "formal_arc": "4 ARC"},
        "same_input": "Each corresponding pack is byte-identical for every requested configuration. The execution wrapper only substitutes pack and output paths, never model or effort.",
        "replication_limit": "There is one generation per item/configuration. Four items share a pack context; there are only 12 distinct formal tasks and 3 pack contexts per configuration, not 420 independent evaluation tasks.",
        "language": "Common instructions are Chinese; BBEH question text remains original English; ARC uses lossless decimal row-string grids. No additional style task is included in this harder reasoning round.",
    },
    "worker_tool_policy": {
        "allowed": ["Read exactly the assigned pack once", "Write exactly the assigned raw JSON output once using apply_patch"],
        "disallowed": ["Other file reads", "Code execution or other tools to solve tasks", "Internet/search", "Other agents", "Consulting any gold answer or source task file"],
        "enforcement_limit": "These are prompt instructions, not a filesystem or tool security sandbox. Workers share the workspace. Complete worker tool traces are not independently available for audit, so hard isolation or fully verified tool abstinence is not claimed.",
    },
    "response_schema": {
        "answers": {"ITEM_ID": {"answer": "ARC: list of predicted grids, each grid a list of row strings; BBEH: final answer string", "confidence": "Integer 0..100", "rationale": "Optional short explanation, at most two sentences; no private reasoning transcript requested"}},
    },
    "scoring": {
        "primary": "Binary task solved; each task has equal weight. Report domain scores and overall mean with exploratory limits.",
        "arc": "Pass@1: all cells of every test grid in the source task must match, including shape. No candidate selection, partial grid credit, or second guess. This differs from the official two-candidate evaluation and is not an official leaderboard score.",
        "bbeh": "Use the pinned official evaluate_correctness function without changing its normalization or fuzzy matching rules.",
        "format_recovery": ["Strip a whole-file Markdown JSON code fence if present", "ARC accepts a 0..9 integer grid as equivalent to row strings", "For an ARC task with exactly one test input, recover an answer that omits the outer list of test outputs", "BBEH scalar answers may be converted to strings before official scoring"],
        "prohibited_recovery": ["Change any grid value", "Transpose or rotate a prediction", "Remap colors", "Choose from multiple guesses", "Hand-correct factual content"],
        "missing": "Empty/null/explicit abstention is a primary failure and is reported separately from attempted wrong answers. Confidence zero alone does not make a numeric zero answer a placeholder.",
        "infrastructure": "Preserve execution failures separately from substantive refusal or model-produced invalid answers. Never replace a low-scoring completed attempt with a better retry. Any infrastructure-only retry must be labeled, retain the failed event, and use the identical prompt/configuration.",
        "raw_preservation": "Retain original raw file bytes, refusal text if any, execution events, and all mechanical recovery flags.",
    },
    "analysis_limits": [
        "An exploratory small public-task comparison cannot establish a stable general-intelligence ranking.",
        "Report paired per-item disagreements and ties; task and domain sampling uncertainty matters more than decimal score differences.",
        "No test of monotonic effort improvement can rely on a single generation per cell.",
        "Routing/backend identity, temperature, generation seed, token limits, reasoning-token use, costs, and detailed finish reasons are not attested by these tools.",
        "The preset task-family selection favors abstract induction and symbolic/linguistic reasoning, not full general capability. The six BBEH families are not the complete BBEH benchmark.",
        "New scores are not directly comparable with prior custom-task totals or official ARC/BBEH leaderboards.",
    ],
}


COMMON_INSTRUCTIONS = """这是独立的题包评测。请解答本题包中的全部四题。

工具规则：你只能读取协调者指定的这一份题包一次，并用 apply_patch 向协调者指定的输出路径写入一次最终 JSON。不要读取任何其他文件；不要运行代码、使用搜索/网络、调用其他智能体或使用其他工具求解。题包外的文件和信息不属于本次输入。

请直接给最终答案。可以为每题附上最多两句话的简短判断依据，但不要输出完整思维过程。每题给出 0 至 100 的整数 confidence，表示你认为整题答案完全正确的概率百分比。不能解答时 answer 可为 null，并在 rationale 简短注明；不要用空对象或默认数字冒充答案。

输出必须是一个 JSON 对象：
{"answers":{"题号":{"answer":最终答案,"confidence":80,"rationale":"可选简短依据"}}}
所有题号都必须出现。不要附加 Markdown 围栏。JSON 写入指定文件之后，最终消息只需说明文件已写入，不再重复答案。

网格题说明：每个字符表示一个格子的颜色编号（0—9），一串字符是一行，字符串数组是一张网格；这些编号不是要连成十进制整数。训练示例给出了输入到输出的同一种规律。请推断规律，对每个测试输入给出预测输出。answer 始终是按测试输入顺序排列的网格列表，每张网格是行字符串数组。即使只有一个测试输入，也保留最外层测试列表，合法形式如 [["012","345"]]。只有所有测试输出形状和每个格子完全正确，整题才算解出。只提交一个候选答案。

文字题说明：问题保持原始英文。answer 必须仅含题目要求的最终答案字符串；解释放在 rationale，不要混进 answer。若原题规定答案形式，请遵守。

以下是四道题：
"""


def row_grid(grid):
    assert grid and len({len(row) for row in grid}) == 1
    assert all(type(cell) is int and 0 <= cell <= 9 for row in grid for cell in row)
    return ["".join(str(cell) for cell in row) for row in grid]


def make_pack(pack_id, item_ids, public_items):
    chunks = [COMMON_INSTRUCTIONS]
    for item_id in item_ids:
        item = public_items[item_id]
        chunks.append(f"\n题号：{item_id}\n题型：{'网格规律' if item['domain'] == 'arc' else '文字推理'}\n")
        if item["domain"] == "arc":
            chunks.append(json.dumps(item["task"], ensure_ascii=False, separators=(",", ":")) + "\n")
        else:
            chunks.append(item["input"] + "\n")
    text = "".join(chunks)
    path = ROOT / "inputs" / (pack_id + ".txt")
    immutable_write(path, text.encode())
    return {"pack_id": pack_id, "pack_path": str(path), "item_ids": item_ids,
            "characters": len(text), "bytes": len(text.encode()), "sha256": digest(text.encode())}


def make_manifest(phase, packs, config_order, run_prefix):
    rows = []
    for i, (model, effort, pack_index) in enumerate(config_order, 1):
        run_id = f"{run_prefix}{i:03d}"
        pack = packs[pack_index]
        output_dir = ROOT / ("calibration/raw" if phase == "calibration" else "raw")
        output_dir.mkdir(parents=True, exist_ok=True)
        rows.append({"run_id": run_id, "model": model, "reasoning_effort": effort,
                     "pack_id": pack["pack_id"], "pack_path": pack["pack_path"],
                     "item_ids": pack["item_ids"], "output_path": str(output_dir / (run_id + ".json")),
                     "pack_sha256": pack["sha256"]})
    return {"phase": phase, "seed": SEED, "run_count": len(rows), "packs": packs, "runs": rows}


def main():
    assert revision(ARC_ROOT) == ARC_COMMIT
    assert revision(BBEH_ROOT) == BBEH_COMMIT
    # This immutable preregistration is written before any random draws or task reads.
    write_json(ROOT / "protocol.json", PROTOCOL)

    rng = random.Random(SEED)
    arc_paths = sorted((ARC_ROOT / "data/evaluation").glob("*.json"))
    assert len(arc_paths) == 120
    rng.shuffle(arc_paths)
    selected_arc = arc_paths[:18]
    selections = {"seed": SEED, "arc_ordered_ids": [p.stem for p in selected_arc], "bbeh": []}
    public, gold = {}, {}
    for i, path in enumerate(selected_arc, 1):
        item_id = f"A{i:03d}"
        data = json.loads(path.read_text())
        split = "calibration" if i <= 6 else "holdout"
        public[item_id] = {"domain": "arc", "task": {
            "train": [{"input": row_grid(q["input"]), "output": row_grid(q["output"])} for q in data["train"]],
            "test": [{"input": row_grid(q["input"])} for q in data["test"]]}}
        gold[item_id] = {"domain": "arc", "family": "abstract_grid_induction", "split": split,
                         "source_id": path.stem, "source_relative_path": str(path.relative_to(ARC_ROOT)),
                         "source_sha256": digest(path.read_bytes()),
                         "answer": [row_grid(q["output"]) for q in data["test"]],
                         "source_target": [q["output"] for q in data["test"]]}
        immutable_write(ROOT / "source_snapshots/arc/data/evaluation" / path.name, path.read_bytes())

    bbeh_snapshot = []
    for family_index, family in enumerate(FAMILIES):
        relative_path = f"bbeh/benchmark_tasks/bbeh_{family}/task.json"
        source_path = BBEH_ROOT / relative_path
        source = json.loads(source_path.read_text())
        indices = rng.sample(range(len(source["examples"])), 2)
        selections["bbeh"].append({"family": family, "calibration_index_zero_based": indices[0], "holdout_index_zero_based": indices[1], "population_n": len(source["examples"]), "source_file_sha256": digest(source_path.read_bytes())})
        for j, index in enumerate(indices):
            item_id = f"B{2 * family_index + j + 1:03d}"
            example = source["examples"][index]
            public[item_id] = {"domain": "bbeh", "input": example["input"]}
            gold[item_id] = {"domain": "bbeh", "family": family, "split": "calibration" if j == 0 else "holdout",
                             "source_id": f"bbeh_{family}:{index}", "source_index_zero_based": index,
                             "source_relative_path": relative_path, "source_sha256": digest(source_path.read_bytes()),
                             "example_sha256": digest(encode_json(example)), "answer": example["target"], "source_target": example["target"]}
            bbeh_snapshot.append({"item_id": item_id, "family": family, "index_zero_based": index,
                                  "source_canary": source.get("canary"), "example": example})
    write_json(ROOT / "source_snapshots/bbeh/selected_examples.json", bbeh_snapshot)

    calibration_packs, mixed_packs, arc_packs = [], [], []
    for pack_index in range(3):
        k = 2 * pack_index
        calibration_ids = [f"A{k+1:03d}", f"B{2*k+1:03d}", f"A{k+2:03d}", f"B{2*k+3:03d}"]
        mixed_ids = [f"A{k+7:03d}", f"B{2*k+2:03d}", f"A{k+8:03d}", f"B{2*k+4:03d}"]
        arc_ids = [f"A{7+4*pack_index+j:03d}" for j in range(4)]
        calibration_packs.append(make_pack(f"calibration_p{pack_index+1}", calibration_ids, public))
        mixed_packs.append(make_pack(f"formal_mixed_p{pack_index+1}", mixed_ids, public))
        arc_packs.append(make_pack(f"formal_arc_p{pack_index+1}", arc_ids, public))

    calibration_order = [(model, "max", pack_index) for model in MODELS[:3] for pack_index in range(3)]
    rng.shuffle(calibration_order)
    formal_order = [(model, effort, pack_index) for model in MODELS for effort in EFFORTS
                    if not (model == "gpt-6-luna" and effort == "ultra") for pack_index in range(3)]
    rng.shuffle(formal_order)
    write_json(ROOT / "calibration_manifest.json", make_manifest("calibration", calibration_packs, calibration_order, "c"))
    write_json(ROOT / "formal_mixed_manifest.json", make_manifest("formal_mixed", mixed_packs, formal_order, "v"))
    write_json(ROOT / "formal_arc_manifest.json", make_manifest("formal_arc", arc_packs, formal_order, "v"))
    write_json(ROOT / "gold.json", {"version": "v3.1", "items": gold})
    write_json(ROOT / "selection.json", selections)
    write_json(ROOT / "pack_inventory.json", {"calibration": calibration_packs, "formal_mixed": mixed_packs, "formal_arc": arc_packs})

    for source_root, dest_prefix, names in [
        (ARC_ROOT, "arc", ["LICENSE", "readme.md"]),
        (BBEH_ROOT, "bbeh", ["LICENSE", "README.md", "bbeh/evaluate.py"]),
    ]:
        for name in names:
            source = source_root / name
            immutable_write(ROOT / "source_snapshots" / dest_prefix / name, source.read_bytes())
    attribution = """Third-round benchmark source attribution

ARC-AGI-2: ARC Prize, https://github.com/arcprize/ARC-AGI-2
Pinned commit: f3283f727488ad98fe575ea6a5ac981e4a188e49
License: Apache License 2.0. Original LICENSE and README are included.
Selected public evaluation tasks are reproduced as source JSON. Worker inputs
remove source identifiers and held-out test outputs and encode integer grid rows
as digit strings; this is a lossless textual representation of the visible grid.
Our one-candidate pass@1 protocol is not an official ARC leaderboard evaluation.

BIG-Bench Extra Hard (BBEH): Copyright 2025 Google LLC.
Mehran Kazemi et al., BIG-Bench Extra Hard, arXiv:2502.19187 (2025).
https://github.com/google-deepmind/bbeh
Pinned commit: 80d12ca916b7158f22293fcf3144f4d3d854d4be
Dataset materials: Creative Commons Attribution 4.0 International (CC-BY-4.0),
https://creativecommons.org/licenses/by/4.0/legalcode
Software: Apache License 2.0. The original LICENSE, README with full citations,
and unmodified evaluate.py are included. Selected question input strings and
targets are unmodified; question wrapping and pseudonymous item IDs are new.
Only six of twenty-three BBEH task families are sampled, not the full benchmark.

Additional attribution for included task families, as specified in the README:
- Linguini: Eduardo Sanchez et al., Linguini: A Benchmark for Language-Agnostic
  Linguistic Reasoning, arXiv:2409.12126 (2024).
- Dyck Languages: Gladys Tyen et al., LLMs Cannot Find Reasoning Errors, but Can
  Correct Them!, arXiv:2311.08516 (2023).
- Web of Lies: Colin White et al., LiveBench: A Challenging, Contamination-Free
  LLM Benchmark, arXiv:2406.19314 (2024). This citation is not a claim that our
  selected public BBEH items are uncontaminated.

Source answers are included for reproducibility but are not part of the worker
input. Shared filesystem access is restricted by prompt, not an enforced boundary.
"""
    immutable_write(ROOT / "source_snapshots/ATTRIBUTION.txt", attribution.encode())

    tracked = [ROOT / "protocol.json", ROOT / "selection.json", ROOT / "gold.json", ROOT / "pack_inventory.json",
               ROOT / "calibration_manifest.json", ROOT / "formal_mixed_manifest.json", ROOT / "formal_arc_manifest.json",
               Path(__file__).resolve()]
    tracked += sorted((ROOT / "inputs").glob("*.txt"))
    tracked += sorted(p for p in (ROOT / "source_snapshots").rglob("*") if p.is_file())
    freeze = {str(p.relative_to(ROOT)): {"bytes": p.stat().st_size, "sha256": digest(p.read_bytes())} for p in tracked}
    write_json(ROOT / "frozen_sha256.json", {"algorithm": "sha256", "files": freeze})
    assert len(gold) == 30
    assert len(calibration_order) == 9 and len(formal_order) == 105
    assert set(x for p in calibration_packs for x in p["item_ids"]).isdisjoint(x for p in mixed_packs + arc_packs for x in p["item_ids"])
    print(json.dumps({"frozen_files": len(freeze), "gold_items": len(gold),
                      "calibration_runs": 9, "formal_runs_per_variant": 105,
                      "pack_characters": {p["pack_id"]: p["characters"] for p in calibration_packs + mixed_packs + arc_packs}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
