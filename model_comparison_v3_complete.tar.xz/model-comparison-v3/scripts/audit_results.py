"""Independently recount results and verify immutable evidence before delivery."""
import contextlib
import hashlib
import importlib.util
import io
import json
from collections import Counter, defaultdict
from pathlib import Path

base=Path(__file__).resolve().parents[1]
read=lambda name:json.loads((base/name).read_text())
gold=read('gold.json')['items']; manifest=read('formal_manifest.json')
summary=read('analysis/formal/summary.json'); score_rows=read('analysis/formal/item_scores.json')
assert summary['ready']
index={(r['run_id'],r['item_id']):r for r in score_rows}
assert len(index)==420
spec=importlib.util.spec_from_file_location('independent_official_bbeh',base/'source_snapshots/bbeh/bbeh/evaluate.py')
official=importlib.util.module_from_spec(spec)
with contextlib.redirect_stdout(io.StringIO()):spec.loader.exec_module(official)

def grid(v):
    if not isinstance(v,list) or not v:return None
    z=[]
    for row in v:
        if isinstance(row,str) and row and all(c in '0123456789' for c in row):z.append(row)
        elif isinstance(row,list) and row and all(type(c)==int and 0<=c<=9 for c in row):z.append(''.join(str(c) for c in row))
        else:return None
    return z if len({len(row) for row in z})==1 else None

def answer_correct(pred,target,domain):
    if domain=='bbeh':
        return (type(pred) in (str,int,float)) and official.evaluate_correctness(str(pred),str(target))
    if not isinstance(pred,list) or not pred:return False
    norm=[grid(x) for x in pred]
    if any(x is None for x in norm):
        single=grid(pred)
        norm=[single] if len(target)==1 and single is not None else None
    return norm==target

raw_aggregate=[json.loads(x) for x in (base/'analysis/formal/all_raw.jsonl').read_text().splitlines()]
raw_aggregate={x['run']['run_id']:x for x in raw_aggregate}
totals=Counter(); items=defaultdict(set); raw_hashes={}; refusal_count=0
for run in manifest['runs']:
    path=Path(run['output_path']); obj=None
    if path.exists():
        rawbytes=path.read_bytes(); text=rawbytes.decode('utf-8'); parse=text.strip()
        if parse.startswith('```') and parse.endswith('```'):
            parse=parse.split('\n',1)[1].rsplit('\n',1)[0]
        try:obj=json.loads(parse)
        except (json.JSONDecodeError,ValueError):pass
    else:
        path=path.with_suffix('.refusal.txt')
        assert path.exists(), ('unresolved infrastructure',run['run_id'])
        rawbytes=path.read_bytes();refusal_count+=1
    digest=hashlib.sha256(rawbytes).hexdigest(); raw_hashes[run['run_id']]=digest
    agg=raw_aggregate[run['run_id']]
    assert digest==agg['raw_sha256']
    assert agg['raw_text'].encode('utf-8')==rawbytes, ('aggregate changed raw text',run['run_id'])
    envelope=obj.get('answers',{}) if isinstance(obj,dict) else {}
    envelope=envelope if isinstance(envelope,dict) else {}
    key=(run['model'],run['reasoning_effort'])
    for iid in run['item_ids']:
        entry=envelope.get(iid,{})
        pred=entry.get('answer') if isinstance(entry,dict) else None
        correct=int(answer_correct(pred,gold[iid]['answer'],gold[iid]['domain']))
        assert correct==index[run['run_id'],iid]['correct'], (run['run_id'],iid)
        totals[key]+=correct;items[key].add(iid)
assert len(totals)==35 and all(len(x)==12 for x in items.values())
for row in summary['configurations']:
    key=(row['model'],row['reasoning_effort'])
    assert row['correct']==totals[key]
    assert abs(row['score_pct']-100*totals[key]/12)<1e-10
for name,info in read('frozen_sha256.json')['files'].items():
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==info['sha256'],name
freeze=read('score_freeze.json')
hash_dict=freeze.get('files',freeze.get('hashes',{}))
for name,info in hash_dict.items():
    expected=info if isinstance(info,str) else info['sha256']
    assert hashlib.sha256((base/name).read_bytes()).hexdigest()==expected,name
report={'all_pass':True,'auditor':'root independent raw-file recount',
        'formal_runs':len(manifest['runs']),'question_scores_recounted':len(index),
        'configurations_recounted':len(totals),'distinct_questions':len(set.union(*items.values())),
        'observed_refusal_artifacts':refusal_count,'raw_hashes':raw_hashes,
        'checks':['all raw artifact bytes match aggregate text and SHA256','independent ARC canonicalization and exact equality',
                  'official pinned BBEH scorer called independently','all 420 binary scores and 35 totals match',
                  '42 input/source freezes preserved','final scorer freeze preserved']}
(base/'analysis/final_audit.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='raw_hashes'},ensure_ascii=False,indent=2))
