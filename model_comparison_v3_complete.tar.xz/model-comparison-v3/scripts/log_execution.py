import argparse
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/model-comparison-v3')
p = argparse.ArgumentParser()
p.add_argument('event')
p.add_argument('run_id')
p.add_argument('--agent', default=None)
p.add_argument('--detail', default=None)
p.add_argument('--manifest', default='calibration_manifest.json')
a = p.parse_args()
manifest = json.loads((ROOT / a.manifest).read_text())
row = next(r for r in manifest['runs'] if r['run_id'] == a.run_id)
event = dict(row)
event.update(event=a.event, recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), agent_name=a.agent, detail=a.detail)
if a.event in ('completed', 'no_raw', 'failed'):
    output = Path(row['output_path'])
    event['raw_exists'] = output.exists()
    if output.exists():
        data = output.read_bytes()
        event['raw_bytes'] = len(data)
        event['raw_sha256'] = hashlib.sha256(data).hexdigest()
with (ROOT / 'execution_events.jsonl').open('a') as f:
    f.write(json.dumps(event, ensure_ascii=False) + '\n')
