"""Standalone SVG of the complete model-effort matrix; no external assets."""
import html
import json
from pathlib import Path

base=Path(__file__).resolve().parents[1]
s=json.loads((base/'analysis/formal/summary.json').read_text())
assert s['ready']
models=['gpt-6-astra','gpt-6.1-sol','gpt-6-sol','gpt-6.1-terra','gpt-6-luna','gpt-5.6-sol']
efforts=['low','medium','high','xhigh','max','ultra']
labels=['6 Astra','6.1 Sol','6 Sol','6.1 Terra','6 Luna','5.6 Sol*']
rows={(r['model'],r['reasoning_effort']):r for r in s['configurations']}
parts=['<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="660" viewBox="0 0 1080 660">',
       '<rect width="1080" height="660" fill="#f3f6f7"/>',
       '<style>text{font-family:Arial,sans-serif;fill:#193442}.title{font-size:27px;font-weight:bold}.body{font-size:17px}.small{font-size:14px}.count{font-size:24px;font-weight:bold}</style>',
       '<text x="36" y="48" class="title">Hard-task follow-up: 35 requested configurations</text>',
       '<text x="36" y="78" class="body">12 distinct tasks per configuration · single attempt · exploratory public subset</text>']
for j, effort in enumerate(efforts):
    parts.append(f'<text x="{245+j*136}" y="127" class="body" text-anchor="middle">{effort}</text>')
for i,(model,label) in enumerate(zip(models,labels)):
    y=146+i*70
    parts.append(f'<text x="36" y="{y+37}" class="body">{label}</text>')
    for j,effort in enumerate(efforts):
        x=180+j*136; r=rows.get((model,effort))
        p=r['score_pct']/100 if r else 0
        rgb=tuple(round(a+(b-a)*p) for a,b in zip((238,243,244),(73,168,160)))
        fill='#%02x%02x%02x'%rgb
        parts.append(f'<rect x="{x}" y="{y}" width="126" height="61" rx="8" fill="{fill}"/>')
        if r:
            parts.append(f'<text x="{x+63}" y="{y+29}" class="count" text-anchor="middle">{r["correct"]}/12</text>')
            parts.append(f'<text x="{x+63}" y="{y+49}" class="small" text-anchor="middle">{r["score_pct"]:.1f}%</text>')
        else:
            parts.append(f'<text x="{x+63}" y="{y+36}" class="small" text-anchor="middle">unsupported</text>')
parts.extend(['<text x="36" y="600" class="small">* 5.6 Sol: accepted request identifier; backend identity unverified.</text>',
              '<text x="36" y="625" class="small">Equal task weight. Not an official leaderboard, IQ estimate, or stable general capability ranking.</text>', '</svg>'])
(base/'delivery/scores.svg').write_text('\n'.join(parts)+'\n')
