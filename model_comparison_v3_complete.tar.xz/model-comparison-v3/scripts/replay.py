"""Re-score an extracted archive without changing its frozen manifests/raw data."""
import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

base = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--phase', choices=['formal','calibration'], default='formal')
args = parser.parse_args()
original = base / ('formal_manifest.json' if args.phase == 'formal' else 'calibration_manifest.json')
manifest = json.loads(original.read_text())
for pack in manifest['packs']:
    pack['pack_path'] = str(base / 'inputs' / Path(pack['pack_path']).name)
for run in manifest['runs']:
    run['pack_path'] = str(base / 'inputs' / Path(run['pack_path']).name)
    rawdir = base / 'raw' if args.phase == 'formal' else base / 'calibration/raw'
    run['output_path'] = str(rawdir / Path(run['output_path']).name)
with tempfile.TemporaryDirectory(prefix='v3-replay-') as tmp:
    localized = Path(tmp) / 'manifest.json'
    localized.write_text(json.dumps(manifest, ensure_ascii=False))
    subprocess.run([sys.executable, str(base/'scripts/score.py'), '--phase', args.phase,
                    '--manifest', str(localized), '--output-dir', str(base/'replay'/args.phase)], check=True)
print('Original frozen inputs and raw files were not changed. Replay metadata uses relocated paths.')
