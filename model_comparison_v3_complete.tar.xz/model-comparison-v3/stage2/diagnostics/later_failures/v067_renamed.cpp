#include <bits/stdc++.h>
using namespace std;

using ll = long long;
static const int MAXN = 1300;
int J, M, N;
int mach[MAXN], duration_[MAXN], jp[MAXN], job_next_op[MAXN];
int prv[MAXN], nxt[MAXN], bestPrv[MAXN], bestNxt[MAXN];
ll head_[MAXN], finish_[MAXN];
int indeg_[MAXN], parent_[MAXN], que_[MAXN];
mt19937 rng(2026110305);
clock_t startClock;

double elapsed() { return double(clock() - startClock) / CLOCKS_PER_SEC; }

struct Evaluation {
    ll makespan, sum;
    int last;
    bool valid;
};

Evaluation evaluate() {
    int qh = 0, qt = 0;
    for (int i = 0; i < N; ++i) {
        indeg_[i] = (jp[i] >= 0) + (prv[i] >= 0);
        head_[i] = 0;
        parent_[i] = -1;
        if (!indeg_[i]) que_[qt++] = i;
    }
    ll makespan = 0, sum = 0;
    int last = -1;
    while (qh < qt) {
        int u = que_[qh++];
        ll f = head_[u] + duration_[u];
        finish_[u] = f;
        sum += f;
        if (f > makespan) { makespan = f; last = u; }
        int v = job_next_op[u];
        if (v >= 0) {
            if (f > head_[v]) { head_[v] = f; parent_[v] = u; }
            if (!--indeg_[v]) que_[qt++] = v;
        }
        v = nxt[u];
        if (v >= 0) {
            if (f > head_[v]) { head_[v] = f; parent_[v] = u; }
            if (!--indeg_[v]) que_[qt++] = v;
        }
    }
    return {makespan, sum, last, qt == N};
}

void swapAdjacent(int x, int y) {
    int a = prv[x], b = nxt[y];
    if (a >= 0) nxt[a] = y;
    if (b >= 0) prv[b] = x;
    prv[y] = a; nxt[y] = x;
    prv[x] = y; nxt[x] = b;
}

vector<pair<int,int>> criticalMoves(int last) {
    vector<int> path;
    for (int u = last; u >= 0; u = parent_[u]) path.push_back(u);
    reverse(path.begin(), path.end());
    vector<pair<int,int>> result;
    for (int i = 0; i < (int)path.size();) {
        int e = i;
        while (e + 1 < (int)path.size() && nxt[path[e]] == path[e+1]) ++e;
        if (e > i) {
            result.emplace_back(path[i], path[i+1]);
            if (e > i+1) result.emplace_back(path[e-1], path[e]);
        }
        i = e+1;
    }
    return result;
}

void construct() {
    vector<int> stage(J, 0), tail(M, -1);
    vector<ll> jobReady(J, 0), machineReady(M, 0), remaining(J, 0), machineLoad(M, 0);
    for (int j = 0; j < J; ++j)
        for (int k = 0; k < M; ++k) {
            int u = j*M+k;
            remaining[j] += duration_[u];
            machineLoad[mach[u]] += duration_[u];
        }
    fill(prv, prv+N, -1); fill(nxt, nxt+N, -1);
    double total = 0;
    for (int j = 0; j < J; ++j) total += remaining[j];
    double meanJob = max(1.0, total / J);
    double meanOp = max(1.0, total / N);
    int mode = rng()%7;
    double noise = (rng()%1000) / 1000.0;
    for (int count = 0; count < N; ++count) {
        ll minCompletion = LLONG_MAX;
        int selectedMachine = -1;
        for (int j = 0; j < J; ++j) if (stage[j] < M) {
            int u = j*M + stage[j], m = mach[u];
            ll completion = max(jobReady[j], machineReady[m]) + duration_[u];
            if (completion < minCompletion || (completion == minCompletion && (rng()&1))) {
                minCompletion = completion; selectedMachine = m;
            }
        }
        int chosen = -1;
        double bestPriority = -1e100;
        for (int j = 0; j < J; ++j) if (stage[j] < M) {
            int u = j*M + stage[j], m = mach[u];
            if (m != selectedMachine) continue;
            ll st = max(jobReady[j], machineReady[m]);
            if (st >= minCompletion) continue;
            double rem = remaining[j] / meanJob;
            double p = duration_[u] / meanOp;
            double ready = double(st - machineReady[m]) / meanOp;
            double randomTerm = double(rng()) / double(mt19937::max());
            double score;
            switch (mode) {
                case 0: score = rem - 0.15*p - 0.25*ready; break;
                case 1: score = rem + 0.25*p - 0.15*ready; break;
                case 2: score = -p - 0.2*ready + 0.4*rem; break;
                case 3: score = p + 0.3*rem - 0.25*ready; break;
                case 4: score = -ready + 0.4*rem; break;
                case 5: score = 1.5*rem - 0.5*p; break;
                default: score = randomTerm; break;
            }
            score += (0.05 + noise*0.9)*randomTerm;
            if (score > bestPriority) { bestPriority = score; chosen = j; }
        }
        int u = chosen*M + stage[chosen], m = mach[u];
        ll st = max(jobReady[chosen], machineReady[m]);
        jobReady[chosen] = machineReady[m] = st + duration_[u];
        if (tail[m] >= 0) { nxt[tail[m]] = u; prv[u] = tail[m]; }
        tail[m] = u;
        remaining[chosen] -= duration_[u];
        ++stage[chosen];
    }
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    startClock = clock();
    if (!(cin >> J >> M)) return 0;
    N = J*M;
    for (int j = 0; j < J; ++j) for (int k = 0; k < M; ++k) {
        int u = j*M+k;
        cin >> mach[u] >> duration_[u];
        jp[u] = k ? u-1 : -1;
        job_next_op[u] = k+1 < M ? u+1 : -1;
    }
    ll globalBest = LLONG_MAX, bestSum = LLONG_MAX;
    auto saveBest = [&](const Evaluation &e) {
        if (e.valid && (e.makespan < globalBest || (e.makespan == globalBest && e.sum < bestSum))) {
            globalBest = e.makespan; bestSum = e.sum;
            copy(prv, prv+N, bestPrv); copy(nxt, nxt+N, bestNxt);
            return true;
        }
        return false;
    };
    for (int i = 0; i < 20; ++i) {
        construct();
        saveBest(evaluate());
    }
    copy(bestPrv, bestPrv+N, prv); copy(bestNxt, bestNxt+N, nxt);
    Evaluation current = evaluate();
    vector<int> tabu((size_t)N*N, 0);
    int iteration = 0, stagnant = 0, restarts = 0;
    while (elapsed() < 1.82) {
        ++iteration;
        auto moves = criticalMoves(current.last);
        if (moves.empty()) break;
        shuffle(moves.begin(), moves.end(), rng);
        pair<int,int> chosen = {-1,-1}, fallback = {-1,-1};
        ll chosenValue = LLONG_MAX, chosenSum = LLONG_MAX;
        ll fallbackValue = LLONG_MAX, fallbackSum = LLONG_MAX;
        for (auto [x,y] : moves) {
            swapAdjacent(x,y);
            Evaluation e = evaluate();
            swapAdjacent(y,x);
            if (!e.valid) continue;
            int a = min(x,y), b = max(x,y);
            bool forbidden = tabu[(size_t)a*N+b] > iteration && e.makespan >= globalBest;
            if (e.makespan < fallbackValue || (e.makespan == fallbackValue && e.sum < fallbackSum)) {
                fallback = {x,y}; fallbackValue = e.makespan; fallbackSum = e.sum;
            }
            if (!forbidden && (e.makespan < chosenValue || (e.makespan == chosenValue && e.sum < chosenSum))) {
                chosen = {x,y}; chosenValue = e.makespan; chosenSum = e.sum;
            }
        }
        if (chosen.first < 0) chosen = fallback;
        if (chosen.first < 0) stagnant = 100000;
        else {
            int x = chosen.first, y = chosen.second;
            swapAdjacent(x,y);
            int a = min(x,y), b = max(x,y);
            tabu[(size_t)a*N+b] = iteration + 7 + int(rng()%12);
            current = evaluate();
            ll oldBest = globalBest;
            saveBest(current);
            if (globalBest < oldBest) stagnant = 0;
            else ++stagnant;
        }
        if (stagnant > 180 + int(N/10)) {
            ++restarts;
            stagnant = 0;
            if (restarts % 4 == 0) {
                construct();
                current = evaluate();
                saveBest(current);
            } else {
                copy(bestPrv, bestPrv+N, prv); copy(bestNxt, bestNxt+N, nxt);
                current = evaluate();
                int steps = 8 + int(rng()%20);
                for (int k = 0; k < steps; ++k) {
                    auto perturb = criticalMoves(current.last);
                    if (perturb.empty()) break;
                    shuffle(perturb.begin(), perturb.end(), rng);
                    bool done = false;
                    for (auto [x,y] : perturb) {
                        swapAdjacent(x,y);
                        Evaluation e = evaluate();
                        if (e.valid) { current = e; done = true; saveBest(e); break; }
                        swapAdjacent(y,x);
                    }
                    if (!done) { current = evaluate(); break; }
                }
            }
            fill(tabu.begin(), tabu.end(), 0);
        }
    }
    for (int m = 0; m < M; ++m) {
        int first = -1;
        for (int u = 0; u < N; ++u) if (mach[u] == m && bestPrv[u] == -1) { first = u; break; }
        bool space = false;
        for (int u = first; u >= 0; u = bestNxt[u]) {
            if (space) cout << ' ';
            cout << u/M;
            space = true;
        }
        cout << '\n';
    }
    return 0;
}
