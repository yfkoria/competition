#include <bits/stdc++.h>
using namespace std;

struct Edge { int u, v; };

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, m;
    if (!(cin >> n >> m)) return 0;
    vector<Edge> edges(m);
    vector<vector<int>> adj(n);
    for (int i = 0; i < m; ++i) {
        int u, v; cin >> u >> v; --u; --v;
        edges[i] = {u, v};
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    if (m == 0) {
        for (int i = 0; i < n; ++i) cout << (i ? " 0" : "0");
        cout << '\n';
        return 0;
    }

    mt19937 rng(2026110305u);
    vector<int> best(n, 0);
    int bestScore = -1;
    auto scoreOf = [&](const vector<int>& s) {
        int c = 0;
        for (const auto &e : edges) c += (s[e.u] != s[e.v]);
        return c;
    };

    auto improve = [&](vector<int> s) -> pair<vector<int>, int> {
        vector<int> gain(n, 0), ver(n, 0);
        int cur = 0;
        for (const auto &e : edges) {
            if (s[e.u] != s[e.v]) {
                ++cur;
                --gain[e.u]; --gain[e.v];
            } else {
                ++gain[e.u]; ++gain[e.v];
            }
        }
        priority_queue<tuple<int,int,int>> pq;
        for (int v = 0; v < n; ++v) pq.emplace(gain[v], v, ver[v]);
        while (!pq.empty()) {
            auto [g, v, version] = pq.top(); pq.pop();
            if (version != ver[v] || g != gain[v]) continue;
            if (g <= 0) break;
            cur += g;
            s[v] ^= 1;
            gain[v] = -gain[v];
            ++ver[v];
            pq.emplace(gain[v], v, ver[v]);
            for (int u : adj[v]) {
                // Relation before the flip determines the neighbor's gain change.
                if (s[u] == s[v]) gain[u] += 2;
                else gain[u] -= 2;
                ++ver[u];
                pq.emplace(gain[u], u, ver[u]);
            }
        }
        return {move(s), cur};
    };

    auto consider = [&](vector<int> s) {
        auto res = improve(move(s));
        if (res.second > bestScore) {
            bestScore = res.second;
            best = move(res.first);
        }
    };

    // Seed with a randomized greedy construction in a random vertex order.
    vector<int> order(n);
    iota(order.begin(), order.end(), 0);
    shuffle(order.begin(), order.end(), rng);
    vector<int> initial(n, -1);
    for (int v : order) {
        int cnt[2] = {0, 0};
        for (int u : adj[v]) if (initial[u] != -1) ++cnt[initial[u]];
        if (cnt[0] == cnt[1]) initial[v] = (rng() & 1);
        else initial[v] = (cnt[0] > cnt[1] ? 1 : 0);
    }
    consider(initial);

    auto start = chrono::steady_clock::now();
    const double limitSeconds = 1.72;
    int rounds = 0;
    while (chrono::duration<double>(chrono::steady_clock::now() - start).count() < limitSeconds) {
        vector<int> s;
        if ((rounds % 4) == 0 && bestScore >= 0) {
            s = best;
            int k = 1 + (rng() % 6);
            if (n > 1) k = min(k, n);
            for (int j = 0; j < k; ++j) s[rng() % n] ^= 1;
        } else {
            iota(order.begin(), order.end(), 0);
            shuffle(order.begin(), order.end(), rng);
            s.assign(n, -1);
            for (int v : order) {
                int cnt0 = 0, cnt1 = 0;
                for (int u : adj[v]) {
                    if (s[u] == 0) ++cnt0;
                    else if (s[u] == 1) ++cnt1;
                }
                if (cnt0 == cnt1) s[v] = (rng() & 1);
                else s[v] = (cnt0 > cnt1 ? 1 : 0);
            }
        }
        consider(move(s));
        ++rounds;
    }

    for (int i = 0; i < n; ++i) cout << (i ? " " : "") << best[i];
    cout << '\n';
    return 0;
}
