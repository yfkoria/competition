#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    if (!(cin >> n >> m)) return 0;
    vector<pair<int,int>> edges;
    edges.reserve(m);
    vector<vector<int>> adj(n);
    for (int i = 0; i < m; ++i) {
        int u, v; cin >> u >> v; --u; --v;
        edges.push_back({u,v});
        adj[u].push_back(v); adj[v].push_back(u);
    }
    if (m == 0) {
        for (int i=0;i<n;i++) cout << 0 << (i+1==n?'\n':' ');
        return 0;
    }
    mt19937 rng(2026110305u);
    vector<int> best(n,0), cur(n), gain(n), order(n), used(n);
    int bestVal = -1;
    auto deadline = chrono::steady_clock::now() + chrono::milliseconds(1750);
    int iteration = 0;
    while (chrono::steady_clock::now() < deadline) {
        ++iteration;
        iota(order.begin(), order.end(), 0);
        // Randomized ordering, with a mild preference for high degree vertices.
        shuffle(order.begin(), order.end(), rng);
        if (iteration % 3 != 0) {
            stable_sort(order.begin(), order.end(), [&](int a, int b) {
                int da=adj[a].size(), db=adj[b].size();
                if (da != db) return da > db;
                return false;
            });
        }
        fill(used.begin(), used.end(), 0);
        fill(cur.begin(), cur.end(), 0);
        for (int v : order) {
            int same=0, other=0;
            for (int u : adj[v]) if (used[u]) {
                if (cur[u] == 0) ++same; else ++other;
            }
            if (same > other) cur[v]=1;
            else if (other > same) cur[v]=0;
            else cur[v]=rng() & 1;
            used[v]=1;
        }
        // Steepest local improvement using an incrementally maintained flip gain.
        for (int v=0; v<n; ++v) {
            int g=0;
            for (int u: adj[v]) g += (cur[u]==cur[v] ? 1 : -1);
            gain[v]=g;
        }
        vector<int> q(n);
        iota(q.begin(),q.end(),0);
        shuffle(q.begin(),q.end(),rng);
        size_t head=0;
        while (head<q.size()) {
            int v=q[head++];
            if (gain[v] <= 0) continue;
            cur[v]^=1;
            gain[v]=-gain[v];
            for (int u:adj[v]) {
                gain[u] += (cur[u]==cur[v] ? 2 : -2);
                q.push_back(u);
            }
        }
        int val=0;
        for (auto [u,v]:edges) val += (cur[u]!=cur[v]);
        if (val>bestVal) { bestVal=val; best=cur; }
    }
    for (int i=0;i<n;i++) cout << best[i] << (i+1==n?'\n':' ');
    return 0;
}
