#include <bits/stdc++.h>
using namespace std;

struct Cell { int x, y; };
static bool operator==(const Cell& a, const Cell& b) { return a.x == b.x && a.y == b.y; }
struct RowMask { int dy, x0, len; uint16_t mask; };
struct Variant {
    int f, r, w, h, ox, oy;
    vector<Cell> cells;
    vector<RowMask> rows;
};
struct Piece {
    int k = 0, bboxArea = 0, maxSide = 0, minW = 0;
    vector<Variant> vars;
};
struct Placement { int X = 0, Y = 0, R = 0, F = 0; };
struct Result {
    vector<Placement> p;
    int W = 0, H = 0;
    long long area = (1LL << 60);
};

static vector<Cell> normalizeCells(const vector<Cell>& raw, int f, int r, int& ox, int& oy, int& w, int& h) {
    vector<Cell> t;
    int minx = INT_MAX, miny = INT_MAX, maxx = INT_MIN, maxy = INT_MIN;
    for (auto c : raw) {
        int x = c.x, y = c.y;
        if (f) x = -x;
        for (int j = 0; j < r; ++j) {
            int nx = y, ny = -x;
            x = nx; y = ny;
        }
        t.push_back({x, y});
        minx = min(minx, x); miny = min(miny, y);
        maxx = max(maxx, x); maxy = max(maxy, y);
    }
    ox = minx; oy = miny;
    w = maxx - minx + 1; h = maxy - miny + 1;
    for (auto& c : t) { c.x -= minx; c.y -= miny; }
    sort(t.begin(), t.end(), [](const Cell& a, const Cell& b) {
        return a.y != b.y ? a.y < b.y : a.x < b.x;
    });
    return t;
}

static Variant makeVariant(const vector<Cell>& raw, int f, int r) {
    Variant v; v.f = f; v.r = r;
    v.cells = normalizeCells(raw, f, r, v.ox, v.oy, v.w, v.h);
    for (int y = 0; y < v.h; ++y) {
        int lo = INT_MAX, hi = INT_MIN;
        for (auto c : v.cells) if (c.y == y) { lo = min(lo, c.x); hi = max(hi, c.x); }
        uint16_t m = 0;
        for (auto c : v.cells) if (c.y == y) m |= (uint16_t(1) << (c.x - lo));
        v.rows.push_back({y, lo, hi - lo + 1, m});
    }
    return v;
}

static uint64_t getBits(const vector<vector<uint64_t>>& occ, int y, int x, int len) {
    if (y < 0 || y >= (int)occ.size()) return 0;
    int wi = x >> 6, off = x & 63;
    uint64_t z = occ[y][wi] >> off;
    if (off + len > 64 && wi + 1 < (int)occ[y].size()) z |= occ[y][wi + 1] << (64 - off);
    return z;
}

static bool fits(const vector<vector<uint64_t>>& occ, int x, int y, const Variant& v) {
    for (const auto& row : v.rows)
        if (getBits(occ, y + row.dy, x + row.x0, row.len) & row.mask) return false;
    return true;
}

static bool occupied(const vector<vector<uint64_t>>& occ, int x, int y) {
    if (x < 0 || y < 0 || y >= (int)occ.size()) return false;
    int wi = x >> 6;
    if (wi >= (int)occ[y].size()) return false;
    return (occ[y][wi] >> (x & 63)) & 1ULL;
}

static int contactScore(const vector<vector<uint64_t>>& occ, int x, int y, const Variant& v, int W) {
    int s = 0;
    static const int dx[4] = {1, -1, 0, 0};
    static const int dy[4] = {0, 0, 1, -1};
    for (auto c : v.cells) for (int d = 0; d < 4; ++d) {
        int xx = x + c.x + dx[d], yy = y + c.y + dy[d];
        if (xx >= 0 && xx < W && occupied(occ, xx, yy)) ++s;
    }
    return s;
}

static void putPiece(vector<vector<uint64_t>>& occ, int words, int x, int y, const Variant& v) {
    while ((int)occ.size() < y + v.h) occ.emplace_back(words, 0ULL);
    for (auto c : v.cells) occ[y + c.y][(x + c.x) >> 6] |= 1ULL << ((x + c.x) & 63);
}

static void setPlacement(Result& out, int id, int x, int y, const Variant& v) {
    out.p[id] = {x - v.ox, y - v.oy, v.r, v.f};
}

static void measure(Result& out, const vector<Piece>& pieces) {
    int mx = 0, my = 0;
    for (int i = 0; i < (int)pieces.size(); ++i) {
        const Placement& p = out.p[i];
        const Variant* chosen = nullptr;
        for (const auto& v : pieces[i].vars) if (v.f == p.F && v.r == p.R) { chosen = &v; break; }
        if (!chosen) continue;
        int px = p.X + chosen->ox, py = p.Y + chosen->oy;
        mx = max(mx, px + chosen->w);
        my = max(my, py + chosen->h);
    }
    out.W = max(1, mx); out.H = max(1, my);
    out.area = 1LL * out.W * out.H;
}

static Result shelfResult(const vector<Piece>& pieces) {
    int n = pieces.size();
    long long boxSum = 0;
    int needW = 1;
    for (const auto& p : pieces) {
        boxSum += p.bboxArea;
        needW = max(needW, p.minW);
    }
    int shelfW = max(needW, (int)ceil(sqrt((double)boxSum) * 1.12));
    vector<int> chosen(n), ids(n);
    iota(ids.begin(), ids.end(), 0);
    vector<int> heights(n);
    for (int i = 0; i < n; ++i) {
        int best = -1;
        for (int j = 0; j < (int)pieces[i].vars.size(); ++j) {
            const auto& v = pieces[i].vars[j];
            if (v.w > shelfW) continue;
            if (best < 0 || tie(v.h, v.w) < tie(pieces[i].vars[best].h, pieces[i].vars[best].w)) best = j;
        }
        if (best < 0) best = 0;
        chosen[i] = best; heights[i] = pieces[i].vars[best].h;
    }
    stable_sort(ids.begin(), ids.end(), [&](int a, int b) {
        if (heights[a] != heights[b]) return heights[a] > heights[b];
        if (pieces[a].bboxArea != pieces[b].bboxArea) return pieces[a].bboxArea > pieces[b].bboxArea;
        return pieces[a].k > pieces[b].k;
    });
    Result out; out.p.resize(n);
    int x = 0, y = 0, rowH = 0;
    for (int id : ids) {
        const Variant& v = pieces[id].vars[chosen[id]];
        if (x + v.w > shelfW) { y += rowH; x = 0; rowH = 0; }
        setPlacement(out, id, x, y, v);
        x += v.w;
        rowH = max(rowH, v.h);
    }
    measure(out, pieces);
    return out;
}

static Result greedyResult(const vector<Piece>& pieces, const vector<int>& order, int W,
                           clock_t start, double timeLimit, bool& interrupted) {
    int n = pieces.size(), words = (W + 63) / 64;
    vector<vector<uint64_t>> occ;
    Result out; out.p.resize(n);
    int usedH = 0;
    int done = 0;
    for (; done < n; ++done) {
        int id = order[done];
        bool found = false;
        int bx = 0, by = 0, bv = -1;
        for (int y = 0; y <= usedH && !found; ++y) {
            for (int x = 0; x < W && !found; ++x) {
                int bestContact = -1, bestVar = -1;
                for (int j = 0; j < (int)pieces[id].vars.size(); ++j) {
                    const Variant& v = pieces[id].vars[j];
                    if (x + v.w > W || !fits(occ, x, y, v)) continue;
                    int c = contactScore(occ, x, y, v, W);
                    if (c > bestContact) { bestContact = c; bestVar = j; }
                }
                if (bestVar >= 0) { found = true; bx = x; by = y; bv = bestVar; }
            }
        }
        if (!found) {
            // A fresh row above all existing cells always fits because W covers each piece's minimum width.
            by = usedH; bx = 0; bv = 0;
            for (int j = 0; j < (int)pieces[id].vars.size(); ++j)
                if (pieces[id].vars[j].w <= W && (bv < 0 || pieces[id].vars[j].h < pieces[id].vars[bv].h)) bv = j;
        }
        const Variant& v = pieces[id].vars[bv];
        setPlacement(out, id, bx, by, v);
        putPiece(occ, words, bx, by, v);
        usedH = max(usedH, by + v.h);
        if ((done & 15) == 15 && double(clock() - start) / CLOCKS_PER_SEC >= timeLimit) {
            ++done;
            interrupted = true;
            break;
        }
    }
    if (interrupted) {
        int x = 0, y = usedH, rowH = 0;
        for (int q = done; q < n; ++q) {
            int id = order[q], best = -1;
            for (int j = 0; j < (int)pieces[id].vars.size(); ++j) {
                const Variant& v = pieces[id].vars[j];
                if (v.w <= W && (best < 0 || tie(v.h, v.w) < tie(pieces[id].vars[best].h, pieces[id].vars[best].w))) best = j;
            }
            if (best < 0) best = 0;
            const Variant& v = pieces[id].vars[best];
            if (x + v.w > W) { y += rowH; x = 0; rowH = 0; }
            setPlacement(out, id, x, y, v);
            x += v.w; rowH = max(rowH, v.h);
        }
    }
    measure(out, pieces);
    return out;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    clock_t start = clock();
    int n;
    if (!(cin >> n)) return 0;
    vector<Piece> pieces(n);
    long long totalCells = 0;
    int globalMinW = 1;
    for (int i = 0; i < n; ++i) {
        int k; cin >> k;
        pieces[i].k = k; totalCells += k;
        vector<Cell> raw(k);
        for (auto& c : raw) cin >> c.x >> c.y;
        for (int f = 0; f <= 1; ++f) for (int r = 0; r < 4; ++r) {
            Variant v = makeVariant(raw, f, r);
            bool duplicate = false;
            for (const auto& old : pieces[i].vars) if (old.cells == v.cells) { duplicate = true; break; }
            if (!duplicate) pieces[i].vars.push_back(std::move(v));
        }
        sort(pieces[i].vars.begin(), pieces[i].vars.end(), [](const Variant& a, const Variant& b) {
            if (a.w + a.h != b.w + b.h) return a.w + a.h < b.w + b.h;
            if (a.w != b.w) return a.w < b.w;
            return a.h < b.h;
        });
        pieces[i].bboxArea = pieces[i].vars[0].w * pieces[i].vars[0].h;
        pieces[i].minW = INT_MAX;
        for (const auto& v : pieces[i].vars) {
            pieces[i].minW = min(pieces[i].minW, v.w);
            pieces[i].maxSide = max(pieces[i].maxSide, max(v.w, v.h));
        }
        globalMinW = max(globalMinW, pieces[i].minW);
    }

    Result best = shelfResult(pieces);
    vector<int> order(n);
    iota(order.begin(), order.end(), 0);
    stable_sort(order.begin(), order.end(), [&](int a, int b) {
        if (pieces[a].k != pieces[b].k) return pieces[a].k > pieces[b].k;
        if (pieces[a].bboxArea != pieces[b].bboxArea) return pieces[a].bboxArea > pieces[b].bboxArea;
        if (pieces[a].maxSide != pieces[b].maxSide) return pieces[a].maxSide > pieces[b].maxSide;
        if (pieces[a].minW != pieces[b].minW) return pieces[a].minW > pieces[b].minW;
        return a < b;
    });

    double factors[] = {1.08, 0.90, 1.32, 1.50, 1.00, 0.78};
    set<int> tried;
    bool stop = false;
    for (double factor : factors) {
        if (double(clock() - start) / CLOCKS_PER_SEC >= 1.45) break;
        int W = max(globalMinW, (int)ceil(sqrt((double)totalCells) * factor));
        if (!tried.insert(W).second) continue;
        bool interrupted = false;
        Result cur = greedyResult(pieces, order, W, start, 1.45, interrupted);
        if (cur.area < best.area || (cur.area == best.area && tie(cur.H, cur.W) < tie(best.H, best.W))) best = std::move(cur);
        if (interrupted) { stop = true; break; }
    }
    (void)stop;
    cout << best.W << ' ' << best.H << '\n';
    for (const auto& p : best.p) cout << p.X << ' ' << p.Y << ' ' << p.R << ' ' << p.F << '\n';
    return 0;
}
