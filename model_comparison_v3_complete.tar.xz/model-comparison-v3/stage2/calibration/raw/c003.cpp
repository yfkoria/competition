#include <bits/stdc++.h>
using namespace std;

struct Parser {
    string s;
    size_t pos = 0;

    explicit Parser(string input) : s(move(input)) {}

    void spaces() {
        while (pos < s.size() && isspace(static_cast<unsigned char>(s[pos]))) ++pos;
    }

    bool take(char c) {
        spaces();
        if (pos < s.size() && s[pos] == c) {
            ++pos;
            return true;
        }
        return false;
    }

    string rawString() {
        spaces();
        size_t begin = pos;
        if (pos < s.size() && s[pos] == '"') ++pos;
        while (pos < s.size()) {
            char c = s[pos++];
            if (c == '\\') {
                if (pos < s.size()) ++pos;
            } else if (c == '"') {
                break;
            }
        }
        return s.substr(begin, pos - begin);
    }

    long long number() {
        spaces();
        bool negative = take('-');
        long long value = 0;
        while (pos < s.size() && s[pos] >= '0' && s[pos] <= '9') {
            value = value * 10 + (s[pos++] - '0');
        }
        return negative ? -value : value;
    }

    bool boolean() {
        spaces();
        if (s.compare(pos, 4, "true") == 0) {
            pos += 4;
            return true;
        }
        pos += 5;
        return false;
    }
};

struct Item {
    string id;
    int w = 0, h = 0, limit = 0;
    long long value = 0, area = 0;
    double density = 0;
};

struct Region {
    int x = 0, y = 0, w = 0, h = 0;
};

struct Option {
    int type, w, h, rot;
};

struct Placement {
    int type, x, y, rot;
};

struct Config {
    double alpha, look, grid, continuity, bias, jitter;
    int regionMode, splitMode;
};

struct Result {
    long long value = 0;
    vector<Placement> placements;
};

int binW = 0, binH = 0;
bool allowRotate = false;
vector<Item> items;
vector<Option> options;
vector<int> densityOrder;
mt19937_64 randomEngine(2026110305ULL);

double randomUnit() {
    return static_cast<double>(randomEngine() >> 11) * (1.0 / 9007199254740992.0);
}

void readBin(Parser &p) {
    p.take('{');
    while (!p.take('}')) {
        string key = p.rawString();
        p.take(':');
        if (key == "\"W\"") binW = static_cast<int>(p.number());
        else if (key == "\"H\"") binH = static_cast<int>(p.number());
        else if (key == "\"allow_rotate\"") allowRotate = p.boolean();
        if (p.take('}')) break;
        p.take(',');
    }
}

Item readItem(Parser &p) {
    Item item;
    p.take('{');
    while (!p.take('}')) {
        string key = p.rawString();
        p.take(':');
        if (key == "\"type\"") item.id = p.rawString();
        else if (key == "\"w\"") item.w = static_cast<int>(p.number());
        else if (key == "\"h\"") item.h = static_cast<int>(p.number());
        else if (key == "\"v\"") item.value = p.number();
        else if (key == "\"limit\"") item.limit = static_cast<int>(p.number());
        if (p.take('}')) break;
        p.take(',');
    }
    item.area = 1LL * item.w * item.h;
    item.density = static_cast<double>(item.value) / item.area;
    return item;
}

void readItems(Parser &p) {
    p.take('[');
    while (!p.take(']')) {
        items.push_back(readItem(p));
        if (p.take(']')) break;
        p.take(',');
    }
}

void readInput(Parser &p) {
    p.take('{');
    while (!p.take('}')) {
        string key = p.rawString();
        p.take(':');
        if (key == "\"bin\"") readBin(p);
        else if (key == "\"items\"") readItems(p);
        if (p.take('}')) break;
        p.take(',');
    }
}

long long areaOf(const Region &r) {
    return 1LL * r.w * r.h;
}

int capacity(const Region &r, const Item &item) {
    if (r.w <= 0 || r.h <= 0) return 0;
    int count = 0;
    if (r.w >= item.w && r.h >= item.h)
        count = (r.w / item.w) * (r.h / item.h);
    if (allowRotate && item.w != item.h && r.w >= item.h && r.h >= item.w)
        count = max(count, (r.w / item.h) * (r.h / item.w));
    return count;
}

double estimate(const Region &a, const Region &b, const vector<int> &remaining) {
    long long vacant = areaOf(a) + areaOf(b);
    double total = 0;
    for (int t : densityOrder) {
        if (vacant == 0) break;
        if (remaining[t] == 0) continue;
        int cap = capacity(a, items[t]) + capacity(b, items[t]);
        if (cap == 0) continue;
        long long copies = min<long long>(remaining[t], cap);
        long long covered = min(vacant, copies * items[t].area);
        total += covered * items[t].density;
        vacant -= covered;
    }
    return total;
}

struct Node {
    long long key;
    int serial;
    Region region;

    bool operator<(const Node &other) const {
        if (key != other.key) return key < other.key;
        return serial < other.serial;
    }
};

Result pack(const Config &cfg, clock_t beginning) {
    vector<int> remaining(items.size());
    vector<double> base(items.size()), bias(items.size());
    for (size_t i = 0; i < items.size(); ++i) {
        remaining[i] = items[i].limit;
        base[i] = static_cast<double>(items[i].value) /
                  pow(static_cast<double>(items[i].area), cfg.alpha);
        bias[i] = exp((2.0 * randomUnit() - 1.0) * cfg.bias);
    }

    priority_queue<Node> regions;
    int serial = 0;
    auto addRegion = [&](const Region &r) {
        if (r.w <= 0 || r.h <= 0) return;
        long long a = areaOf(r);
        long long key;
        if (cfg.regionMode == 0) {
            key = a * 1000000LL + static_cast<long long>(randomUnit() * 100000.0);
        } else if (cfg.regionMode == 1) {
            key = -1000000000000LL * r.y - 10000000LL * r.x + a;
        } else if (cfg.regionMode == 2) {
            key = -1000000000000LL * r.x - 10000000LL * r.y + a;
        } else if (cfg.regionMode == 3) {
            key = serial;
        } else {
            key = static_cast<long long>(a * (0.65 + 0.7 * randomUnit()) * 1000000.0);
        }
        regions.push({key, serial++, r});
    };

    addRegion({0, 0, binW, binH});
    Result answer;
    answer.placements.reserve(2100);
    const Region empty{};
    int processed = 0;

    while (!regions.empty()) {
        if ((processed++ & 31) == 0 &&
            static_cast<double>(clock() - beginning) / CLOCKS_PER_SEC > 1.72)
            break;

        Region r = regions.top().region;
        regions.pop();
        bool needEstimate = cfg.look > 0.0 || cfg.splitMode == 0;
        double original = needEstimate ? estimate(r, empty, remaining) : 1.0;
        double bestScore = -1.0;
        int bestOption = -1, bestSplit = 0;

        for (int oi = 0; oi < static_cast<int>(options.size()); ++oi) {
            const Option &opt = options[oi];
            if (remaining[opt.type] == 0 || opt.w > r.w || opt.h > r.h) continue;

            int rightWidth = r.w - opt.w;
            int upperHeight = r.h - opt.h;
            Region rightTall{r.x + opt.w, r.y, rightWidth, r.h};
            Region upperNarrow{r.x, r.y + opt.h, opt.w, upperHeight};
            Region rightShort{r.x + opt.w, r.y, rightWidth, opt.h};
            Region upperWide{r.x, r.y + opt.h, r.w, upperHeight};

            double estimateA = 0.0, estimateB = 0.0;
            if (needEstimate) {
                --remaining[opt.type];
                estimateA = estimate(rightTall, upperNarrow, remaining);
                estimateB = estimate(rightShort, upperWide, remaining);
                ++remaining[opt.type];
            }

            int split = 0;
            if (cfg.splitMode == 1) {
                split = 0;
            } else if (cfg.splitMode == 2) {
                split = 1;
            } else if (cfg.splitMode == 3) {
                split = randomUnit() < 0.5 ? 0 : 1;
            } else if (cfg.splitMode == 4) {
                split = rightWidth < upperHeight ? 1 : 0;
            } else {
                double bonusA = cfg.continuity * original *
                                static_cast<double>(max(areaOf(rightTall), areaOf(upperNarrow))) /
                                areaOf(r);
                double bonusB = cfg.continuity * original *
                                static_cast<double>(max(areaOf(rightShort), areaOf(upperWide))) /
                                areaOf(r);
                split = estimateB + bonusB > estimateA + bonusA ? 1 : 0;
            }

            double score = base[opt.type] * bias[opt.type];
            if (cfg.look > 0.0) {
                double future = split == 0 ? estimateA : estimateB;
                double ratio = (items[opt.type].value + future) / max(1.0, original);
                ratio = min(1.2, max(0.0, ratio));
                score *= 1.0 + cfg.look * (ratio - 1.0);
            }
            if (cfg.grid > 0.0) {
                long long cap = 1LL * (r.w / opt.w) * (r.h / opt.h);
                double fraction = static_cast<double>(cap * items[opt.type].area) / areaOf(r);
                score *= 1.0 + cfg.grid * (fraction - 1.0);
            }
            if (opt.w == r.w) score *= 1.012;
            if (opt.h == r.h) score *= 1.012;
            if (cfg.jitter > 0.0)
                score *= 1.0 + cfg.jitter * (2.0 * randomUnit() - 1.0);

            if (score > bestScore) {
                bestScore = score;
                bestOption = oi;
                bestSplit = split;
            }
        }

        if (bestOption < 0) continue;
        const Option &chosen = options[bestOption];
        answer.placements.push_back({chosen.type, r.x, r.y, chosen.rot});
        answer.value += items[chosen.type].value;
        --remaining[chosen.type];

        if (bestSplit == 0) {
            addRegion({r.x + chosen.w, r.y, r.w - chosen.w, r.h});
            addRegion({r.x, r.y + chosen.h, chosen.w, r.h - chosen.h});
        } else {
            addRegion({r.x + chosen.w, r.y, r.w - chosen.w, chosen.h});
            addRegion({r.x, r.y + chosen.h, r.w, r.h - chosen.h});
        }
    }
    return answer;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    string input((istreambuf_iterator<char>(cin)), istreambuf_iterator<char>());
    Parser parser(move(input));
    readInput(parser);

    for (int t = 0; t < static_cast<int>(items.size()); ++t) {
        options.push_back({t, items[t].w, items[t].h, 0});
        if (allowRotate && items[t].w != items[t].h)
            options.push_back({t, items[t].h, items[t].w, 1});
        densityOrder.push_back(t);
    }
    sort(densityOrder.begin(), densityOrder.end(), [](int a, int b) {
        if (items[a].density != items[b].density)
            return items[a].density > items[b].density;
        return items[a].value > items[b].value;
    });

    vector<Config> presets = {
        {1.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0, 4},
        {1.00, 0.65, 0.07, 0.03, 0.00, 0.00, 0, 0},
        {0.86, 0.55, 0.10, 0.03, 0.00, 0.00, 0, 0},
        {1.14, 0.55, 0.06, 0.03, 0.00, 0.00, 0, 0},
        {1.00, 0.40, 0.08, 0.00, 0.00, 0.00, 1, 2},
        {1.00, 0.40, 0.08, 0.00, 0.00, 0.00, 2, 1},
        {0.73, 0.55, 0.10, 0.04, 0.00, 0.00, 0, 0},
        {1.27, 0.55, 0.10, 0.04, 0.00, 0.00, 0, 0},
        {1.00, 0.75, 0.04, 0.02, 0.00, 0.00, 3, 0}
    };

    clock_t beginning = clock();
    Result best;
    for (int attempt = 0;; ++attempt) {
        if (attempt > 0 &&
            static_cast<double>(clock() - beginning) / CLOCKS_PER_SEC > 1.55)
            break;

        Config cfg;
        if (attempt < static_cast<int>(presets.size())) {
            cfg = presets[attempt];
        } else {
            cfg.alpha = 0.72 + 0.60 * randomUnit();
            cfg.look = 0.15 + 0.75 * randomUnit();
            cfg.grid = 0.02 + 0.18 * randomUnit();
            cfg.continuity = 0.08 * randomUnit();
            cfg.bias = 0.05 + 0.45 * randomUnit();
            cfg.jitter = 0.10 * randomUnit();
            cfg.regionMode = static_cast<int>(randomEngine() % 5);
            cfg.splitMode = static_cast<int>(randomEngine() % 5);
        }

        Result candidate = pack(cfg, beginning);
        if (candidate.value > best.value) best = move(candidate);
    }

    cout << "{\"placements\":[";
    for (size_t i = 0; i < best.placements.size(); ++i) {
        if (i) cout << ',';
        const Placement &p = best.placements[i];
        cout << "{\"type\":" << items[p.type].id << ",\"x\":" << p.x
             << ",\"y\":" << p.y << ",\"rot\":" << p.rot << '}';
    }
    cout << "]}\n";
    return 0;
}
