#include <bits/stdc++.h>
using namespace std;

using u8 = unsigned char;

static inline int literal_node(int x) {
    return 2 * (abs(x) - 1) + (x > 0);
}

static bool solve_2sat(int n, const vector<pair<int, int>>& raw, int skip,
                       vector<u8>& assignment, vector<int>* components = nullptr) {
    const int nodes = 2 * n;
    vector<vector<int>> graph(nodes), reverse_graph(nodes);
    for (int i = 0; i < (int)raw.size(); ++i) {
        if (i == skip) continue;
        int a = literal_node(raw[i].first);
        int b = literal_node(raw[i].second);
        graph[a ^ 1].push_back(b);
        reverse_graph[b].push_back(a ^ 1);
        graph[b ^ 1].push_back(a);
        reverse_graph[a].push_back(b ^ 1);
    }

    vector<u8> seen(nodes, 0);
    vector<int> order;
    order.reserve(nodes);
    function<void(int)> dfs1 = [&](int v) {
        seen[v] = 1;
        for (int w : graph[v]) if (!seen[w]) dfs1(w);
        order.push_back(v);
    };
    for (int v = 0; v < nodes; ++v) if (!seen[v]) dfs1(v);

    vector<int> component(nodes, -1);
    function<void(int, int)> dfs2 = [&](int v, int id) {
        component[v] = id;
        for (int w : reverse_graph[v]) if (component[w] < 0) dfs2(w, id);
    };
    int count = 0;
    for (int i = nodes - 1; i >= 0; --i) {
        int v = order[i];
        if (component[v] < 0) dfs2(v, count++);
    }

    bool feasible = true;
    assignment.resize(n);
    for (int i = 0; i < n; ++i) {
        if (component[2 * i] == component[2 * i + 1]) feasible = false;
        assignment[i] = component[2 * i + 1] > component[2 * i];
    }
    if (components) *components = move(component);
    return feasible;
}

struct DSU {
    vector<int> parent, size;
    explicit DSU(int n) : parent(n), size(n, 1) {
        iota(parent.begin(), parent.end(), 0);
    }
    int find(int x) {
        while (parent[x] != x) {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        return x;
    }
    void unite(int x, int y) {
        x = find(x);
        y = find(y);
        if (x == y) return;
        if (size[x] < size[y]) swap(x, y);
        parent[y] = x;
        size[x] += size[y];
    }
};

struct Clause {
    int x, y, raw_id;
    u8 sx, sy;
};

struct Occurrence {
    int clause, other;
    u8 sign, other_sign;
};

struct RNG {
    uint64_t state = 2026110305ULL;
    uint32_t next() {
        uint64_t z = (state += 0x9e3779b97f4a7c15ULL);
        z = (z ^ (z >> 30)) * 0xbf58476d1ce4e5b9ULL;
        z = (z ^ (z >> 27)) * 0x94d049bb133111ebULL;
        return uint32_t((z ^ (z >> 31)) >> 32);
    }
    int pick(int bound) { return int(next() % uint32_t(bound)); }
};

struct Search {
    int n, lower_bound;
    vector<Clause> clauses;
    vector<vector<Occurrence>> incident;
    vector<u8> value, best_value;
    vector<int> gain, bad, position;
    int best_cost = INT_MAX;
    RNG rng;

    Search(int n_, const vector<pair<int, int>>& raw, int lower)
        : n(n_), lower_bound(lower), incident(n_), value(n_), best_value(n_), gain(n_) {
        for (int i = 0; i < (int)raw.size(); ++i) {
            int a = raw[i].first, b = raw[i].second;
            int x = abs(a) - 1, y = abs(b) - 1;
            u8 sx = a > 0, sy = b > 0;
            if (x == y) {
                if (sx != sy) continue;
                y = -1;
            }
            int id = (int)clauses.size();
            clauses.push_back({x, y, i, sx, sy});
            incident[x].push_back({id, y, sx, sy});
            if (y >= 0) incident[y].push_back({id, x, sy, sx});
        }
        position.resize(clauses.size(), -1);
        bad.reserve(clauses.size());
    }

    void add_bad(int c) {
        position[c] = (int)bad.size();
        bad.push_back(c);
    }
    void remove_bad(int c) {
        int p = position[c];
        int last = bad.back();
        bad[p] = last;
        position[last] = p;
        bad.pop_back();
        position[c] = -1;
    }

    void initialize(const vector<u8>& start) {
        value = start;
        fill(gain.begin(), gain.end(), 0);
        fill(position.begin(), position.end(), -1);
        bad.clear();
        for (int i = 0; i < (int)clauses.size(); ++i) {
            const Clause& c = clauses[i];
            bool tx = value[c.x] == c.sx;
            if (c.y < 0) {
                if (tx) --gain[c.x];
                else {
                    ++gain[c.x];
                    add_bad(i);
                }
                continue;
            }
            bool ty = value[c.y] == c.sy;
            if (!tx && !ty) {
                ++gain[c.x];
                ++gain[c.y];
                add_bad(i);
            } else if (tx && !ty) {
                --gain[c.x];
            } else if (!tx && ty) {
                --gain[c.y];
            }
        }
    }

    void flip(int x) {
        u8 old_value = value[x];
        int change_x = 0;
        for (const Occurrence& e : incident[x]) {
            bool tx = old_value == e.sign;
            int direction = tx ? 1 : -1;
            if (e.other < 0) {
                change_x += 2 * direction;
                if (tx) add_bad(e.clause);
                else remove_bad(e.clause);
                continue;
            }
            bool ty = value[e.other] == e.other_sign;
            if (!ty) {
                change_x += 2 * direction;
                gain[e.other] += direction;
                if (tx) add_bad(e.clause);
                else remove_bad(e.clause);
            } else {
                gain[e.other] -= direction;
            }
        }
        gain[x] += change_x;
        value[x] ^= 1;
    }

    void record() {
        int cost = (int)bad.size();
        if (cost < best_cost) {
            best_cost = cost;
            best_value = value;
        }
    }

    void climb(clock_t deadline) {
        for (int iteration = 0; best_cost > lower_bound; ++iteration) {
            if ((iteration & 63) == 0 && clock() >= deadline) return;
            int offset = rng.pick(n);
            int chosen = -1, top_gain = 0;
            for (int j = 0; j < n; ++j) {
                int v = offset + j;
                if (v >= n) v -= n;
                if (gain[v] > top_gain) {
                    top_gain = gain[v];
                    chosen = v;
                }
            }
            if (chosen < 0) return;
            flip(chosen);
            record();
        }
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    clock_t start_time = clock();

    int n, m;
    if (!(cin >> n >> m)) return 0;
    vector<pair<int, int>> raw(m);
    for (auto& clause : raw) cin >> clause.first >> clause.second;

    vector<u8> initial;
    vector<int> components;
    bool feasible = solve_2sat(n, raw, -1, initial, &components);
    if (feasible) {
        for (int i = 0; i < n; ++i) {
            if (i) cout << ' ';
            cout << int(initial[i]);
        }
        cout << '\n';
        return 0;
    }

    DSU dsu(n);
    for (auto [a, b] : raw) dsu.unite(abs(a) - 1, abs(b) - 1);
    vector<u8> unsat_component(n, 0);
    for (int i = 0; i < n; ++i) {
        if (components[2 * i] == components[2 * i + 1])
            unsat_component[dsu.find(i)] = 1;
    }
    int lower_bound = accumulate(unsat_component.begin(), unsat_component.end(), 0);
    Search search(n, raw, lower_bound);
    clock_t deadline = start_time + clock_t(1.85 * CLOCKS_PER_SEC);

    search.initialize(initial);
    search.record();
    search.climb(deadline);

    if (search.best_cost > lower_bound && clock() < deadline) {
        for (u8& bit : initial) bit ^= 1;
        search.initialize(initial);
        search.record();
        search.climb(deadline);
    }

    if (search.best_cost > lower_bound && clock() < deadline) {
        vector<int> balance(n, 0);
        for (auto [a, b] : raw) {
            balance[abs(a) - 1] += (a > 0 ? 1 : -1);
            balance[abs(b) - 1] += (b > 0 ? 1 : -1);
        }
        for (int i = 0; i < n; ++i)
            initial[i] = balance[i] == 0 ? search.rng.pick(2) : (balance[i] > 0);
        search.initialize(initial);
        search.record();
        search.climb(deadline);
    }

    auto try_single_deletion = [&]() {
        if (lower_bound != 1 || search.best_cost <= 1 || search.best_cost > 6) return;
        search.initialize(search.best_value);
        vector<int> candidates = search.bad;
        for (int c : candidates) {
            if (clock() >= deadline) break;
            vector<u8> solution;
            if (solve_2sat(n, raw, search.clauses[c].raw_id, solution)) {
                search.initialize(solution);
                search.record();
                return;
            }
        }
    };
    int last_exact_cost = INT_MAX;
    if (search.best_cost <= 6) {
        try_single_deletion();
        last_exact_cost = search.best_cost;
    }

    vector<long long> taboo_until(n, 0);
    long long step_number = 0;
    int epoch = 0;
    while (search.best_cost > lower_bound && clock() < deadline) {
        initial = search.best_value;
        if (epoch % 9 == 8) {
            for (u8& bit : initial) bit = search.rng.pick(2);
        } else {
            int kick;
            if (epoch % 3 == 0) kick = max(2, n / 50);
            else if (epoch % 3 == 1) kick = max(4, n / 10);
            else kick = max(8, n / 4);
            for (int j = 0; j < kick; ++j) initial[search.rng.pick(n)] ^= 1;
        }
        search.initialize(initial);
        search.record();
        search.climb(deadline);
        if (search.best_cost <= lower_bound) break;

        fill(taboo_until.begin(), taboo_until.end(), 0);
        int limit = 2000 + 6 * n;
        int stale = 0;
        for (int k = 0; k < limit && !search.bad.empty(); ++k) {
            if ((k & 255) == 0 && clock() >= deadline) break;
            int chosen = -1;
            int chosen_gain = INT_MIN;
            int bad_count = (int)search.bad.size();
            for (int sample = 0; sample < 10; ++sample) {
                const Clause& clause = search.clauses[search.bad[search.rng.pick(bad_count)]];
                int candidates[2] = {clause.x, clause.y};
                for (int j = 0; j < 2; ++j) {
                    int v = candidates[j];
                    if (v < 0) continue;
                    if (step_number < taboo_until[v] &&
                        bad_count - search.gain[v] >= search.best_cost) continue;
                    int g = search.gain[v];
                    if (g > chosen_gain || (g == chosen_gain && search.rng.pick(2) == 0)) {
                        chosen = v;
                        chosen_gain = g;
                    }
                }
            }
            if (chosen < 0 || search.rng.pick(100) < 3) {
                const Clause& clause = search.clauses[search.bad[search.rng.pick(bad_count)]];
                if (clause.y < 0) chosen = clause.x;
                else chosen = search.rng.pick(2) ? clause.x : clause.y;
            }
            search.flip(chosen);
            ++step_number;
            taboo_until[chosen] = step_number + 4 + search.rng.pick(8)
                                  + min(20, (int)search.bad.size() / 30);
            int previous_best = search.best_cost;
            search.record();
            if (search.best_cost < previous_best) stale = 0;
            else ++stale;
            if (search.best_cost <= lower_bound || stale > max(600, 3 * n)) break;
        }
        search.climb(deadline);
        if (search.best_cost < last_exact_cost && search.best_cost <= 6 && clock() < deadline) {
            try_single_deletion();
            last_exact_cost = search.best_cost;
        }
        ++epoch;
    }

    for (int i = 0; i < n; ++i) {
        if (i) cout << ' ';
        cout << int(search.best_value[i]);
    }
    cout << '\n';
}
