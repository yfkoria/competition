#include <bits/stdc++.h>
using namespace std;

struct Random {
    uint64_t state = 2026110305ULL;
    uint64_t next() {
        state ^= state >> 12;
        state ^= state << 25;
        state ^= state >> 27;
        return state * 2685821657736338717ULL;
    }
    int get(int n) { return int(next() % (uint64_t)n); }
    double real() { return (next() >> 11) * 0x1.0p-53; }
    float normal() {
        double u = max(1e-15, real());
        return float(sqrt(-2.0 * log(u)) * cos(6.2831853071795864769 * real()));
    }
} rnd;

struct Dinic {
    struct Edge { int to, rev, cap; };
    int n;
    vector<vector<Edge>> g;
    vector<int> level, ptr;
    Dinic(int n) : n(n), g(n), level(n), ptr(n) {}
    void directed(int u, int v, int c) {
        if (!c) return;
        int a = int(g[u].size()), b = int(g[v].size());
        g[u].push_back({v, b, c});
        g[v].push_back({u, a, 0});
    }
    void undirected(int u, int v, int c) {
        if (!c) return;
        int a = int(g[u].size()), b = int(g[v].size());
        g[u].push_back({v, b, c});
        g[v].push_back({u, a, c});
    }
    bool bfs(int s, int t) {
        fill(level.begin(), level.end(), -1);
        vector<int> q(n);
        int lo = 0, hi = 0;
        q[hi++] = s;
        level[s] = 0;
        while (lo < hi) {
            int v = q[lo++];
            for (const auto &e : g[v]) if (e.cap > 0 && level[e.to] < 0) {
                level[e.to] = level[v] + 1;
                q[hi++] = e.to;
            }
        }
        return level[t] >= 0;
    }
    int dfs(int v, int t, int flow) {
        if (v == t) return flow;
        for (int &i = ptr[v]; i < (int)g[v].size(); ++i) {
            Edge &e = g[v][i];
            if (e.cap <= 0 || level[e.to] != level[v] + 1) continue;
            int got = dfs(e.to, t, min(flow, e.cap));
            if (got) {
                e.cap -= got;
                g[e.to][e.rev].cap += got;
                return got;
            }
        }
        return 0;
    }
    int flow(int s, int t) {
        int ans = 0;
        while (bfs(s, t)) {
            fill(ptr.begin(), ptr.end(), 0);
            while (int f = dfs(s, t, 1000000000)) ans += f;
        }
        return ans;
    }
    vector<char> reachable(int s) const {
        vector<char> seen(n, 0);
        vector<int> q;
        q.push_back(s);
        seen[s] = 1;
        for (size_t k = 0; k < q.size(); ++k) {
            int v = q[k];
            for (const auto &e : g[v]) if (e.cap > 0 && !seen[e.to]) {
                seen[e.to] = 1;
                q.push_back(e.to);
            }
        }
        return seen;
    }
};

struct Rule {
    int v, bias;
    vector<pair<int, int>> neighbors;
};

struct Kernel {
    int n;
    vector<int> h, strength;
    vector<unordered_map<int, int>> adj;
    vector<char> alive, queued;
    deque<int> pending;
    vector<Rule> rules;
    Kernel(int n) : n(n), h(n), strength(n), adj(n), alive(n), queued(n) {}
    void touch(int v) {
        if (alive[v] && !queued[v]) {
            queued[v] = 1;
            pending.push_back(v);
        }
    }
    void edge(int u, int v, int delta) {
        if (!delta || u == v) return;
        auto it = adj[u].find(v);
        int old = it == adj[u].end() ? 0 : it->second;
        int now = old + delta;
        if (now) {
            adj[u][v] = now;
            adj[v][u] = now;
        } else {
            adj[u].erase(v);
            adj[v].erase(u);
        }
        strength[u] += abs(now) - abs(old);
        strength[v] += abs(now) - abs(old);
        touch(u);
        touch(v);
    }
    vector<pair<int, int>> neighbors(int v) const {
        vector<pair<int, int>> a(adj[v].begin(), adj[v].end());
        sort(a.begin(), a.end());
        return a;
    }
    void detach(int v, const vector<pair<int, int>> &a) {
        alive[v] = 0;
        for (auto [u, w] : a) edge(v, u, -w);
        h[v] = 0;
        strength[v] = 0;
    }
    void fix(int v, int s) {
        if (!alive[v]) return;
        auto a = neighbors(v);
        rules.push_back({v, s, {}});
        detach(v, a);
        for (auto [u, w] : a) {
            h[u] += w * s;
            touch(u);
        }
    }
    void reduce() {
        for (int v = 0; v < n; ++v) touch(v);
        while (!pending.empty()) {
            int v = pending.front();
            pending.pop_front();
            queued[v] = 0;
            if (!alive[v]) continue;
            if (abs(h[v]) >= strength[v]) {
                fix(v, h[v] >= 0 ? 1 : -1);
                continue;
            }
            int degree = int(adj[v].size());
            if (degree <= 2 || (degree == 3 && h[v] == 0)) {
                auto a = neighbors(v);
                int bias = h[v];
                rules.push_back({v, bias, a});
                detach(v, a);
                if (degree == 1) {
                    int u = a[0].first, w = a[0].second;
                    h[u] += (abs(bias + w) - abs(bias - w)) / 2;
                    touch(u);
                } else if (degree == 2) {
                    int u = a[0].first, z = a[1].first;
                    int w = a[0].second, t = a[1].second;
                    int pp = abs(bias + w + t), pm = abs(bias + w - t);
                    int mp = abs(bias - w + t), mm = abs(bias - w - t);
                    h[u] += (pp + pm - mp - mm) / 4;
                    h[z] += (pp - pm + mp - mm) / 4;
                    edge(u, z, (pp - pm - mp + mm) / 4);
                    touch(u);
                    touch(z);
                } else if (degree == 3) {
                    int u = a[0].first, z = a[1].first, t = a[2].first;
                    int x = a[0].second, y = a[1].second, w = a[2].second;
                    int pp = abs(x + y + w), pm = abs(x - y + w);
                    int mp = abs(-x + y + w), mm = abs(-x - y + w);
                    edge(u, z, (pp - pm - mp + mm) / 4);
                    edge(u, t, (pp + pm - mp - mm) / 4);
                    edge(z, t, (pp - pm + mp - mm) / 4);
                }
                continue;
            }
            int dom = -1, weight = 0;
            for (auto [u, w] : adj[v]) if (abs(w) > abs(weight)) {
                weight = w;
                dom = u;
            }
            if (dom >= 0 && 2 * abs(weight) >= strength[v] + abs(h[v])) {
                int relation = weight > 0 ? 1 : -1;
                int bias = h[v];
                auto a = neighbors(v);
                rules.push_back({v, 0, {{dom, relation}}});
                detach(v, a);
                h[dom] += relation * bias;
                touch(dom);
                for (auto [u, w] : a) if (u != dom) edge(dom, u, relation * w);
            }
        }
    }
    void breakSymmetry() {
        vector<char> seen(n, 0);
        vector<int> pins;
        for (int root = 0; root < n; ++root) if (alive[root] && !seen[root]) {
            vector<int> q(1, root);
            seen[root] = 1;
            bool zero = true;
            int chosen = root;
            for (size_t k = 0; k < q.size(); ++k) {
                int v = q[k];
                if (h[v]) zero = false;
                if (strength[v] > strength[chosen]) chosen = v;
                for (auto [u, w] : adj[v]) if (!seen[u]) {
                    seen[u] = 1;
                    q.push_back(u);
                }
            }
            if (zero) pins.push_back(chosen);
        }
        for (int v : pins) fix(v, 1);
    }
    bool roofDual() {
        vector<int> ids, index(n, -1);
        for (int v = 0; v < n; ++v) if (alive[v]) {
            index[v] = int(ids.size());
            ids.push_back(v);
        }
        int k = int(ids.size());
        if (!k) return false;
        int source = 2 * k, sink = source + 1;
        Dinic d(sink + 1);
        for (int i = 0; i < k; ++i) {
            int v = ids[i];
            if (h[v] > 0) {
                d.directed(source, 2 * i, h[v]);
                d.directed(2 * i + 1, sink, h[v]);
            } else if (h[v] < 0) {
                d.directed(source, 2 * i + 1, -h[v]);
                d.directed(2 * i, sink, -h[v]);
            }
            for (auto [u, w] : adj[v]) if (u > v) {
                int j = index[u];
                if (w > 0) {
                    d.undirected(2 * i, 2 * j, w);
                    d.undirected(2 * i + 1, 2 * j + 1, w);
                } else {
                    d.undirected(2 * i, 2 * j + 1, -w);
                    d.undirected(2 * i + 1, 2 * j, -w);
                }
            }
        }
        d.flow(source, sink);
        auto side = d.reachable(source);
        vector<pair<int, int>> fixed;
        for (int i = 0; i < k; ++i) if (side[2 * i] != side[2 * i + 1])
            fixed.push_back({ids[i], side[2 * i] ? 1 : -1});
        for (auto [v, s] : fixed) fix(v, s);
        return !fixed.empty();
    }
};

struct Problem {
    struct Edge { int u, v, w; };
    int n;
    vector<int> h;
    vector<vector<pair<int, int>>> adj;
    vector<Edge> edges;
    int lattice = 1;
    Problem(const Kernel &k, const vector<int> &ids) {
        n = int(ids.size());
        h.resize(n);
        adj.resize(n);
        vector<int> idx(k.n, -1);
        for (int i = 0; i < n; ++i) idx[ids[i]] = i;
        for (int i = 0; i < n; ++i) {
            int v = ids[i];
            h[i] = k.h[v];
            for (auto [u, w] : k.adj[v]) {
                int j = idx[u];
                adj[i].push_back({j, w});
                if (i < j) edges.push_back({i, j, w});
            }
            sort(adj[i].begin(), adj[i].end());
        }
        int divisor = 0;
        for (int i = 0; i < n; ++i) {
            int f = h[i];
            for (auto [j, w] : adj[i]) f += w;
            divisor = gcd(divisor, abs(2 * f));
        }
        for (auto e : edges) divisor = gcd(divisor, abs(4 * e.w));
        lattice = max(1, divisor);
    }
    bool balanced(vector<int> &answer) const {
        vector<int> gauge(n, 0), q;
        gauge[0] = 1;
        q.push_back(0);
        for (size_t at = 0; at < q.size(); ++at) {
            int v = q[at];
            for (auto [u, w] : adj[v]) {
                int s = gauge[v] * (w > 0 ? 1 : -1);
                if (!gauge[u]) {
                    gauge[u] = s;
                    q.push_back(u);
                } else if (gauge[u] != s) return false;
            }
        }
        Dinic flow(n + 2);
        for (int i = 0; i < n; ++i) {
            int f = h[i] * gauge[i];
            if (f > 0) flow.directed(n, i, f);
            else if (f < 0) flow.directed(i, n + 1, -f);
        }
        for (auto e : edges) flow.undirected(e.u, e.v, abs(e.w));
        flow.flow(n, n + 1);
        auto side = flow.reachable(n);
        answer.resize(n);
        for (int i = 0; i < n; ++i) answer[i] = gauge[i] * (side[i] ? 1 : -1);
        return true;
    }
};

struct Exact {
    const Problem &p;
    int n, best, constant = 0, fields = 0, edges = 0;
    vector<int> h, strength, assignment, bestAssignment;
    uint64_t active;
    clock_t deadline;
    uint64_t nodes = 0;
    bool aborted = false;
    Exact(const Problem &p, int score, const vector<int> &s, clock_t deadline)
        : p(p), n(p.n), best(score), h(p.h), strength(n), assignment(s),
          bestAssignment(s), active((1ULL << n) - 1), deadline(deadline) {
        for (int v = 0; v < n; ++v) fields += abs(h[v]);
        for (auto e : p.edges) {
            edges += abs(e.w);
            strength[e.u] += abs(e.w);
            strength[e.v] += abs(e.w);
        }
    }
    void assign(int v, int s) {
        active &= ~(1ULL << v);
        assignment[v] = s;
        constant += h[v] * s;
        fields -= abs(h[v]);
        for (auto [u, w] : p.adj[v]) if (active & (1ULL << u)) {
            fields -= abs(h[u]);
            h[u] += w * s;
            fields += abs(h[u]);
            strength[u] -= abs(w);
            edges -= abs(w);
        }
    }
    void undo(int v, int s) {
        for (auto [u, w] : p.adj[v]) if (active & (1ULL << u)) {
            fields -= abs(h[u]);
            h[u] -= w * s;
            fields += abs(h[u]);
            strength[u] += abs(w);
            edges += abs(w);
        }
        constant -= h[v] * s;
        fields += abs(h[v]);
        active |= 1ULL << v;
    }
    bool triangleBound() {
        int cap[40][40] = {};
        signed char sign[40][40] = {};
        int index[40], ids[40], count = 0;
        fill(index, index + 40, -1);
        for (uint64_t bits = active; bits; bits &= bits - 1) {
            int v = __builtin_ctzll(bits);
            index[v] = count;
            ids[count++] = v;
        }
        int anchor = count++;
        for (int i = 0; i < anchor; ++i) {
            int v = ids[i];
            cap[i][anchor] = cap[anchor][i] = abs(h[v]);
            sign[i][anchor] = sign[anchor][i] = h[v] >= 0 ? 1 : -1;
            for (auto [u, w] : p.adj[v]) if (index[u] >= 0) {
                int j = index[u];
                cap[i][j] = abs(w);
                sign[i][j] = w > 0 ? 1 : -1;
            }
        }
        int upper = constant + fields + edges;
        for (int i = count - 1; i >= 2; --i) {
            for (int j = i - 1; j >= 1; --j) if (cap[i][j]) {
                for (int k = j - 1; k >= 0 && cap[i][j]; --k) {
                    if (!cap[i][k] || !cap[j][k]) continue;
                    if (int(sign[i][j]) * int(sign[i][k]) * int(sign[j][k]) >= 0) continue;
                    int w = min(cap[i][j], min(cap[i][k], cap[j][k]));
                    cap[i][j] -= w;
                    cap[i][k] -= w;
                    cap[j][k] -= w;
                    upper -= 2 * w;
                    if (upper < best + p.lattice) return true;
                }
            }
        }
        return upper < best + p.lattice;
    }
    void dfs(int depth) {
        if (aborted) return;
        if ((++nodes & 63) == 0 && clock() >= deadline) {
            aborted = true;
            return;
        }
        vector<pair<int, int>> forced;
        bool cut = false;
        while (true) {
            if (constant + fields + edges < best + p.lattice) {
                cut = true;
                break;
            }
            int v = -1;
            for (uint64_t bits = active; bits; bits &= bits - 1) {
                int u = __builtin_ctzll(bits);
                if (abs(h[u]) >= strength[u]) { v = u; break; }
            }
            if (v < 0) break;
            int s = h[v] >= 0 ? 1 : -1;
            forced.push_back({v, s});
            assign(v, s);
        }
        if (!cut && !active) {
            if (constant > best) {
                best = constant;
                bestAssignment = assignment;
            }
            cut = true;
        }
        int remaining = __builtin_popcountll(active);
        if (!cut && (depth < 3 || remaining <= 18 || (nodes & 15) == 0))
            cut = triangleBound();
        if (!cut) {
            int candidates[4] = {-1, -1, -1, -1};
            int quality[4] = {-1, -1, -1, -1};
            for (uint64_t bits = active; bits; bits &= bits - 1) {
                int v = __builtin_ctzll(bits);
                int q = 2 * strength[v] - abs(h[v]);
                for (int j = 0; j < 4; ++j) if (q > quality[j]) {
                    for (int k = 3; k > j; --k) {
                        candidates[k] = candidates[k - 1];
                        quality[k] = quality[k - 1];
                    }
                    candidates[j] = v;
                    quality[j] = q;
                    break;
                }
            }
            int chosen = candidates[0], preferred = bestAssignment[chosen];
            int smallestMax = INT_MAX, smallestMin = INT_MAX;
            int upper = constant + fields + edges;
            for (int z = 0; z < 4 && candidates[z] >= 0; ++z) {
                int v = candidates[z];
                int plus = upper - abs(h[v]) + h[v] - strength[v];
                int minus = upper - abs(h[v]) - h[v] - strength[v];
                for (auto [u, w] : p.adj[v]) if (active & (1ULL << u)) {
                    plus += abs(h[u] + w) - abs(h[u]);
                    minus += abs(h[u] - w) - abs(h[u]);
                }
                int a = max(plus, minus), b = min(plus, minus);
                if (a < smallestMax || (a == smallestMax && b < smallestMin)) {
                    smallestMax = a;
                    smallestMin = b;
                    chosen = v;
                    preferred = plus == minus ? bestAssignment[v] : (plus > minus ? 1 : -1);
                }
            }
            if (smallestMax >= best + p.lattice) {
                assign(chosen, preferred);
                dfs(depth + 1);
                undo(chosen, preferred);
                if (!aborted) {
                    assign(chosen, -preferred);
                    dfs(depth + 1);
                    undo(chosen, -preferred);
                }
            }
        }
        for (int i = int(forced.size()) - 1; i >= 0; --i) undo(forced[i].first, forced[i].second);
    }
    bool run() {
        if (clock() >= deadline) return false;
        dfs(0);
        return !aborted;
    }
};

struct Search {
    static constexpr int D = 12;
    const Problem &p;
    int n, bestScore = INT_MIN;
    vector<int> best;
    struct Candidate { int score; vector<int> s; };
    vector<Candidate> pool;
    vector<array<float, D>> embedding;
    bool hasEmbedding = false;
    struct State {
        const Problem &p;
        vector<int> s, gain;
        int score = 0;
        State(const Problem &p, vector<int> s) : p(p), s(move(s)), gain(p.h) {
            for (int i = 0; i < p.n; ++i) score += p.h[i] * this->s[i];
            for (auto e : p.edges) {
                score += e.w * this->s[e.u] * this->s[e.v];
                gain[e.u] += e.w * this->s[e.v];
                gain[e.v] += e.w * this->s[e.u];
            }
            for (int i = 0; i < p.n; ++i) gain[i] *= -this->s[i];
        }
        void flip(int v) {
            int old = s[v];
            score += 2 * gain[v];
            s[v] = -old;
            gain[v] = -gain[v];
            for (auto [u, w] : p.adj[v]) gain[u] += 2 * w * old * s[u];
        }
    };
    Search(const Problem &p) : p(p), n(p.n) {}
    void offer(const vector<int> &s, int score) {
        if (score > bestScore) { bestScore = score; best = s; }
        int separation = max(2, n / 30);
        for (auto &e : pool) {
            int distance = 0;
            for (int i = 0; i < n; ++i) distance += s[i] != e.s[i];
            if (distance < separation) {
                if (score > e.score) e = {score, s};
                return;
            }
        }
        if (pool.size() < 12) pool.push_back({score, s});
        else {
            int worst = 0;
            for (int i = 1; i < (int)pool.size(); ++i) if (pool[i].score < pool[worst].score) worst = i;
            if (score > pool[worst].score || rnd.get(32) == 0) pool[worst] = {score, s};
        }
    }
    void greedy(State &st, clock_t deadline) {
        int moves = 0;
        while (moves < 20 * n + 200) {
            if ((moves & 63) == 0 && clock() >= deadline) break;
            int chosen = -1, gain = 0, ties = 0;
            for (int v = 0; v < n; ++v) {
                if (st.gain[v] > gain) { gain = st.gain[v]; chosen = v; ties = 1; }
                else if (st.gain[v] == gain && gain > 0 && rnd.get(++ties) == 0) chosen = v;
            }
            if (chosen >= 0) { st.flip(chosen); ++moves; continue; }
            int u = -1, v = -1, pairGain = 0;
            for (auto e : p.edges) {
                int g = st.gain[e.u] + st.gain[e.v] + 2 * e.w * st.s[e.u] * st.s[e.v];
                if (g > pairGain) { pairGain = g; u = e.u; v = e.v; }
            }
            if (u < 0) break;
            st.flip(u);
            st.flip(v);
            moves += 2;
        }
    }
    void prepareEmbedding(clock_t deadline) {
        embedding.resize(n + 1);
        for (auto &v : embedding) {
            float norm = 0;
            for (float &x : v) { x = rnd.normal(); norm += x * x; }
            norm = 1.0f / sqrt(max(norm, 1e-20f));
            for (float &x : v) x *= norm;
        }
        vector<int> order(n);
        iota(order.begin(), order.end(), 0);
        int sweeps = n < 100 ? 96 : 72;
        for (int step = 0; step < sweeps; ++step) {
            if ((step & 3) == 0) {
                if (clock() >= deadline) break;
                for (int i = n - 1; i > 0; --i) swap(order[i], order[rnd.get(i + 1)]);
            }
            for (int v : order) {
                array<float, D> sum;
                for (int d = 0; d < D; ++d) sum[d] = float(p.h[v]) * embedding[n][d];
                for (auto [u, w] : p.adj[v]) {
                    float wf = float(w);
                    for (int d = 0; d < D; ++d) sum[d] += wf * embedding[u][d];
                }
                float norm = 0;
                for (float x : sum) norm += x * x;
                if (norm > 1e-20f) {
                    norm = 1.0f / sqrt(norm);
                    for (int d = 0; d < D; ++d) embedding[v][d] = sum[d] * norm;
                }
            }
            array<float, D> sum{};
            for (int v = 0; v < n; ++v) if (p.h[v]) {
                float w = float(p.h[v]);
                for (int d = 0; d < D; ++d) sum[d] += w * embedding[v][d];
            }
            float norm = 0;
            for (float x : sum) norm += x * x;
            if (norm > 1e-20f) {
                norm = 1.0f / sqrt(norm);
                for (int d = 0; d < D; ++d) embedding[n][d] = sum[d] * norm;
            }
        }
        hasEmbedding = true;
    }
    vector<int> roundEmbedding() {
        array<float, D> direction;
        for (float &x : direction) x = rnd.normal();
        float dot = 0;
        for (int d = 0; d < D; ++d) dot += direction[d] * embedding[n][d];
        int anchor = dot >= 0 ? 1 : -1;
        vector<int> s(n);
        for (int v = 0; v < n; ++v) {
            dot = 0;
            for (int d = 0; d < D; ++d) dot += direction[d] * embedding[v][d];
            s[v] = (dot >= 0 ? 1 : -1) * anchor;
        }
        return s;
    }
    vector<int> solve(clock_t deadline) {
        clock_t started = clock();
        vector<int> initial(n);
        for (int i = 0; i < n; ++i) initial[i] = p.h[i] ? (p.h[i] > 0 ? 1 : -1) : (rnd.get(2) ? 1 : -1);
        State first(p, initial);
        greedy(first, deadline);
        offer(first.s, first.score);
        clock_t total = max<clock_t>(0, deadline - started);
        clock_t initialDeadline = started + total / 4;
        if (total > CLOCKS_PER_SEC / 100 && clock() < initialDeadline) {
            prepareEmbedding(started + total / 10);
            int rounds = n >= 500 ? 32 : 48;
            for (int r = 0; r < rounds && clock() < initialDeadline; ++r) {
                State st(p, roundEmbedding());
                greedy(st, initialDeadline);
                offer(st.s, st.score);
            }
        }
        if (n <= 38 && deadline - clock() > CLOCKS_PER_SEC / 200) {
            clock_t now = clock();
            clock_t allowance = (deadline - now) * (n <= 26 ? 50 : 18) / 100;
            Exact exact(p, bestScore, best, now + allowance);
            bool complete = exact.run();
            offer(exact.bestAssignment, exact.best);
            if (complete) return best;
        }
        int theoretical = 0;
        for (int h : p.h) theoretical += abs(h);
        for (auto e : p.edges) theoretical += abs(e.w);
        vector<int> shuffle(n);
        int run = 0;
        while (clock() < deadline && bestScore < theoretical) {
            vector<int> s;
            int mode = run % 8;
            if (run == 0) s = best;
            else if (mode == 0) {
                s.resize(n);
                for (int &x : s) x = rnd.get(2) ? 1 : -1;
            } else if (mode == 1 && hasEmbedding) {
                s = roundEmbedding();
            } else if (mode == 2 && pool.size() >= 2) {
                int a = rnd.get(int(pool.size()));
                int b = rnd.get(int(pool.size()) - 1);
                if (b >= a) ++b;
                s.resize(n);
                for (int i = 0; i < n; ++i) {
                    s[i] = rnd.get(2) ? pool[a].s[i] : pool[b].s[i];
                    if (rnd.get(100) < 3) s[i] = -s[i];
                }
            } else {
                s = mode == 4 || mode == 6 ? pool[rnd.get(int(pool.size()))].s : best;
                if (mode != 6) {
                    double r = rnd.real();
                    int count = min(n, 2 + int((n / 3) * r * r));
                    iota(shuffle.begin(), shuffle.end(), 0);
                    for (int j = 0; j < count; ++j) {
                        swap(shuffle[j], shuffle[j + rnd.get(n - j)]);
                        s[shuffle[j]] = -s[shuffle[j]];
                    }
                }
            }
            State st(p, move(s));
            if (run) greedy(st, deadline);
            offer(st.s, st.score);
            int localScore = st.score;
            vector<int> localBest = st.s;
            vector<int> tabu(n, 0), last(n, -1000000);
            static const double fractions[] = {0.018, 0.035, 0.065, 0.1, 0.012};
            int baseTenure = max(3, int(n * fractions[run % 5]) + 2);
            int patience = max(700, 12 * n + 400);
            if (run % 4 == 3) patience = patience * 3 / 2;
            int lastImprovement = 0;
            for (int iter = 1; iter - lastImprovement <= patience; ++iter) {
                if ((iter & 127) == 1 && clock() >= deadline) break;
                int chosen = -1, gain = INT_MIN, age = INT_MAX, ties = 0;
                for (int v = 0; v < n; ++v) {
                    int g = st.gain[v];
                    if (tabu[v] > iter && st.score + 2 * g <= bestScore) continue;
                    if (g > gain || (g == gain && last[v] < age)) {
                        chosen = v; gain = g; age = last[v]; ties = 1;
                    } else if (g == gain && last[v] == age && rnd.get(++ties) == 0) chosen = v;
                }
                if (chosen < 0) {
                    chosen = 0;
                    for (int v = 1; v < n; ++v) if (st.gain[v] > st.gain[chosen]) chosen = v;
                }
                st.flip(chosen);
                last[chosen] = iter;
                tabu[chosen] = iter + baseTenure + rnd.get(baseTenure / 2 + 5);
                if (st.score > localScore) {
                    localScore = st.score;
                    localBest = st.s;
                    lastImprovement = iter;
                    if (localScore > bestScore) { bestScore = localScore; best = localBest; }
                }
                if (bestScore == theoretical) break;
            }
            offer(localBest, localScore);
            ++run;
        }
        return best;
    }
};

int main() {
    const clock_t started = clock();
    const clock_t deadline = started + clock_t(1.84 * CLOCKS_PER_SEC);
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    if (!(cin >> n >> m)) return 0;
    vector<pair<int, int>> clauses(m);
    vector<vector<int>> g(2 * n), reverseGraph(2 * n);
    auto literal = [](int a) { return 2 * (abs(a) - 1) + (a < 0); };
    for (auto &[a, b] : clauses) {
        cin >> a >> b;
        int x = literal(a), y = literal(b);
        g[x ^ 1].push_back(y);
        reverseGraph[y].push_back(x ^ 1);
        g[y ^ 1].push_back(x);
        reverseGraph[x].push_back(y ^ 1);
    }
    vector<char> visited(2 * n, 0);
    vector<int> order;
    function<void(int)> visit = [&](int v) {
        visited[v] = 1;
        for (int u : g[v]) if (!visited[u]) visit(u);
        order.push_back(v);
    };
    for (int v = 0; v < 2 * n; ++v) if (!visited[v]) visit(v);
    vector<int> component(2 * n, -1);
    function<void(int, int)> paint = [&](int v, int c) {
        component[v] = c;
        for (int u : reverseGraph[v]) if (component[u] < 0) paint(u, c);
    };
    int count = 0;
    for (int i = 2 * n - 1; i >= 0; --i) if (component[order[i]] < 0) paint(order[i], count++);
    vector<int> spin(n);
    Kernel kernel(n);
    for (int i = 0; i < n; ++i) {
        spin[i] = component[2 * i] > component[2 * i + 1] ? 1 : -1;
        kernel.alive[i] = component[2 * i] == component[2 * i + 1];
    }
    for (auto [a, b] : clauses) {
        int u = abs(a) - 1, v = abs(b) - 1;
        if (!kernel.alive[u] || !kernel.alive[v]) continue;
        int x = a > 0 ? 1 : -1, y = b > 0 ? 1 : -1;
        if (u == v) {
            if (x == y) kernel.h[u] += 2 * x;
        } else {
            kernel.h[u] += x;
            kernel.h[v] += y;
            kernel.edge(u, v, -x * y);
        }
    }
    kernel.reduce();
    kernel.breakSymmetry();
    kernel.reduce();
    for (int pass = 0; pass < 4 && clock() + CLOCKS_PER_SEC / 20 < deadline; ++pass) {
        if (!kernel.roofDual()) break;
        kernel.reduce();
    }
    vector<vector<int>> groups;
    fill(visited.begin(), visited.end(), 0);
    for (int root = 0; root < n; ++root) if (kernel.alive[root] && !visited[root]) {
        vector<int> ids(1, root);
        visited[root] = 1;
        for (size_t i = 0; i < ids.size(); ++i) {
            for (auto [u, w] : kernel.adj[ids[i]]) if (!visited[u]) {
                visited[u] = 1;
                ids.push_back(u);
            }
        }
        sort(ids.begin(), ids.end());
        groups.push_back(move(ids));
    }
    struct Job {
        vector<int> ids;
        Problem problem;
        double weight;
        Job(const Kernel &k, vector<int> ids) : ids(move(ids)), problem(k, this->ids) {
            weight = (problem.n + 2.0 * problem.edges.size()) * sqrt(double(problem.n));
        }
    };
    vector<Job> jobs;
    for (auto &ids : groups) {
        Job job(kernel, move(ids));
        vector<int> answer;
        if (job.problem.balanced(answer)) {
            for (int i = 0; i < job.problem.n; ++i) spin[job.ids[i]] = answer[i];
        } else jobs.push_back(move(job));
    }
    sort(jobs.begin(), jobs.end(), [](const Job &a, const Job &b) { return a.problem.n < b.problem.n; });
    double remainingWeight = 0;
    for (const auto &job : jobs) remainingWeight += job.weight;
    for (auto &job : jobs) {
        clock_t now = clock();
        clock_t available = max<clock_t>(0, deadline - now);
        clock_t allowance = clock_t(double(available) * job.weight / max(1.0, remainingWeight));
        clock_t localDeadline = min(deadline, now + max<clock_t>(CLOCKS_PER_SEC / 1000, allowance));
        Search search(job.problem);
        vector<int> answer = search.solve(localDeadline);
        for (int i = 0; i < job.problem.n; ++i) spin[job.ids[i]] = answer[i];
        remainingWeight -= job.weight;
    }
    for (int i = int(kernel.rules.size()) - 1; i >= 0; --i) {
        const auto &rule = kernel.rules[i];
        int value = rule.bias;
        for (auto [v, w] : rule.neighbors) value += w * spin[v];
        spin[rule.v] = value >= 0 ? 1 : -1;
    }
    for (int i = 0; i < n; ++i) {
        if (i) cout << ' ';
        cout << (spin[i] > 0 ? 1 : 0);
    }
    cout << '\n';
    return 0;
}
