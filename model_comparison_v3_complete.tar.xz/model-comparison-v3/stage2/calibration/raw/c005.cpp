#include <bits/stdc++.h>
using namespace std;

static clock_t begin_clock;
static constexpr double TIME_LIMIT = 1.86;
static double elapsed() {
    return double(clock() - begin_clock) / CLOCKS_PER_SEC;
}

struct Random {
    uint64_t state = 2026110305ULL;
    uint32_t next() {
        state ^= state << 13;
        state ^= state >> 7;
        state ^= state << 17;
        return uint32_t(state >> 16);
    }
    int operator()(int k) { return int(next() % uint32_t(k)); }
};

struct Dinic {
    struct Edge { int to, rev, cap; };
    int n;
    vector<vector<Edge>> g;
    vector<int> level, at;
    explicit Dinic(int n_) : n(n_), g(n_), level(n_), at(n_) {}
    void add(int u, int v, int c) {
        Edge a{v, int(g[v].size()), c};
        Edge b{u, int(g[u].size()), 0};
        g[u].push_back(a);
        g[v].push_back(b);
    }
    bool bfs(int s, int t) {
        fill(level.begin(), level.end(), -1);
        vector<int> q(n);
        int l = 0, r = 0;
        q[r++] = s;
        level[s] = 0;
        while (l < r) {
            int v = q[l++];
            for (const Edge &e : g[v]) if (e.cap && level[e.to] < 0) {
                level[e.to] = level[v] + 1;
                q[r++] = e.to;
            }
        }
        return level[t] >= 0;
    }
    int dfs(int v, int t, int f) {
        if (v == t) return f;
        for (int &i = at[v]; i < int(g[v].size()); ++i) {
            Edge &e = g[v][i];
            if (e.cap && level[e.to] == level[v] + 1) {
                int z = dfs(e.to, t, min(f, e.cap));
                if (z) {
                    e.cap -= z;
                    g[e.to][e.rev].cap += z;
                    return z;
                }
            }
        }
        return 0;
    }
    void flow(int s, int t) {
        while (bfs(s, t)) {
            fill(at.begin(), at.end(), 0);
            while (dfs(s, t, INT_MAX / 4)) {}
        }
    }
    vector<int> reachable(int s) {
        vector<int> seen(n, 0), q(1, s);
        seen[s] = 1;
        for (size_t k = 0; k < q.size(); ++k) {
            int v = q[k];
            for (const Edge &e : g[v]) if (e.cap && !seen[e.to]) {
                seen[e.to] = 1;
                q.push_back(e.to);
            }
        }
        return seen;
    }
};

struct Elimination {
    int v, a = -1, b = -1, h = 0, wa = 0, wb = 0;
    int fixed = -1;
};

class Optimizer {
    int n, range = 1, min_bucket = 0;
    const vector<int> &h;
    const vector<vector<pair<int,int>>> &g;
    Random &rng;
    vector<int> x, delta, position, tabu;
    vector<vector<int>> buckets;
    int energy = 0, moves = 0, tenure = 6;
    int best_energy = INT_MAX;
    long long lower_bound = LLONG_MIN;
    vector<int> best_x, centered;
    vector<int> permutation, dsu, dsu_size, marks, selected, parent;
    vector<int> parent_weight, tree_order, dp0, dp1, target, key, changed;

    void insert(int v) {
        int b = delta[v] + range;
        position[v] = int(buckets[b].size());
        buckets[b].push_back(v);
        if (b < min_bucket) min_bucket = b;
    }
    void erase(int v) {
        vector<int> &b = buckets[delta[v] + range];
        int p = position[v], u = b.back();
        b[p] = u;
        position[u] = p;
        b.pop_back();
    }
    void save() {
        if (energy < best_energy) {
            best_energy = energy;
            best_x = x;
        }
    }
    void flip(int v, bool set_tabu = true) {
        int change = 1 - 2 * x[v], old_delta = delta[v];
        erase(v);
        x[v] ^= 1;
        energy += old_delta;
        delta[v] = -old_delta;
        insert(v);
        for (auto [u, w] : g[v]) {
            erase(u);
            delta[u] += (1 - 2 * x[u]) * w * change;
            insert(u);
        }
        ++moves;
        if (set_tabu) tabu[v] = moves + tenure + rng(10);
        save();
    }
    void initialize(const vector<int> &s) {
        x = s;
        fill(tabu.begin(), tabu.end(), 0);
        moves = 0;
        energy = 0;
        for (auto &b : buckets) b.clear();
        min_bucket = int(buckets.size());
        for (int v = 0; v < n; ++v) {
            int f = h[v];
            energy += h[v] * x[v];
            for (auto [u, w] : g[v]) {
                f += w * x[u];
                if (u > v) energy += w * x[u] * x[v];
            }
            delta[v] = (1 - 2 * x[v]) * f;
            insert(v);
        }
        save();
    }
    int choose() {
        while (min_bucket < int(buckets.size()) &&
               buckets[min_bucket].empty()) ++min_bucket;
        int first = min_bucket;
        for (int b = first; b < int(buckets.size()); ++b) {
            vector<int> &vs = buckets[b];
            if (vs.empty()) continue;
            if (energy + b - range < best_energy)
                return vs[rng(int(vs.size()))];
            for (int k = 0; k < 8; ++k) {
                int v = vs[rng(int(vs.size()))];
                if (tabu[v] <= moves) return v;
            }
            int offset = rng(int(vs.size()));
            for (int k = 0; k < int(vs.size()); ++k) {
                int v = vs[(offset + k) % vs.size()];
                if (tabu[v] <= moves) return v;
            }
        }
        if (first < int(buckets.size()))
            return buckets[first][rng(int(buckets[first].size()))];
        return 0;
    }
    void descent() {
        if (elapsed() >= TIME_LIMIT) return;
        for (int k = 0; k < 30 * n + 100; ++k) {
            while (min_bucket < int(buckets.size()) &&
                   buckets[min_bucket].empty()) ++min_bucket;
            if (min_bucket >= range) return;
            vector<int> &b = buckets[min_bucket];
            flip(b[rng(int(b.size()))], false);
            if ((k & 127) == 127 && elapsed() >= TIME_LIMIT) return;
        }
    }
    int root(int a) {
        while (dsu[a] != a) {
            dsu[a] = dsu[dsu[a]];
            a = dsu[a];
        }
        return a;
    }
    void unite(int a, int b) {
        a = root(a);
        b = root(b);
        if (a == b) return;
        if (dsu_size[a] < dsu_size[b]) swap(a, b);
        dsu[b] = a;
        dsu_size[a] += dsu_size[b];
    }
    void forest_move() {
        if (elapsed() >= TIME_LIMIT) return;
        iota(permutation.begin(), permutation.end(), 0);
        for (int i = n - 1; i > 0; --i)
            swap(permutation[i], permutation[rng(i + 1)]);
        if (rng(3) != 0) {
            for (int v = 0; v < n; ++v)
                key[v] = 4 * delta[v] + rng(24);
            sort(permutation.begin(), permutation.end(),
                 [&](int a, int b) { return key[a] < key[b]; });
        }
        iota(dsu.begin(), dsu.end(), 0);
        fill(dsu_size.begin(), dsu_size.end(), 1);
        fill(marks.begin(), marks.end(), 0);
        fill(selected.begin(), selected.end(), 0);
        for (int k = 0; k < n; ++k) {
            int v = permutation[k], stamp = k + 1;
            bool ok = true;
            for (auto [u, w] : g[v]) if (selected[u]) {
                int r = root(u);
                if (marks[r] == stamp) {
                    ok = false;
                    break;
                }
                marks[r] = stamp;
            }
            if (!ok) continue;
            selected[v] = 1;
            for (auto [u, w] : g[v])
                if (selected[u]) unite(v, u);
        }
        fill(parent.begin(), parent.end(), -2);
        tree_order.clear();
        for (int v = 0; v < n; ++v) if (selected[v]) {
            dp0[v] = 0;
            dp1[v] = h[v];
            for (auto [u, w] : g[v])
                if (!selected[u]) dp1[v] += w * x[u];
        }
        for (int v = 0; v < n; ++v)
            if (selected[v] && parent[v] == -2) {
                parent[v] = -1;
                size_t start = tree_order.size();
                tree_order.push_back(v);
                for (size_t k = start; k < tree_order.size(); ++k) {
                    int a = tree_order[k];
                    for (auto [b, w] : g[a])
                        if (selected[b] && parent[b] == -2) {
                            parent[b] = a;
                            parent_weight[b] = w;
                            tree_order.push_back(b);
                        }
                }
            }
        for (int k = int(tree_order.size()) - 1; k >= 0; --k) {
            int v = tree_order[k], p = parent[v];
            if (p >= 0) {
                dp0[p] += min(dp0[v], dp1[v]);
                dp1[p] += min(dp0[v], dp1[v] + parent_weight[v]);
            }
        }
        for (int v : tree_order) {
            int e0 = dp0[v], e1 = dp1[v];
            if (parent[v] >= 0)
                e1 += parent_weight[v] * target[parent[v]];
            if (e0 < e1) target[v] = 0;
            else if (e1 < e0) target[v] = 1;
            else target[v] = rng(4) ? x[v] : rng(2);
        }
        changed.clear();
        for (int v : tree_order) if (target[v] != x[v]) {
            changed.push_back(v);
            flip(v, false);
        }
        for (int v : changed)
            tabu[v] = moves + tenure + rng(10);
    }
    void anneal(double initial_temperature) {
        uint32_t probability[65];
        for (int level = 0; level < 32; ++level) {
            double t = initial_temperature *
                       pow(0.045 / initial_temperature, double(level) / 31.0);
            for (int d = 1; d <= 64; ++d)
                probability[d] = uint32_t(exp(-double(d) / t) * 4294967295.0);
            for (int k = 0; k < 3 * n; ++k) {
                int v = rng(n), d = delta[v];
                if (d <= 0 || (d <= 64 && rng.next() < probability[d]))
                    flip(v, false);
            }
            if (elapsed() >= TIME_LIMIT) return;
        }
    }
    vector<int> biased_start() {
        vector<int> s(n);
        for (int v = 0; v < n; ++v) {
            int probability = centered[v] < 0 ? 77 :
                              centered[v] > 0 ? 23 : 50;
            s[v] = rng(100) < probability;
        }
        return s;
    }
public:
    Optimizer(const vector<int> &hh,
              const vector<vector<pair<int,int>>> &gg, Random &rr)
        : n(int(hh.size())), h(hh), g(gg), rng(rr) {
        x.resize(n);
        delta.resize(n);
        position.resize(n);
        tabu.resize(n);
        centered.resize(n);
        long long simple = 0, constant = 0, absolute_fields = 0, absolute_edges = 0;
        for (int v = 0; v < n; ++v) {
            int r = abs(h[v]), f = 2 * h[v];
            simple += min(0, h[v]);
            constant += 2LL * h[v];
            for (auto [u, w] : g[v]) {
                r += abs(w);
                f += w;
                if (u > v) {
                    simple += min(0, w);
                    constant += w;
                    absolute_edges += abs(w);
                }
            }
            centered[v] = f;
            absolute_fields += abs(f);
            range = max(range, r);
        }
        long long z = constant - absolute_fields - absolute_edges;
        lower_bound = max(simple, z >= 0 ? (z + 3) / 4 : z / 4);
        buckets.resize(2 * range + 1);
        permutation.resize(n);
        dsu.resize(n);
        dsu_size.resize(n);
        marks.resize(n);
        selected.resize(n);
        parent.resize(n);
        parent_weight.resize(n);
        dp0.resize(n);
        dp1.resize(n);
        target.resize(n);
        key.resize(n);
        tree_order.reserve(n);
        changed.reserve(n);
        tenure = 5 + n / 100;
    }
    vector<int> run(const vector<int> &initial) {
        initialize(initial);
        for (int seed = 0; seed < 5; ++seed) {
            if (elapsed() >= TIME_LIMIT || best_energy == lower_bound) break;
            if (seed > 0) {
                vector<int> s(n);
                if (seed == 1) fill(s.begin(), s.end(), 0);
                if (seed == 2) fill(s.begin(), s.end(), 1);
                if (seed == 3) s = biased_start();
                if (seed == 4)
                    for (int &b : s) b = rng(2);
                initialize(s);
            }
            descent();
            for (int k = 0; k < 4; ++k) {
                forest_move();
                descent();
            }
        }
        int round = 0;
        while (elapsed() < TIME_LIMIT && best_energy != lower_bound) {
            vector<int> s = best_x;
            if (round > 0) {
                if (round % 7 == 0) {
                    for (int &b : s) b = rng(2);
                } else if (round % 7 == 3) {
                    s = biased_start();
                } else {
                    static const int rates[] = {25, 60, 120, 220, 350};
                    int rate = rates[round % 5], count = 0;
                    for (int &b : s) if (rng(1000) < rate) {
                        b ^= 1;
                        ++count;
                    }
                    if (!count) s[rng(n)] ^= 1;
                }
            }
            tenure = 4 + n / 90 + rng(4 + n / 150);
            initialize(s);
            if (round % 4 == 2) {
                anneal(round % 8 == 2 ? 1.2 : 2.2);
                descent();
                forest_move();
            }
            int observed_best = best_energy, stalled = 0;
            int maximum_steps = max(2500, 45 * n);
            int stall_limit = max(700, 12 * n);
            int forest_period = max(96, n / 2);
            for (int step = 0; step < maximum_steps; ++step) {
                flip(choose());
                if ((step + 1) % forest_period == 0) forest_move();
                if (best_energy < observed_best) {
                    observed_best = best_energy;
                    stalled = 0;
                } else ++stalled;
                if (stalled > stall_limit || best_energy == lower_bound) break;
                if ((step & 127) == 127 && elapsed() >= TIME_LIMIT) break;
            }
            ++round;
        }
        return best_x;
    }
};

int main() {
    begin_clock = clock();
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n, m;
    if (!(cin >> n >> m)) return 0;
    vector<int> h(n, 0);
    vector<vector<int>> w(n, vector<int>(n, 0));
    vector<vector<int>> implications(2 * n), reverse_implications(2 * n);
    auto literal = [](int a) {
        return 2 * (abs(a) - 1) + (a < 0);
    };
    auto imply = [&](int a, int b) {
        implications[a].push_back(b);
        reverse_implications[b].push_back(a);
    };
    for (int k = 0; k < m; ++k) {
        int a, b;
        cin >> a >> b;
        int la = literal(a), lb = literal(b);
        imply(la ^ 1, lb);
        imply(lb ^ 1, la);
        int u = abs(a) - 1, v = abs(b) - 1;
        if (u == v) {
            if (a == b) h[u] += a > 0 ? -1 : 1;
            continue;
        }
        int j;
        if (a > 0 && b > 0) {
            --h[u];
            --h[v];
            j = 1;
        } else if (a > 0 && b < 0) {
            ++h[v];
            j = -1;
        } else if (a < 0 && b > 0) {
            ++h[u];
            j = -1;
        } else j = 1;
        w[u][v] += j;
        w[v][u] += j;
    }
    vector<int> visited(2 * n, 0), order, component(2 * n, -1);
    function<void(int)> dfs1 = [&](int v) {
        visited[v] = 1;
        for (int u : implications[v]) if (!visited[u]) dfs1(u);
        order.push_back(v);
    };
    for (int v = 0; v < 2 * n; ++v) if (!visited[v]) dfs1(v);
    function<void(int,int)> dfs2 = [&](int v, int c) {
        component[v] = c;
        for (int u : reverse_implications[v])
            if (component[u] < 0) dfs2(u, c);
    };
    int count = 0;
    for (int k = int(order.size()) - 1; k >= 0; --k)
        if (component[order[k]] < 0) dfs2(order[k], count++);
    vector<int> answer(n, 0);
    bool satisfiable = true;
    for (int v = 0; v < n; ++v) {
        if (component[2 * v] == component[2 * v + 1]) satisfiable = false;
        answer[v] = component[2 * v] > component[2 * v + 1];
    }
    auto output = [&]() {
        for (int i = 0; i < n; ++i) {
            if (i) cout << ' ';
            cout << answer[i];
        }
        cout << '\n';
    };
    if (satisfiable) {
        output();
        return 0;
    }

    vector<int> active(n, 1), degree(n, 0), positive(n, 0), negative(n, 0);
    for (int i = 0; i < n; ++i)
        for (int j = 0; j < n; ++j) if (w[i][j]) {
            ++degree[i];
            positive[i] += max(0, w[i][j]);
            negative[i] += min(0, w[i][j]);
        }
    deque<int> queue;
    vector<int> in_queue(n, 0);
    auto enqueue = [&](int v) {
        if (active[v] && !in_queue[v]) {
            in_queue[v] = 1;
            queue.push_back(v);
        }
    };
    for (int i = 0; i < n; ++i) enqueue(i);
    auto alter = [&](int a, int b, int change) {
        if (!change) return;
        int old = w[a][b], now = old + change;
        int d = int(now != 0) - int(old != 0);
        degree[a] += d;
        degree[b] += d;
        int p = max(0, now) - max(0, old);
        int q = min(0, now) - min(0, old);
        positive[a] += p;
        positive[b] += p;
        negative[a] += q;
        negative[b] += q;
        w[a][b] = w[b][a] = now;
        enqueue(a);
        enqueue(b);
    };
    vector<Elimination> eliminated;
    eliminated.reserve(n);
    while (!queue.empty()) {
        int v = queue.front();
        queue.pop_front();
        in_queue[v] = 0;
        if (!active[v]) continue;
        int fixed = -1;
        if (h[v] + negative[v] >= 0) fixed = 0;
        else if (h[v] + positive[v] <= 0) fixed = 1;
        if (fixed < 0 && degree[v] > 2) continue;
        vector<pair<int,int>> neighbours;
        for (int u = 0; u < n; ++u)
            if (active[u] && w[v][u]) neighbours.push_back({u, w[v][u]});
        Elimination e;
        e.v = v;
        e.h = h[v];
        e.fixed = fixed;
        if (fixed >= 0) {
            eliminated.push_back(e);
            active[v] = 0;
            for (auto [u, weight] : neighbours) {
                h[u] += fixed * weight;
                alter(v, u, -weight);
                enqueue(u);
            }
        } else {
            if (!neighbours.empty()) {
                e.a = neighbours[0].first;
                e.wa = neighbours[0].second;
            }
            if (neighbours.size() == 2) {
                e.b = neighbours[1].first;
                e.wb = neighbours[1].second;
            }
            eliminated.push_back(e);
            active[v] = 0;
            for (auto [u, weight] : neighbours) alter(v, u, -weight);
            int f0 = min(0, e.h);
            int fa = min(0, e.h + e.wa);
            int fb = min(0, e.h + e.wb);
            int fab = min(0, e.h + e.wa + e.wb);
            if (e.a >= 0) {
                h[e.a] += fa - f0;
                enqueue(e.a);
            }
            if (e.b >= 0) {
                h[e.b] += fb - f0;
                enqueue(e.b);
                alter(e.a, e.b, fab - fa - fb + f0);
            }
        }
    }

    vector<vector<pair<int,int>>> adjacency(n);
    for (int v = 0; v < n; ++v) if (active[v])
        for (int u = 0; u < n; ++u)
            if (active[u] && w[v][u]) adjacency[v].push_back({u, w[v][u]});
    vector<int> gauge(n, -1), local_index(n, -1);
    uint64_t enumeration_used = 0;
    for (int start = 0; start < n; ++start) if (active[start] && gauge[start] < 0) {
        vector<int> vertices(1, start);
        gauge[start] = 0;
        bool balanced = true;
        for (size_t k = 0; k < vertices.size(); ++k) {
            int v = vertices[k];
            for (auto [u, weight] : adjacency[v]) {
                int expected = gauge[v] ^ int(weight > 0);
                if (gauge[u] < 0) {
                    gauge[u] = expected;
                    vertices.push_back(u);
                } else if (gauge[u] != expected) balanced = false;
            }
        }
        int k = int(vertices.size());
        for (int i = 0; i < k; ++i) local_index[vertices[i]] = i;
        if (balanced) {
            Dinic network(k + 2);
            int source = k, sink = k + 1;
            for (int i = 0; i < k; ++i) {
                int v = vertices[i], f = h[v], sum = 0;
                for (auto [u, weight] : adjacency[v]) {
                    f += weight * gauge[u];
                    sum += abs(weight);
                    int j = local_index[u];
                    if (i < j) {
                        network.add(i, j, abs(weight));
                        network.add(j, i, abs(weight));
                    }
                }
                if (gauge[v]) f = -f;
                int unary = 2 * f - sum;
                if (unary > 0) network.add(i, sink, unary);
                if (unary < 0) network.add(source, i, -unary);
            }
            network.flow(source, sink);
            vector<int> side = network.reachable(source);
            for (int i = 0; i < k; ++i) {
                int v = vertices[i];
                answer[v] = side[i] ^ gauge[v];
                active[v] = 0;
            }
        } else if (k <= 22 && elapsed() < 0.18 &&
                   enumeration_used + (1ULL << k) <= 8000000ULL) {
            vector<vector<pair<int,int>>> small(k);
            vector<int> bits(k, 0), field(k);
            for (int i = 0; i < k; ++i) {
                field[i] = h[vertices[i]];
                for (auto [u, weight] : adjacency[vertices[i]])
                    small[i].push_back({local_index[u], weight});
            }
            uint32_t total = 1U << k, best_mask = 0;
            int value = 0, best_value = 0;
            bool complete = true;
            for (uint32_t t = 1; t < total; ++t) {
                int v = __builtin_ctz(t), change = 1 - 2 * bits[v];
                value += change * field[v];
                bits[v] ^= 1;
                for (auto [u, weight] : small[v]) field[u] += weight * change;
                if (value < best_value) {
                    best_value = value;
                    best_mask = t ^ (t >> 1);
                }
                if ((t & 8191U) == 0 && elapsed() >= 0.18) {
                    complete = false;
                    break;
                }
            }
            enumeration_used += total;
            for (int i = 0; i < k; ++i) {
                answer[vertices[i]] = (best_mask >> i) & 1U;
                if (complete) active[vertices[i]] = 0;
            }
        }
    }

    vector<int> ids, kernel_index(n, -1);
    for (int v = 0; v < n; ++v) if (active[v]) {
        kernel_index[v] = int(ids.size());
        ids.push_back(v);
    }
    if (!ids.empty()) {
        int k = int(ids.size());
        vector<int> kh(k), initial(k);
        vector<vector<pair<int,int>>> kg(k);
        for (int i = 0; i < k; ++i) {
            int v = ids[i];
            kh[i] = h[v];
            initial[i] = answer[v];
            for (auto [u, weight] : adjacency[v])
                if (active[u]) kg[i].push_back({kernel_index[u], weight});
        }
        Random rng;
        Optimizer optimizer(kh, kg, rng);
        vector<int> solution = optimizer.run(initial);
        for (int i = 0; i < k; ++i) answer[ids[i]] = solution[i];
    }
    for (int k = int(eliminated.size()) - 1; k >= 0; --k) {
        const Elimination &e = eliminated[k];
        if (e.fixed >= 0) answer[e.v] = e.fixed;
        else {
            int f = e.h;
            if (e.a >= 0) f += e.wa * answer[e.a];
            if (e.b >= 0) f += e.wb * answer[e.b];
            answer[e.v] = f < 0;
        }
    }
    output();
    return 0;
}
