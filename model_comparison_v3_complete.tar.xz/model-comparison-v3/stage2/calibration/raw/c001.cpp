#include <bits/stdc++.h>
using namespace std;
using ll = long long;

struct Json {
    map<string, Json> o;
    vector<Json> a;
    string s;
    ll n = 0;
    bool b = false;
};

struct Parser {
    string s;
    size_t p = 0;
    void ws() { while (p < s.size() && isspace((unsigned char)s[p])) ++p; }
    unsigned hex4() {
        unsigned x = 0;
        for (int i = 0; i < 4 && p < s.size(); ++i) {
            char c = s[p++];
            x = x * 16 + (c >= '0' && c <= '9' ? c - '0' :
                c >= 'a' && c <= 'f' ? c - 'a' + 10 : c - 'A' + 10);
        }
        return x;
    }
    static void utf8(string &r, unsigned u) {
        if (u < 128) r += char(u);
        else if (u < 2048) {
            r += char(192 | (u >> 6)); r += char(128 | (u & 63));
        } else if (u < 65536) {
            r += char(224 | (u >> 12)); r += char(128 | ((u >> 6) & 63));
            r += char(128 | (u & 63));
        } else {
            r += char(240 | (u >> 18)); r += char(128 | ((u >> 12) & 63));
            r += char(128 | ((u >> 6) & 63)); r += char(128 | (u & 63));
        }
    }
    string str() {
        ws(); ++p;
        string r;
        while (p < s.size()) {
            char c = s[p++];
            if (c == '"') break;
            if (c != '\\') { r += c; continue; }
            c = s[p++];
            if (c == 'n') r += '\n';
            else if (c == 'r') r += '\r';
            else if (c == 't') r += '\t';
            else if (c == 'b') r += '\b';
            else if (c == 'f') r += '\f';
            else if (c == 'u') {
                unsigned u = hex4();
                if (u >= 0xd800 && u <= 0xdbff && p + 5 < s.size() &&
                    s[p] == '\\' && s[p + 1] == 'u') {
                    p += 2;
                    unsigned v = hex4();
                    if (v >= 0xdc00 && v <= 0xdfff)
                        u = 0x10000 + ((u - 0xd800) << 10) + v - 0xdc00;
                }
                utf8(r, u);
            } else r += c;
        }
        return r;
    }
    Json parse() {
        ws(); Json j;
        if (s[p] == '{') {
            ++p; ws();
            while (p < s.size() && s[p] != '}') {
                string k = str(); ws(); ++p;
                j.o[k] = parse(); ws();
                if (s[p] == ',') { ++p; ws(); } else break;
            }
            ++p;
        } else if (s[p] == '[') {
            ++p; ws();
            while (p < s.size() && s[p] != ']') {
                j.a.push_back(parse()); ws();
                if (s[p] == ',') { ++p; ws(); } else break;
            }
            ++p;
        } else if (s[p] == '"') j.s = str();
        else if (s[p] == 't') { j.b = true; p += 4; }
        else if (s[p] == 'f') { j.b = false; p += 5; }
        else if (s[p] == 'n') p += 4;
        else {
            bool neg = false;
            if (s[p] == '-') { neg = true; ++p; }
            while (p < s.size() && isdigit((unsigned char)s[p])) j.n = j.n * 10 + s[p++] - '0';
            if (neg) j.n = -j.n;
        }
        return j;
    }
};

string quoted(const string &s) {
    string r = "\"";
    const char *h = "0123456789abcdef";
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { r += '\\'; r += char(c); }
        else if (c < 32) {
            r += "\\u00"; r += h[c >> 4]; r += h[c & 15];
        } else r += char(c);
    }
    r += '"';
    return r;
}

struct Item { string id; int w, h, lim; ll v; };
struct Place { int t, x, y, r; };
struct Rect { int x, y, w, h; };
struct Size { int w, h; };
struct Result { vector<Place> p; ll value = 0; };
vector<Item> items;
int BW, BH, M;
bool rotation;
clock_t started;
constexpr double END_TIME = 1.82;
mt19937_64 rng(2026110305ULL);
double elapsed() { return double(clock() - started) / CLOCKS_PER_SEC; }
double rnd() { return (rng() >> 11) * (1.0 / 9007199254740992.0); }
int ri(int n) { return n > 0 ? int(rng() % unsigned(n)) : 0; }

bool overlap(const Rect &a, const Rect &b) {
    return a.x < b.x + b.w && b.x < a.x + a.w &&
           a.y < b.y + b.h && b.y < a.y + a.h;
}
bool contains(const Rect &a, const Rect &b) {
    return a.x <= b.x && a.y <= b.y &&
           a.x + a.w >= b.x + b.w && a.y + a.h >= b.y + b.h;
}
Size originalSize(const Place &p) {
    return p.r ? Size{items[p.t].h, items[p.t].w} : Size{items[p.t].w, items[p.t].h};
}

struct Config {
    int trans = 0, flipx = 0, flipy = 0;
    int metric = 0, pref = 0, compact = 0, select = 0, order = 0;
    double budget = 1.0, exponent = 1.0, noise = 0.0;
};

struct Packer {
    Config cfg;
    int W, H;
    double cutoff;
    bool halted = false;
    ll value = 0, usedArea = 0;
    vector<Place> pos;
    vector<Rect> freeRects;
    vector<int> cnt, nr, preference;
    vector<array<Size, 2>> dims;
    vector<Size> active;
    int minw = INT_MAX, minh = INT_MAX, mina = INT_MAX;

    void refresh() {
        active.clear(); minw = minh = mina = INT_MAX;
        for (int t = 0; t < M; ++t) if (cnt[t] < items[t].lim && items[t].v > 0) {
            for (int r = 0; r < nr[t]; ++r) {
                Size s = dims[t][r];
                if (s.w > W || s.h > H) continue;
                active.push_back(s);
                minw = min(minw, s.w); minh = min(minh, s.h);
                mina = min(mina, s.w * s.h);
            }
        }
        sort(active.begin(), active.end(), [](Size a, Size b) { return a.w * a.h < b.w * b.h; });
    }
    bool useful(const Rect &r) const {
        if (r.w < minw || r.h < minh || r.w * r.h < mina) return false;
        for (Size s : active) if (s.w <= r.w && s.h <= r.h) return true;
        return false;
    }
    void split(const Rect &p) {
        if (freeRects.empty() || halted) return;
        vector<Rect> base, added, accepted;
        base.reserve(freeRects.size()); added.reserve(freeRects.size() + 8);
        auto add = [&](Rect r) { if (r.w > 0 && r.h > 0 && useful(r)) added.push_back(r); };
        for (const Rect &f : freeRects) {
            if (!overlap(f, p)) {
                if (useful(f)) base.push_back(f);
                continue;
            }
            if (p.x > f.x) add({f.x, f.y, p.x - f.x, f.h});
            if (p.x + p.w < f.x + f.w) add({p.x + p.w, f.y, f.x + f.w - p.x - p.w, f.h});
            if (p.y > f.y) add({f.x, f.y, f.w, p.y - f.y});
            if (p.y + p.h < f.y + f.h) add({f.x, p.y + p.h, f.w, f.y + f.h - p.y - p.h});
        }
        accepted.reserve(added.size());
        for (size_t i = 0; i < added.size(); ++i) {
            if ((i & 15) == 0 && elapsed() > cutoff) {
                halted = true; freeRects.clear(); return;
            }
            const Rect a = added[i];
            bool redundant = false;
            for (const Rect &b : base) if (contains(b, a)) { redundant = true; break; }
            if (redundant) continue;
            for (size_t j = 0; j < accepted.size();) {
                if (contains(accepted[j], a)) { redundant = true; break; }
                if (contains(a, accepted[j])) {
                    accepted[j] = accepted.back(); accepted.pop_back();
                } else ++j;
            }
            if (!redundant) accepted.push_back(a);
        }
        base.insert(base.end(), accepted.begin(), accepted.end());
        if (base.size() > 1800) {
            nth_element(base.begin(), base.begin() + 1800, base.end(),
                [](const Rect &a, const Rect &b) { return a.w * a.h > b.w * b.h; });
            base.resize(1800);
        }
        freeRects.swap(base);
    }
    void compactAll() {
        for (int pass = 0; pass < cfg.compact; ++pass) {
            vector<int> height(W, 0);
            sort(pos.begin(), pos.end(), [](const Place &a, const Place &b) {
                return tie(a.y, a.x, a.t, a.r) < tie(b.y, b.x, b.t, b.r);
            });
            for (Place &p : pos) {
                Size s = dims[p.t][p.r];
                int y = 0;
                for (int x = p.x; x < p.x + s.w; ++x) y = max(y, height[x]);
                p.y = y;
                for (int x = p.x; x < p.x + s.w; ++x) height[x] = y + s.h;
            }
            vector<int> edge(H, 0);
            sort(pos.begin(), pos.end(), [](const Place &a, const Place &b) {
                return tie(a.x, a.y, a.t, a.r) < tie(b.x, b.y, b.t, b.r);
            });
            for (Place &p : pos) {
                Size s = dims[p.t][p.r];
                int x = 0;
                for (int y = p.y; y < p.y + s.h; ++y) x = max(x, edge[y]);
                p.x = x;
                for (int y = p.y; y < p.y + s.h; ++y) edge[y] = x + s.w;
            }
            if (elapsed() > cutoff) break;
        }
    }
    Packer(const Config &c, const vector<Place> &keep, double allowance) : cfg(c) {
        W = cfg.trans ? BH : BW; H = cfg.trans ? BW : BH;
        cutoff = min(END_TIME, elapsed() + allowance);
        cnt.assign(M, 0); nr.resize(M); preference.assign(M, -1); dims.resize(M);
        for (int t = 0; t < M; ++t) {
            nr[t] = rotation && items[t].w != items[t].h ? 2 : 1;
            for (int r = 0; r < 2; ++r) {
                Size s = r ? Size{items[t].h, items[t].w} : Size{items[t].w, items[t].h};
                if (cfg.trans) swap(s.w, s.h);
                dims[t][r] = s;
            }
            if (cfg.pref && nr[t] == 2) {
                if (cfg.pref == 1) preference[t] = dims[t][0].w >= dims[t][0].h ? 0 : 1;
                else if (cfg.pref == 2) preference[t] = dims[t][0].h >= dims[t][0].w ? 0 : 1;
                else preference[t] = ri(2);
            }
        }
        pos.reserve(keep.size() + 256);
        for (Place p : keep) {
            if (cfg.trans) swap(p.x, p.y);
            Size s = dims[p.t][p.r];
            if (cfg.flipx) p.x = W - p.x - s.w;
            if (cfg.flipy) p.y = H - p.y - s.h;
            pos.push_back(p); ++cnt[p.t];
            value += items[p.t].v; usedArea += s.w * s.h;
        }
        if (cfg.compact) compactAll();
        refresh();
        if (useful({0, 0, W, H})) freeRects.push_back({0, 0, W, H});
        for (size_t i = 0; i < pos.size(); ++i) {
            if ((i & 15) == 0 && elapsed() > cutoff) { halted = true; break; }
            Place p = pos[i]; Size s = dims[p.t][p.r];
            split({p.x, p.y, s.w, s.h});
            if (halted) break;
        }
    }
    bool insert(int t) {
        if (halted || cnt[t] >= items[t].lim || items[t].v <= 0) return false;
        tuple<int, ll, ll, ll, ll> best = {3, LLONG_MAX, LLONG_MAX, LLONG_MAX, LLONG_MAX};
        Place chosen{t, 0, 0, -1};
        for (int r = 0; r < nr[t]; ++r) {
            Size s = dims[t][r];
            int penalty = preference[t] >= 0 && preference[t] != r;
            for (const Rect &f : freeRects) {
                if (s.w > f.w || s.h > f.h) continue;
                int dw = f.w - s.w, dh = f.h - s.h;
                ll a = min(dw, dh), b = max(dw, dh), c = f.y, d = f.x;
                if (cfg.metric == 1) { a = ll(f.w) * f.h - ll(s.w) * s.h; b = min(dw, dh); }
                else if (cfg.metric == 2) { a = f.y + s.h; b = f.x; c = min(dw, dh); d = max(dw, dh); }
                else if (cfg.metric == 3) { a = max(dw, dh); b = min(dw, dh); }
                else if (cfg.metric == 4) {
                    a = ll(f.w) * f.h - ll(f.w / s.w) * (f.h / s.h) * s.w * s.h;
                    b = min(dw, dh);
                }
                auto key = make_tuple(penalty, a, b, c, d);
                if (key < best) { best = key; chosen = {t, f.x, f.y, r}; }
            }
        }
        if (chosen.r < 0) return false;
        Size s = dims[t][chosen.r];
        pos.push_back(chosen); ++cnt[t]; value += items[t].v; usedArea += s.w * s.h;
        if (cnt[t] == items[t].lim) refresh();
        split({chosen.x, chosen.y, s.w, s.h});
        return true;
    }
    Result result() {
        Result r; r.value = value; r.p = move(pos);
        for (Place &p : r.p) {
            Size s = dims[p.t][p.r];
            if (cfg.flipx) p.x = W - p.x - s.w;
            if (cfg.flipy) p.y = H - p.y - s.h;
            if (cfg.trans) swap(p.x, p.y);
        }
        return r;
    }
};

Result runPack(const Config &cfg, const vector<Place> &keep, double allowance) {
    Packer p(cfg, keep, allowance);
    if (p.halted) return p.result();
    vector<int> order(M), targets = p.cnt;
    vector<double> priority(M), key(M);
    iota(order.begin(), order.end(), 0);
    for (int t = 0; t < M; ++t) {
        double area = double(items[t].w) * items[t].h;
        priority[t] = log(double(max(1LL, items[t].v))) - cfg.exponent * log(area) + cfg.noise * (2 * rnd() - 1);
    }
    auto sortKeys = [&](const vector<double> &k) {
        sort(order.begin(), order.end(), [&](int a, int b) { return k[a] != k[b] ? k[a] > k[b] : a < b; });
    };
    sortKeys(priority);
    if (cfg.select) {
        double space = max(0LL, ll(p.W) * p.H - p.usedArea) * cfg.budget;
        for (int t : order) if (items[t].v > 0) {
            ll area = ll(items[t].w) * items[t].h;
            int n = min<ll>(items[t].lim - p.cnt[t], ll(max(0.0, floor(space / area))));
            targets[t] += n; space -= double(n) * area;
        }
        for (int t = 0; t < M; ++t) {
            Size s = p.dims[t][0];
            double area = double(s.w) * s.h;
            if (cfg.order == 0) key[t] = priority[t];
            else if (cfg.order == 1) key[t] = log(area);
            else if (cfg.order == 2) key[t] = log(double(max(s.w, s.h)));
            else if (cfg.order == 3) key[t] = log(double(s.h));
            else if (cfg.order == 4) key[t] = log(double(s.w));
            else if (cfg.order == 5) key[t] = log(double(max(s.w, s.h)) / min(s.w, s.h));
            else key[t] = log(double(max(1LL, items[t].v))) - .5 * log(area);
            key[t] += cfg.noise * (2 * rnd() - 1);
        }
        sortKeys(key);
    } else {
        for (int t = 0; t < M; ++t) targets[t] = items[t].v > 0 ? items[t].lim : p.cnt[t];
    }
    vector<char> blocked(M, false);
    int steps = 0;
    auto fill = [&](const vector<int> &goal) {
        for (int t : order) {
            while (!blocked[t] && p.cnt[t] < goal[t]) {
                if (p.halted || ((steps++ & 15) == 0 && elapsed() > p.cutoff)) { p.halted = true; return; }
                if (!p.insert(t)) { blocked[t] = true; break; }
            }
            if (p.halted) return;
        }
    };
    fill(targets);
    if (cfg.select && !p.halted) {
        for (int t = 0; t < M; ++t) {
            key[t] = log(double(max(1LL, items[t].v))) - log(double(items[t].w) * items[t].h) + cfg.noise * .25 * (2 * rnd() - 1);
            targets[t] = items[t].v > 0 ? items[t].lim : p.cnt[t];
        }
        sortKeys(key); fill(targets);
    }
    return p.result();
}

vector<Place> shelves(int trans, double allowance) {
    int W = trans ? BH : BW, H = trans ? BW : BH;
    double cutoff = min(END_TIME, elapsed() + allowance);
    vector<array<Size, 2>> dims(M);
    vector<int> nr(M), left(M), heights;
    for (int t = 0; t < M; ++t) {
        nr[t] = rotation && items[t].w != items[t].h ? 2 : 1;
        left[t] = items[t].v > 0 ? items[t].lim : 0;
        for (int r = 0; r < 2; ++r) {
            Size s = r ? Size{items[t].h, items[t].w} : Size{items[t].w, items[t].h};
            if (trans) swap(s.w, s.h);
            dims[t][r] = s;
            if (r < nr[t] && s.w <= W && s.h <= H) heights.push_back(s.h);
        }
    }
    sort(heights.begin(), heights.end()); heights.erase(unique(heights.begin(), heights.end()), heights.end());
    vector<Place> out;
    int y = 0;
    vector<ll> dp(W + 1), ndp(W + 1), qval(W + 1);
    vector<int> qidx(W + 1);
    while (y < H && elapsed() < cutoff) {
        double bestRate = -1;
        vector<int> bestCounts, bestRots;
        int bestHeight = 0;
        for (int height : heights) {
            if (height > H - y) break;
            if (elapsed() > cutoff) break;
            fill(dp.begin(), dp.end(), 0);
            vector<vector<int>> takes(M, vector<int>(W + 1, 0));
            vector<int> widths(M, 0), rots(M, -1);
            for (int t = 0; t < M; ++t) {
                if (left[t] <= 0) continue;
                for (int r = 0; r < nr[t]; ++r) {
                    Size s = dims[t][r];
                    if (s.h <= height && s.w <= W && (rots[t] < 0 || s.w < widths[t])) {
                        rots[t] = r; widths[t] = s.w;
                    }
                }
                if (rots[t] < 0) continue;
                int w = widths[t], cap = min(left[t], W / w);
                ll v = items[t].v;
                for (int rem = 0; rem < w && rem <= W; ++rem) {
                    int head = 0, tail = 0;
                    for (int k = 0, x = rem; x <= W; ++k, x += w) {
                        while (head < tail && qidx[head] < k - cap) ++head;
                        ll val = dp[x] - ll(k) * v;
                        while (head < tail && qval[tail - 1] <= val) --tail;
                        qidx[tail] = k; qval[tail] = val; ++tail;
                        ndp[x] = qval[head] + ll(k) * v;
                        takes[t][x] = k - qidx[head];
                    }
                }
                dp.swap(ndp);
            }
            if (dp[W] <= 0) continue;
            vector<int> counts(M, 0);
            int x = W, actualHeight = 0;
            for (int t = M - 1; t >= 0; --t) {
                counts[t] = takes[t][x];
                x -= counts[t] * widths[t];
                if (counts[t]) actualHeight = max(actualHeight, dims[t][rots[t]].h);
            }
            if (actualHeight == 0) continue;
            double rate = double(dp[W]) / actualHeight;
            if (rate > bestRate) {
                bestRate = rate; bestHeight = actualHeight;
                bestCounts = move(counts); bestRots = move(rots);
            }
        }
        if (bestHeight == 0) break;
        int repeat = (H - y) / bestHeight;
        vector<int> order;
        for (int t = 0; t < M; ++t) if (bestCounts[t]) {
            repeat = min(repeat, left[t] / bestCounts[t]); order.push_back(t);
        }
        sort(order.begin(), order.end(), [&](int a, int b) {
            Size x = dims[a][bestRots[a]], z = dims[b][bestRots[b]];
            return tie(x.h, x.w) > tie(z.h, z.w);
        });
        for (int k = 0; k < repeat; ++k) {
            int x = 0;
            for (int t : order) for (int j = 0; j < bestCounts[t]; ++j) {
                Place p{t, x, y, bestRots[t]};
                if (trans) swap(p.x, p.y);
                out.push_back(p); x += dims[t][bestRots[t]].w;
            }
            y += bestHeight;
        }
        for (int t : order) left[t] -= repeat * bestCounts[t];
    }
    return out;
}

int main() {
    started = clock();
    ios::sync_with_stdio(false); cin.tie(nullptr);
    Parser parser; parser.s.assign(istreambuf_iterator<char>(cin), istreambuf_iterator<char>());
    if (parser.s.empty()) { cout << "{\"placements\":[]}\n"; return 0; }
    Json root = parser.parse();
    BW = int(root.o["bin"].o["W"].n); BH = int(root.o["bin"].o["H"].n);
    rotation = root.o["bin"].o["allow_rotate"].b;
    for (Json &j : root.o["items"].a) {
        items.push_back({quoted(j.o["type"].s), int(j.o["w"].n), int(j.o["h"].n),
                         int(j.o["limit"].n), j.o["v"].n});
    }
    M = int(items.size());
    vector<int> densityOrder(M); iota(densityOrder.begin(), densityOrder.end(), 0);
    sort(densityOrder.begin(), densityOrder.end(), [](int a, int b) {
        return (long double)items[a].v / (ll(items[a].w) * items[a].h) >
               (long double)items[b].v / (ll(items[b].w) * items[b].h);
    });
    long double areaLeft = ll(BW) * BH, upper = 0;
    for (int t : densityOrder) {
        ll area = ll(items[t].w) * items[t].h;
        long double copies = min((long double)items[t].lim, areaLeft / area);
        upper += copies * items[t].v; areaLeft -= copies * area;
        if (areaLeft <= 0) break;
    }
    Result best, current;
    auto record = [&](Result r) {
        if (r.value > best.value) best = r;
        double temperature = max(.0003, .005 * (1.0 - elapsed() / END_TIME));
        bool accept = r.value >= current.value;
        if (!accept && best.value > 0)
            accept = rnd() < exp(double(r.value - current.value) / (temperature * best.value));
        if (accept) current = move(r);
    };
    auto finished = [&]() { return elapsed() >= END_TIME || (long double)best.value + .1L >= upper; };
    for (int k = 0; k < 6 && !finished(); ++k) {
        Config c; c.trans = k & 1;
        c.metric = k < 2 ? 0 : (k < 4 ? 2 : 1);
        if (k >= 2) {
            c.select = 1; c.order = k < 4 ? 2 : 1;
            c.budget = k < 4 ? .96 : 1.02;
        }
        record(runPack(c, {}, .14));
    }
    for (int trans = 0; trans < 2 && !finished(); ++trans) {
        vector<Place> p = shelves(trans, .14);
        Config c; c.trans = trans; c.metric = 0; c.compact = 1;
        record(runPack(c, p, .10));
    }
    int iteration = 0;
    while (!finished()) {
        Config c;
        c.trans = ri(2); c.metric = ri(5);
        c.pref = rnd() < .25 ? 1 + ri(3) : 0;
        vector<Place> keep;
        bool fresh = iteration < 12 || iteration % 4 == 0 || best.p.empty();
        if (fresh) {
            c.select = rnd() < .64;
            c.order = 1 + ri(6); c.budget = .86 + .24 * rnd();
            c.exponent = c.select ? .9 + .2 * rnd() : .72 + .55 * rnd();
            c.noise = .02 + .45 * rnd();
        } else {
            const vector<Place> &base = rnd() < .72 || current.p.empty() ? best.p : current.p;
            int mode = ri(9), n = int(base.size());
            int removeType = base[ri(n)].t;
            if (mode == 6) {
                double least = 1e100;
                for (const Place &p : base) {
                    double d = double(items[p.t].v) / (double(items[p.t].w) * items[p.t].h);
                    if (d < least) { least = d; removeType = p.t; }
                }
            }
            int prefix = int(n * (.3 + .58 * rnd()));
            Rect region{0, 0, BW, BH};
            if (mode == 2) {
                int w = max(1, int(BW * (.12 + .36 * rnd())));
                region = {ri(2) ? BW - w : 0, 0, w, BH};
            } else if (mode == 3) {
                int h = max(1, int(BH * (.12 + .36 * rnd())));
                region = {0, ri(2) ? BH - h : 0, BW, h};
            } else if (mode == 4) {
                Place q = base[ri(n)]; Size z = originalSize(q);
                int w = max(1, int(BW * (.15 + .37 * rnd())));
                int h = max(1, int(BH * (.15 + .37 * rnd())));
                int x = max(0, min(BW - w, q.x + z.w / 2 - w / 2));
                int y = max(0, min(BH - h, q.y + z.h / 2 - h / 2));
                region = {x, y, w, h};
            } else if (mode == 7) {
                if (ri(2)) {
                    int w = max(1, int(BW * (.08 + .25 * rnd())));
                    region = {ri(BW - w + 1), 0, w, BH};
                } else {
                    int h = max(1, int(BH * (.08 + .25 * rnd())));
                    region = {0, ri(BH - h + 1), BW, h};
                }
            }
            double discardProbability = .08 + .24 * rnd();
            keep.reserve(n);
            for (int i = 0; i < n; ++i) {
                const Place &p = base[i]; Size s = originalSize(p);
                bool remove = false;
                if (mode == 1) remove = i >= prefix;
                else if (mode == 2 || mode == 3 || mode == 4 || mode == 7)
                    remove = overlap({p.x, p.y, s.w, s.h}, region);
                else if (mode == 5 || mode == 6) remove = p.t == removeType;
                else if (mode == 8) remove = rnd() < discardProbability;
                if (!remove) keep.push_back(p);
            }
            c.flipx = ri(2); c.flipy = ri(2);
            c.compact = mode == 0 || rnd() < .68 ? 1 + ri(2) : 0;
            c.select = rnd() < .38; c.order = 1 + ri(6);
            c.budget = .93 + .26 * rnd();
            c.exponent = .9 + .2 * rnd(); c.noise = .02 + .34 * rnd();
            if (rnd() < .7) c.pref = 0;
        }
        record(runPack(c, keep, fresh ? .13 : .10));
        ++iteration;
        if (iteration % 64 == 0) current = best;
    }
    cout << "{\"placements\":[";
    for (size_t i = 0; i < best.p.size(); ++i) {
        const Place &p = best.p[i];
        if (i) cout << ',';
        cout << "{\"type\":" << items[p.t].id << ",\"x\":" << p.x
             << ",\"y\":" << p.y << ",\"rot\":" << p.r << '}';
    }
    cout << "]}\n";
    return 0;
}
