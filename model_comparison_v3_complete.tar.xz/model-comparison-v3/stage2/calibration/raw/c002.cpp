#include <bits/stdc++.h>
using namespace std;

struct Item {
    string id;
    int w = 0, h = 0, limit = 0;
    long long v = 0, area = 0;
    double loga = 0, logv = 0, density = 0;
};

struct JsonReader {
    string s;
    size_t p = 0;
    explicit JsonReader(string x) : s(move(x)) {}
    void ws() {
        while (p < s.size() && isspace((unsigned char)s[p])) ++p;
    }
    bool eat(char c) {
        ws();
        if (p < s.size() && s[p] == c) {
            ++p;
            return true;
        }
        return false;
    }
    static void utf8(string &s, unsigned x) {
        if (x < 128) s.push_back(char(x));
        else if (x < 2048) {
            s.push_back(char(192 | (x >> 6)));
            s.push_back(char(128 | (x & 63)));
        } else if (x < 65536) {
            s.push_back(char(224 | (x >> 12)));
            s.push_back(char(128 | ((x >> 6) & 63)));
            s.push_back(char(128 | (x & 63)));
        } else {
            s.push_back(char(240 | (x >> 18)));
            s.push_back(char(128 | ((x >> 12) & 63)));
            s.push_back(char(128 | ((x >> 6) & 63)));
            s.push_back(char(128 | (x & 63)));
        }
    }
    unsigned hex4() {
        unsigned a = 0;
        for (int i = 0; i < 4 && p < s.size(); ++i) {
            unsigned char c = s[p++];
            a = a * 16 + (c >= '0' && c <= '9' ? c - '0' :
                          c >= 'a' && c <= 'f' ? c - 'a' + 10 :
                          c >= 'A' && c <= 'F' ? c - 'A' + 10 : 0);
        }
        return a;
    }
    string str() {
        ws();
        if (p >= s.size() || s[p] != '"') return "";
        ++p;
        string a;
        while (p < s.size()) {
            char c = s[p++];
            if (c == '"') break;
            if (c != '\\') {
                a.push_back(c);
                continue;
            }
            if (p == s.size()) break;
            c = s[p++];
            if (c == 'n') a.push_back('\n');
            else if (c == 'r') a.push_back('\r');
            else if (c == 't') a.push_back('\t');
            else if (c == 'b') a.push_back('\b');
            else if (c == 'f') a.push_back('\f');
            else if (c == 'u') {
                unsigned z = hex4();
                if (z >= 0xd800 && z <= 0xdbff && p + 1 < s.size() &&
                    s[p] == '\\' && s[p + 1] == 'u') {
                    p += 2;
                    unsigned z2 = hex4();
                    if (z2 >= 0xdc00 && z2 <= 0xdfff)
                        z = 0x10000 + ((z - 0xd800) << 10) + z2 - 0xdc00;
                }
                utf8(a, z);
            } else a.push_back(c);
        }
        return a;
    }
    long long num() {
        ws();
        bool neg = p < s.size() && s[p] == '-';
        if (neg) ++p;
        long long x = 0;
        while (p < s.size() && s[p] >= '0' && s[p] <= '9')
            x = x * 10 + s[p++] - '0';
        return neg ? -x : x;
    }
    bool boolean() {
        ws();
        if (s.compare(p, 4, "true") == 0) {
            p += 4;
            return true;
        }
        p += min(size_t(5), s.size() - p);
        return false;
    }
    void skip() {
        ws();
        if (p >= s.size()) return;
        if (s[p] == '"') { str(); return; }
        if (eat('{')) {
            if (eat('}')) return;
            do { str(); eat(':'); skip(); } while (eat(','));
            eat('}');
        } else if (eat('[')) {
            if (eat(']')) return;
            do { skip(); } while (eat(','));
            eat(']');
        } else {
            while (p < s.size() && s[p] != ',' && s[p] != '}' &&
                   s[p] != ']' && !isspace((unsigned char)s[p])) ++p;
        }
    }
};

static vector<Item> items;
static int BW, BH, M;
static bool canRotate;
static mt19937 rng(2026110305u);
static clock_t beginTime;

static double rnd() {
    return (double(rng()) + 0.5) * (1.0 / 4294967296.0);
}
static bool expired() {
    return double(clock() - beginTime) / CLOCKS_PER_SEC >= 1.80;
}
static double elapsed() {
    return double(clock() - beginTime) / CLOCKS_PER_SEC;
}

struct Placement {
    int t, x, y, rot;
};
struct Rect {
    int x, y, w, h;
};
static inline int pw(const Placement &p) {
    return p.rot ? items[p.t].h : items[p.t].w;
}
static inline int ph(const Placement &p) {
    return p.rot ? items[p.t].w : items[p.t].h;
}
static inline bool intersects(const Rect &a, const Rect &b) {
    return a.x < b.x + b.w && b.x < a.x + a.w &&
           a.y < b.y + b.h && b.y < a.y + a.h;
}
static inline bool contains(const Rect &a, const Rect &b) {
    return a.x <= b.x && a.y <= b.y &&
           a.x + a.w >= b.x + b.w && a.y + a.h >= b.y + b.h;
}

struct Solution {
    vector<Placement> p;
    vector<int> cnt;
    long long value = 0, area = 0;
};

struct Packer {
    int W, H, rule, anchor, steps = 0, checks = 0;
    bool transpose;
    double mix, lambda;
    vector<int> ww, hh, cnt, pref;
    vector<Rect> fr, work, pieces;
    vector<Placement> placed;
    long long value = 0, area = 0;

    Packer(bool tr, int ru, int an, double mi)
        : W(tr ? BH : BW), H(tr ? BW : BH), rule(ru), anchor(an),
          transpose(tr), mix(mi), lambda(0.04 + 0.55 * rnd()),
          ww(M), hh(M), cnt(M, 0), pref(M) {
        for (int t = 0; t < M; ++t) {
            ww[t] = tr ? items[t].h : items[t].w;
            hh[t] = tr ? items[t].w : items[t].h;
            pref[t] = rng() & 1;
        }
        fr.reserve(256);
        work.reserve(256);
        pieces.reserve(128);
        placed.reserve(2048);
        fr.push_back({0, 0, W, H});
    }

    bool useful(const Rect &r) const {
        if (r.w <= 0 || r.h <= 0) return false;
        for (int t = 0; t < M; ++t) {
            if (cnt[t] >= items[t].limit) continue;
            if (ww[t] <= r.w && hh[t] <= r.h) return true;
            if (canRotate && hh[t] <= r.w && ww[t] <= r.h) return true;
        }
        return false;
    }

    void occupy(const Rect &a) {
        work.clear();
        pieces.clear();
        ++steps;
        auto piece = [&](int x, int y, int w, int h) {
            Rect r{x, y, w, h};
            if (useful(r)) pieces.push_back(r);
        };
        for (const Rect &r : fr) {
            if (!intersects(r, a)) {
                if ((steps & 15) || useful(r)) work.push_back(r);
                continue;
            }
            if (a.x > r.x) piece(r.x, r.y, a.x - r.x, r.h);
            if (a.x + a.w < r.x + r.w)
                piece(a.x + a.w, r.y, r.x + r.w - a.x - a.w, r.h);
            if (a.y > r.y) piece(r.x, r.y, r.w, a.y - r.y);
            if (a.y + a.h < r.y + r.h)
                piece(r.x, a.y + a.h, r.w, r.y + r.h - a.y - a.h);
        }
        for (const Rect &r : pieces) {
            bool covered = false;
            for (const Rect &q : work) {
                if (contains(q, r)) {
                    covered = true;
                    break;
                }
            }
            if (covered) continue;
            for (size_t j = 0; j < work.size();) {
                if (contains(r, work[j])) {
                    work[j] = work.back();
                    work.pop_back();
                } else ++j;
            }
            work.push_back(r);
        }
        fr.swap(work);
        if (fr.size() > 1600) {
            nth_element(fr.begin(), fr.begin() + 1600, fr.end(),
                        [](const Rect &a, const Rect &b) {
                            return (long long)a.w * a.h > (long long)b.w * b.h;
                        });
            fr.resize(1600);
        }
    }

    void add(int t, int x, int y, int rot) {
        int w = rot ? hh[t] : ww[t];
        int h = rot ? ww[t] : hh[t];
        placed.push_back({t, x, y, rot});
        ++cnt[t];
        value += items[t].v;
        area += items[t].area;
        occupy({x, y, w, h});
    }

    void addFixed(const Placement &p) {
        add(p.t, transpose ? p.y : p.x, transpose ? p.x : p.y, p.rot);
    }

    bool place(int t) {
        if (cnt[t] >= items[t].limit) return false;
        int an = anchor;
        if (mix > 0 && rnd() < mix) an ^= 1 + (rng() % 3);
        double ba = 1e100, bb = 1e100, bc = 1e100;
        int bx = 0, by = 0, br = -1;
        int nr = canRotate && ww[t] != hh[t] ? 2 : 1;
        for (const Rect &f : fr) {
            for (int z = 0; z < nr; ++z) {
                int rot = nr == 1 ? 0 : ((z + pref[t]) & 1);
                int w = rot ? hh[t] : ww[t];
                int h = rot ? ww[t] : hh[t];
                if (w > f.w || h > f.h) continue;
                int dx = f.w - w, dy = f.h - h;
                int sh = min(dx, dy), lo = max(dx, dy);
                int x = f.x + ((an & 1) ? dx : 0);
                int y = f.y + ((an & 2) ? dy : 0);
                int gx = (an & 1) ? W - x - w : x;
                int gy = (an & 2) ? H - y - h : y;
                double a, b, c = double(gy) * (W + 1) + gx;
                double waste = double(f.w) * f.h - double(w) * h;
                if (rule == 0) { a = sh; b = lo; }
                else if (rule == 1) { a = waste; b = sh; }
                else if (rule == 2) { a = gy + h; b = gx; c = sh; }
                else if (rule == 3) { a = lo; b = sh; }
                else if (rule == 4) { a = sh + lambda * lo; b = waste; }
                else {
                    double rx = double(dx) / w, ry = double(dy) / h;
                    a = min(rx, ry);
                    b = max(rx, ry);
                }
                if (a < ba - 1e-9 ||
                    (abs(a - ba) <= 1e-9 &&
                     (b < bb - 1e-9 || (abs(b - bb) <= 1e-9 && c < bc)))) {
                    ba = a; bb = b; bc = c;
                    bx = x; by = y; br = rot;
                }
            }
        }
        if (br < 0) return false;
        add(t, bx, by, br);
        return true;
    }

    void fillGrouped(const vector<int> &order, const vector<int> &cap) {
        for (int t : order) {
            if (expired()) return;
            int stop = min(cap[t], items[t].limit);
            while (cnt[t] < stop) {
                if (((checks++) & 7) == 0 && expired()) return;
                if (!place(t)) break;
            }
        }
    }

    void fillStream(const vector<double> &scores, const vector<int> &cap,
                    double spread, int style) {
        if (expired()) return;
        vector<pair<double, int>> seq;
        for (int t = 0; t < M; ++t) {
            int n = max(0, min(cap[t], items[t].limit) - cnt[t]);
            for (int k = 0; k < n; ++k) {
                double key;
                if (style == 0) key = scores[t] + spread * log(rnd());
                else key = scores[t] - spread * (k + 0.5) / max(1, n)
                           + spread * 0.12 * (rnd() - 0.5);
                seq.emplace_back(key, t);
            }
        }
        sort(seq.begin(), seq.end(), [](const auto &a, const auto &b) {
            return a.first > b.first;
        });
        vector<unsigned char> blocked(M, 0);
        for (const auto &q : seq) {
            if (((checks++) & 7) == 0 && expired()) return;
            int t = q.second;
            if (blocked[t] || cnt[t] >= cap[t]) continue;
            if (!place(t)) blocked[t] = 1;
        }
    }

    Solution result() const {
        Solution s;
        s.p = placed;
        if (transpose) for (auto &p : s.p) swap(p.x, p.y);
        s.cnt = cnt;
        s.value = value;
        s.area = area;
        return s;
    }
};

static vector<int> orderBy(const vector<double> &score) {
    vector<int> a(M);
    iota(a.begin(), a.end(), 0);
    stable_sort(a.begin(), a.end(), [&](int x, int y) {
        return score[x] > score[y];
    });
    return a;
}

static vector<int> areaTarget(const Packer &p, const vector<int> &order,
                              double factor) {
    vector<int> cap = p.cnt;
    double budget = max(0LL, (long long)BW * BH - p.area) * factor;
    for (int t : order) {
        long long n = min((long long)items[t].limit - p.cnt[t],
                          (long long)floor(budget / items[t].area + 1e-9));
        if (n > 0) {
            cap[t] += int(n);
            budget -= double(n) * items[t].area;
        }
    }
    return cap;
}

static vector<Placement> compact(vector<Placement> a) {
    bool mx = rng() & 1, my = rng() & 1;
    for (auto &p : a) {
        if (mx) p.x = BW - p.x - pw(p);
        if (my) p.y = BH - p.y - ph(p);
    }
    int first = rng() & 1;
    int passes = a.size() <= 900 ? 4 : 2;
    bool stop = false;
    for (int k = 0; k < passes && !stop; ++k) {
        int axis = (k + first) & 1;
        sort(a.begin(), a.end(), [&](const Placement &p, const Placement &q) {
            if (!axis) return p.x != q.x ? p.x < q.x : p.y < q.y;
            return p.y != q.y ? p.y < q.y : p.x < q.x;
        });
        for (size_t i = 0; i < a.size(); ++i) {
            if ((i & 31) == 0 && expired()) { stop = true; break; }
            int low = 0;
            if (!axis) {
                int y = a[i].y, top = y + ph(a[i]);
                for (size_t j = 0; j < i; ++j)
                    if (a[j].y < top && y < a[j].y + ph(a[j]))
                        low = max(low, a[j].x + pw(a[j]));
                a[i].x = low;
            } else {
                int x = a[i].x, right = x + pw(a[i]);
                for (size_t j = 0; j < i; ++j)
                    if (a[j].x < right && x < a[j].x + pw(a[j]))
                        low = max(low, a[j].y + ph(a[j]));
                a[i].y = low;
            }
        }
    }
    for (auto &p : a) {
        if (mx) p.x = BW - p.x - pw(p);
        if (my) p.y = BH - p.y - ph(p);
    }
    return a;
}

static vector<Placement> retained(const Solution &s, int mode) {
    if (s.p.empty()) return {};
    if (mode == 6) return compact(s.p);
    Rect region{0, 0, BW, BH};
    int ta = -1, tb = -1;
    double probability = 0;
    if (mode == 0) {
        region.w = max(1, int(BW * (0.14 + 0.48 * rnd())));
        if (rng() & 1) region.x = BW - region.w;
    } else if (mode == 1) {
        region.h = max(1, int(BH * (0.14 + 0.48 * rnd())));
        if (rng() & 1) region.y = BH - region.h;
    } else if (mode == 2 || mode == 3) {
        region.w = max(1, int(BW * (0.18 + 0.48 * rnd())));
        region.h = max(1, int(BH * (0.18 + 0.48 * rnd())));
        if (mode == 2) {
            region.x = rng() % (BW - region.w + 1);
            region.y = rng() % (BH - region.h + 1);
        } else {
            int at = rng() % s.p.size();
            for (int j = 0; j < 2; ++j) {
                int q = rng() % s.p.size();
                if (items[s.p[q].t].density < items[s.p[at].t].density) at = q;
            }
            const Placement &p = s.p[at];
            region.x = clamp(p.x + pw(p) / 2 - region.w / 2, 0, BW - region.w);
            region.y = clamp(p.y + ph(p) / 2 - region.h / 2, 0, BH - region.h);
        }
    } else if (mode == 4) {
        ta = s.p[rng() % s.p.size()].t;
        if (rnd() < 0.45) tb = s.p[rng() % s.p.size()].t;
    } else {
        probability = 0.10 + 0.30 * rnd();
    }
    vector<Placement> a;
    a.reserve(s.p.size());
    for (const auto &p : s.p) {
        bool remove;
        if (mode == 4) remove = p.t == ta || p.t == tb || rnd() < 0.035;
        else if (mode == 5) remove = rnd() < probability;
        else remove = intersects(region, {p.x, p.y, pw(p), ph(p)});
        if (!remove) a.push_back(p);
    }
    if (a.size() == s.p.size()) a.erase(a.begin() + (rng() % a.size()));
    return a;
}

static void printString(const string &s) {
    static const char hex[] = "0123456789abcdef";
    cout << '"';
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') cout << '\\' << char(c);
        else if (c < 32) cout << "\\u00" << hex[c >> 4] << hex[c & 15];
        else cout << char(c);
    }
    cout << '"';
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    beginTime = clock();
    string input((istreambuf_iterator<char>(cin)), istreambuf_iterator<char>());
    JsonReader j(move(input));
    j.eat('{');
    if (!j.eat('}')) {
        do {
            string key = j.str();
            j.eat(':');
            if (key == "bin") {
                j.eat('{');
                if (!j.eat('}')) {
                    do {
                        string k = j.str(); j.eat(':');
                        if (k == "W") BW = int(j.num());
                        else if (k == "H") BH = int(j.num());
                        else if (k == "allow_rotate") canRotate = j.boolean();
                        else j.skip();
                    } while (j.eat(','));
                    j.eat('}');
                }
            } else if (key == "items") {
                j.eat('[');
                if (!j.eat(']')) {
                    do {
                        Item it;
                        j.eat('{');
                        if (!j.eat('}')) {
                            do {
                                string k = j.str(); j.eat(':');
                                if (k == "type") it.id = j.str();
                                else if (k == "w") it.w = int(j.num());
                                else if (k == "h") it.h = int(j.num());
                                else if (k == "v") it.v = j.num();
                                else if (k == "limit") it.limit = int(j.num());
                                else j.skip();
                            } while (j.eat(','));
                            j.eat('}');
                        }
                        it.area = (long long)it.w * it.h;
                        it.loga = log(double(max(1LL, it.area)));
                        it.logv = log(double(max(1LL, it.v)));
                        it.density = double(it.v) / max(1LL, it.area);
                        items.push_back(move(it));
                    } while (j.eat(','));
                    j.eat(']');
                }
            } else j.skip();
        } while (j.eat(','));
        j.eat('}');
    }
    M = items.size();
    Solution best, current;
    best.cnt.assign(M, 0);
    current.cnt.assign(M, 0);
    vector<int> limits(M);
    for (int t = 0; t < M; ++t) limits[t] = max(0, items[t].limit);

    int iteration = 0;
    while (M > 0 && BW > 0 && BH > 0 && !expired()) {
        bool repair = iteration >= 8 && best.value > 0 && rnd() < 0.64;
        bool tr = iteration < 8 ? (iteration & 1) : (rng() & 1);
        int rule;
        if (iteration < 8) {
            static const int rules[] = {0, 1, 0, 1, 0, 2, 0, 1};
            rule = rules[iteration];
        } else {
            int q = rng() % 12;
            rule = q < 5 ? 0 : q < 8 ? 1 : q == 8 ? 2 :
                   q == 9 ? 3 : q == 10 ? 4 : 5;
        }
        int anchor = repair ? rng() % 4 : 0;
        double mixed = iteration >= 8 && rnd() < 0.23 ? 0.22 : 0.0;
        Packer pack(tr, rule, anchor, mixed);
        if (repair) {
            const Solution &base =
                current.value >= best.value * 0.96 && rnd() < 0.5 ? current : best;
            vector<Placement> keep = retained(base, rng() % 7);
            sort(keep.begin(), keep.end(), [](const Placement &a, const Placement &b) {
                if (items[a.t].area != items[b.t].area)
                    return items[a.t].area > items[b.t].area;
                return a.x + a.y < b.x + b.y;
            });
            for (size_t q = 0; q < keep.size(); ++q) {
                if ((q & 15) == 0 && expired()) break;
                pack.addFixed(keep[q]);
            }
        }

        double exponent = 0.84 + 0.35 * rnd();
        double noise = 0.12 + 0.65 * rnd();
        if (iteration < 8) {
            exponent = iteration == 4 ? 0.90 : 1.0;
            noise = iteration == 5 ? 0.12 : 0.0;
        }
        vector<double> score(M);
        for (int t = 0; t < M; ++t)
            score[t] = items[t].logv - exponent * items[t].loga
                       + noise * (2.0 * rnd() - 1.0);
        vector<int> densityOrder = orderBy(score);

        int strategy;
        if (iteration < 8) {
            static const int strategies[] = {0, 0, 1, 1, 0, 1, 2, 3};
            strategy = strategies[iteration];
        } else if (!repair) strategy = rng() % 5;
        else {
            int q = rng() % 10;
            strategy = q < 5 ? 0 : q < 7 ? 1 : q == 7 ? 2 : q == 8 ? 3 : 4;
        }

        int geometricMode = iteration < 8 ? (iteration == 5 ? 1 : 0) : rng() % 4;
        vector<double> geo(M);
        for (int t = 0; t < M; ++t) {
            if (geometricMode == 0) geo[t] = items[t].loga;
            else if (geometricMode == 1)
                geo[t] = log(max(double(pack.ww[t]) / pack.W,
                                 double(pack.hh[t]) / pack.H));
            else if (geometricMode == 2)
                geo[t] = log(double(max(items[t].w, items[t].h)));
            else geo[t] = items[t].loga + 0.22 * score[t];
            if (iteration >= 8) geo[t] += 0.55 * (rnd() - 0.5);
        }
        vector<int> geometricOrder = orderBy(geo);
        if (strategy == 0) {
            pack.fillGrouped(densityOrder, limits);
        } else if (strategy == 2) {
            pack.fillStream(score, limits,
                            iteration == 6 ? 1.5 : 0.35 + 2.9 * rnd(),
                            iteration == 6 ? 1 : int(rng() & 1));
        } else {
            vector<int> target;
            if (strategy == 3 && best.value > 0) {
                target = pack.cnt;
                double scale = rnd() < 0.22 ? 0.87 + 0.24 * rnd() : 1.0;
                for (int t = 0; t < M; ++t)
                    target[t] = max(pack.cnt[t], min(limits[t],
                                      int(best.cnt[t] * scale + 0.5)));
            } else {
                double factor = 0.90 + 0.135 * rnd();
                if (iteration == 2) factor = 0.95;
                if (iteration == 3) factor = 1.00;
                if (iteration == 5) factor = 0.98;
                target = areaTarget(pack, densityOrder, factor);
            }
            if (strategy == 4) {
                vector<int> partial = pack.cnt;
                double fraction = 0.12 + 0.62 * rnd();
                for (int t = 0; t < M; ++t)
                    partial[t] += int((target[t] - partial[t]) * fraction);
                pack.fillGrouped(densityOrder, partial);
            }
            if (!expired()) {
                if (iteration >= 8 && rnd() < 0.19)
                    pack.fillStream(geo, target, 0.12 + 0.55 * rnd(), 1);
                else pack.fillGrouped(geometricOrder, target);
            }
            if (!expired()) pack.fillGrouped(densityOrder, limits);
        }

        Solution candidate = pack.result();
        if (candidate.value > best.value) {
            best = candidate;
            current = move(candidate);
        } else {
            if (candidate.value == best.value && (rng() % 4 == 0))
                best = candidate;
            double temperature = 0.0015 + 0.011 * max(0.0, 1.0 - elapsed() / 1.80);
            long long delta = candidate.value - current.value;
            if (delta >= 0 ||
                (best.value > 0 && rnd() < exp(double(delta) /
                                           (temperature * best.value))))
                current = move(candidate);
        }
        ++iteration;
    }

    cout << "{\"placements\":[";
    for (size_t i = 0; i < best.p.size(); ++i) {
        if (i) cout << ',';
        const Placement &p = best.p[i];
        cout << "{\"type\":";
        printString(items[p.t].id);
        cout << ",\"x\":" << p.x << ",\"y\":" << p.y << ",\"rot\":" << p.rot << '}';
    }
    cout << "]}\n";
    return 0;
}
