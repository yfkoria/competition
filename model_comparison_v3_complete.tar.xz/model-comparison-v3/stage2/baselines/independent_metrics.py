"""Independent semantic checks/objective measurements for baseline validation.

This module neither imports the main judge nor reads any model candidate file.
Its algorithms follow the published mathematics, not checker diagnostic text.
"""
from collections import deque
from fractions import Fraction
import json


def packing(text, output):
    tokens=iter(map(int,text.split()));n=next(tokens);shapes=[]
    for _ in range(n):shapes.append([(next(tokens),next(tokens)) for _ in range(next(tokens))])
    t=list(map(int,output.split()));assert len(t)==2+4*n
    W,H=t[:2];assert W>0 and H>0
    occupied=set();cells=0
    for i,shape in enumerate(shapes):
        X,Y,R,F=t[2+4*i:6+4*i];assert R in range(4) and F in [0,1]
        for x,y in shape:
            if F:x=-x
            for _ in range(R):x,y=y,-x
            x+=X;y+=Y
            assert 0<=x<W and 0<=y<H and (x,y) not in occupied
            occupied.add((x,y));cells+=1
    return {'feasible':True,'objective':W*H,'bound':cells,'quality':cells/(W*H),'W':W,'H':H}


def jobshop(text,output):
    t=iter(map(int,text.split()));J,M=next(t),next(t)
    routes=[];times=[];position=[];machine_load=[0]*M;job_load=[]
    for j in range(J):
        r=[];d=[];p={}
        for k in range(M):
            machine,duration=next(t),next(t);r.append(machine);d.append(duration);p[machine]=k
            machine_load[machine]+=duration
        assert len(p)==M
        routes.append(r);times.append(d);position.append(p);job_load.append(sum(d))
    flat=list(map(int,output.split()));assert len(flat)==J*M
    edges=[[] for _ in range(J*M)];degree=[0]*(J*M)
    def add(u,v):edges[u].append(v);degree[v]+=1
    for j in range(J):
        for k in range(M-1):add(j*M+k,j*M+k+1)
    for machine in range(M):
        order=flat[machine*J:(machine+1)*J]
        assert set(order)==set(range(J))
        for a,b in zip(order,order[1:]):add(a*M+position[a][machine],b*M+position[b][machine])
    queue=deque(i for i,d in enumerate(degree) if d==0);start=[0]*(J*M);count=0;makespan=0
    while queue:
        u=queue.popleft();count+=1;finish=start[u]+times[u//M][u%M];makespan=max(makespan,finish)
        for v in edges[u]:
            start[v]=max(start[v],finish);degree[v]-=1
            if not degree[v]:queue.append(v)
    assert count==J*M,'cyclic machine/job precedence graph'
    lower=max(max(job_load),max(machine_load))
    return {'feasible':True,'objective':makespan,'bound':lower,'quality':lower/makespan,'operations':J*M}


def graph_cut(text,output):
    t=list(map(int,text.split()));n,m=t[:2];bits=list(map(int,output.split()));assert len(bits)==n and set(bits)<=set([0,1])
    cut=sum(bits[t[2+2*k]-1]!=bits[t[3+2*k]-1] for k in range(m))
    return {'feasible':True,'objective':cut,'bound':m,'quality':cut/m if m else 1.0}


def max2sat(text,output):
    t=list(map(int,text.split()));n,m=t[:2];bits=list(map(int,output.split()));assert len(bits)==n and set(bits)<=set([0,1])
    def lit(x):return bits[abs(x)-1]==int(x>0)
    sat=sum(lit(t[2+2*k]) or lit(t[3+2*k]) for k in range(m))
    return {'feasible':True,'objective':sat,'bound':m,'quality':sat/m if m else 1.0}


def rectangular(text,output):
    inp=json.loads(text);out=json.loads(output);assert set(out)=={'placements'}
    bin=inp['bin'];items={i['type']:i for i in inp['items']};usage={k:0 for k in items};rects=[];profit=0
    for p in out['placements']:
        assert set(p)=={'type','x','y','rot'}
        assert all(type(p[k]) is int for k in ['x','y','rot'])
        item=items[p['type']];x,y,r=p['x'],p['y'],p['rot'];assert r in (0,1)
        assert not r or bin['allow_rotate']
        w,h=(item['h'],item['w']) if r else (item['w'],item['h'])
        assert x>=0 and y>=0 and x+w<=bin['W'] and y+h<=bin['H']
        for a,b,c,d in rects:assert x+w<=a or c<=x or y+h<=b or d<=y
        rects.append((x,y,x+w,y+h));usage[p['type']]+=1;assert usage[p['type']]<=item['limit'];profit+=item['v']
    # Fractional bounded knapsack relaxation in area; integer objective allows floor.
    remaining=bin['W']*bin['H'];relax=Fraction(0)
    order=sorted(items.values(),key=lambda i:Fraction(i['v'],i['w']*i['h']),reverse=True)
    for item in order:
        area=item['w']*item['h'];take=min(Fraction(item['limit']),Fraction(remaining,area))
        relax+=take*item['v'];remaining-=take*area
        if remaining==0:break
    upper=relax.numerator//relax.denominator
    assert 0<=profit<=upper and upper>0
    return {'feasible':True,'objective':profit,'bound':upper,'quality':profit/upper,'placements':len(rects)}


METRICS={'0':packing,'46':jobshop,'47':rectangular,'192':graph_cut,'193':max2sat}
