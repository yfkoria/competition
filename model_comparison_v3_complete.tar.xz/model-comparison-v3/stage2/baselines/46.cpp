#include <bits/stdc++.h>
using namespace std;
// Validation baseline: machine arcs strictly increase job ID, so no cycles.
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);int J,M;if(!(cin>>J>>M))return 1;
 for(int m=0;m<M;m++){for(int j=0;j<J;j++)cout<<j<<(j+1==J?'\n':' ');}
}
