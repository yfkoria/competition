#include <iostream>
int main(){std::cout<<"{\"placements\":[]}\n";}
