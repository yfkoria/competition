#include <bits/stdc++.h>
using namespace std;
// Validation baseline only: put each untransformed bounding box side by side.
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);
 int n;if(!(cin>>n))return 1;long long W=0,H=0;vector<pair<long long,long long>> shift;
 for(int i=0;i<n;i++){int k;cin>>k;long long x,y,l=LLONG_MAX,r=LLONG_MIN,b=LLONG_MAX,t=LLONG_MIN;
  for(int j=0;j<k;j++){cin>>x>>y;l=min(l,x);r=max(r,x);b=min(b,y);t=max(t,y);}
  shift.push_back({W-l,-b});W+=r-l+1;H=max(H,t-b+1);
 }
 cout<<W<<' '<<H<<'\n';for(auto [x,y]:shift)cout<<x<<' '<<y<<" 0 0\n";
}
