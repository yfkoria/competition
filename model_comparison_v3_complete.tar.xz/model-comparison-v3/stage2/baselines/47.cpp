#include <bits/stdc++.h>
using namespace std;
// Independent validation baseline for released flat JSON instances.
// Choose one item type/orientation with the largest profit obtainable by a grid.
long long integer_field(const string&s,const string&key){smatch m;regex r("\\\""+key+"\\\"\\s*:\\s*(-?[0-9]+)");
 if(!regex_search(s,m,r))throw runtime_error("missing integer field");return stoll(m[1]);}
int main(){ios::sync_with_stdio(false);cin.tie(nullptr);string input((istreambuf_iterator<char>(cin)),{});
 long long W=integer_field(input,"W"),H=integer_field(input,"H");
 bool rotate=regex_search(input,regex("\\\"allow_rotate\\\"\\s*:\\s*true"));
 regex blocks("\\{[^{}]*\\}"),type_re("\\\"type\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
 string best_type;long long best_value=-1,best_w=0,best_h=0,best_n=0;int best_rot=0;
 for(sregex_iterator it(input.begin(),input.end(),blocks),end;it!=end;++it){string b=it->str();smatch m;if(!regex_search(b,m,type_re))continue;
  string typ=m[1];long long w=integer_field(b,"w"),h=integer_field(b,"h"),v=integer_field(b,"v"),lim=integer_field(b,"limit");
  for(int r=0;r<=int(rotate);r++){long long a=r?h:w,c=r?w:h,n=min(lim,(W/a)*(H/c));
   if(n*v>best_value){best_value=n*v;best_type=typ;best_w=a;best_h=c;best_n=n;best_rot=r;}}
 }
 cout<<"{\"placements\":[";long long columns=W/best_w;
 for(long long i=0;i<best_n;i++){if(i)cout<<',';cout<<"{\"type\":\""<<best_type<<"\",\"x\":"<<(i%columns)*best_w<<",\"y\":"<<(i/columns)*best_h<<",\"rot\":"<<best_rot<<'}';}
 cout<<"]}\n";
}
