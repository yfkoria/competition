这些程序是评测器验证用的独立简单基准，不是受测模型输出，也不是质量归一化锚点。

0.cpp：保持原形状、不旋转，把每件的包围框横向排开。包围框不相交，因此单元格不重叠。
46.cpp：每台机器按相同job编号顺序加工。机器边严格增加job编号，job内部边保持编号且沿链前进，因此不会成环。
47.cpp：选择单一item类型及方向，按规则网格填充允许的数量，使这种单类型铺法的总利润最大。它针对发布数据的扁平JSON及ASCII类型名解析，不是通用JSON库。
47_empty.cpp：输出空placements，是有效但零利润的控制。
192.cpp：按顶点编号奇偶划分。
193.cpp：全部变量置False。

independent_metrics.py 从输出的具体内容重新计算物理目标。JSSP会重建job与machine先后约束DAG，以最长路求makespan；不读取任何candidate声称的目标，也不从checker文案反推。
47的上界使用精确Fraction排序和有供给限制的面积分数背包，再对整数利润取floor。旋转不改变面积，因此该上界有效。
47重叠检查是O(K²)的独立朴素控制，适合本基准及小样本复核，不宜对数万placement作为正式高吞吐主judge；官方checker已有扫描线。

validate_baselines.py已检查全部160个所选题族官方输入：70+15+15+30+30。每个输出同时通过官方checker和独立语义检查，独立目标与官方目标消息相符，独立重算的official point与checker误差低于1e-7。全部记录于validation.json，原控制输出位于validation_outputs/。
另外，47_empty的合法零分控制也通过。有效零分不得混同编译失败、超时或checker拒绝。

源码以g++ -std=c++17 -O2 -pipe编译。验证读取固定commit下的官方数据，不读取任何受测模型raw文件。
完整160例复算需已获取官方仓库与已编译checker；正式选中输入/答案应按主实验的冻结快照复算。
