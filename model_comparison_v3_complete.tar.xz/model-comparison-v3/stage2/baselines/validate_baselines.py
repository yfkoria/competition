"""Cross-check independent baseline objectives against pinned official checkers."""
import hashlib
import json
import math
import re
import subprocess
from collections import Counter
from pathlib import Path
from independent_metrics import METRICS

HERE=Path(__file__).resolve().parent
BASE=HERE.parents[1]
PROBLEMS=BASE/'research/Frontier-CS/algorithmic/problems'
CHECKERS=BASE/'research/frontier_probe'
OUT=HERE/'validation_outputs';OUT.mkdir(exist_ok=True)

def official_points(task,metric,answer_file):
    q=metric['quality'];value=metric['objective']
    if task in ('0','192','193'):
        if task in ('192','193') and metric['bound']==0:return 100.0
        return 100*q if q<=.6 else min(100.0,60+math.log(q/.6))
    a,b=map(int,answer_file.read_text().split())
    if task=='46':
        B,T=max(a,b),min(a,b)
        if B==T:return 100.0 if value<=T else 0.0
        old=100*max(0,min(1,(B-value)/(B-T)))
        return old if old<=60 else min(100,60+math.log((.4*B+.6*T)/value))
    B,K=a,b
    if K<=B:return 100.0 if value>=K else 0.0
    exact=K>=metric['bound'];r=max(0,(value-B)/(K-B))
    old=100*min(1,r) if exact else 60*r
    anchor=B+.6*(K-B) if exact else K
    return old if old<=60 else min(100,60+math.log(value/anchor))

records=[]
for task in ['0','46','47','192','193']:
    paths=sorted((PROBLEMS/task/'testdata').glob('*.in'),key=lambda p:int(p.stem))
    for path in paths:
        text=path.read_text()
        solution=subprocess.run([str(HERE/'bin'/task)],input=text,text=True,capture_output=True,timeout=5,check=True)
        out=OUT/f'{task}_{path.stem}.out';out.write_text(solution.stdout)
        metrics=METRICS[task](text,solution.stdout)
        checker=subprocess.run([str(CHECKERS/f'checker_{task}'),str(path),str(out),str(path.with_suffix('.ans'))],text=True,capture_output=True,timeout=5)
        assert checker.returncode==7,(task,path.name,checker.stderr)
        score=float(re.search(r'^points\s+([\d.eE+-]+)',checker.stderr).group(1))*100
        expected=official_points(task,metrics,path.with_suffix('.ans'))
        assert abs(score-expected)<1e-7,(task,path.name,score,expected)
        # These checker messages expose the same raw objectives; do not use them to compute ours.
        if task=='46':assert int(re.search(r'Makespan: (\d+)',checker.stderr).group(1))==metrics['objective']
        if task=='47':assert int(re.search(r'Value: (\d+)',checker.stderr).group(1))==metrics['objective']
        if task=='0':assert int(re.search(r'area=(\d+)',checker.stderr).group(1))==metrics['objective']
        records.append({'task_id':task,'case_id':path.stem,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                        'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
                        'checker_returncode':checker.returncode,'checker_stderr':checker.stderr,
                        'official_points':score,**metrics})
    print(task,len(paths),'all feasible, objectives and official scores agree',flush=True)

empty_path=PROBLEMS/'47/testdata/1.in';empty_out=OUT/'47_empty_1.out';empty_out.write_text('{"placements":[]}\n')
empty=METRICS['47'](empty_path.read_text(),empty_out.read_text())
check=subprocess.run([str(CHECKERS/'checker_47'),str(empty_path),str(empty_out),str(empty_path.with_suffix('.ans'))],text=True,capture_output=True,timeout=5)
assert check.returncode==7 and empty['quality']==0
summary={'all_pass':True,'baseline_only':True,'not_model_samples':True,
         'counts':dict(Counter(r['task_id'] for r in records)),
         'source_hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(HERE.glob('*.cpp'))},
         'cases':records,'valid_zero_profit_control':{'metric':empty,'checker_returncode':check.returncode,'checker_stderr':check.stderr},
         'notes':['Simple controls are not quality normalization anchors.',
                  'JSSP objective is independently recomputed from the DAG, not inferred from a reported header.',
                  'Rectangular fractional area upper bound uses exact rational arithmetic and respects supply limits.',
                  '47.cpp parses the flat ASCII type names used by the released cases; it is a validation baseline, not a generic JSON reference implementation.']}
(HERE/'validation.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print('Saved',HERE/'validation.json')
