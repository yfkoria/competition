---
license: apache-2.0
task_categories:
  - text-generation
language:
  - en
tags:
  - code
  - algorithms
  - competitive-programming
  - research
  - frontier-cs-2.0
size_categories:
  - n<1K
configs:
  - config_name: default
    data_files:
      - split: test
        path: data/test-*.json
---

# Frontier-CS Dataset

A benchmark dataset for evaluating AI systems on challenging computer science problems.

## Dataset Description

This dataset contains 267 problems across three categories:
- **Algorithmic**: 180 competitive programming problems with automated judging
- **Research**: 66 open-ended research problems
- **2.0**: 21 next-generation open-ended optimization problems

## Dataset Structure

Each problem has the following fields:
- `problem_id`: Unique identifier for the problem
- `category`: One of "algorithmic", "research", or "2.0"
- `statement`: The problem statement text
- `config`: YAML configuration for evaluation

## Usage

```python
from datasets import load_dataset

dataset = load_dataset("FrontierCS/Frontier-CS")
```

## License

Apache 2.0
