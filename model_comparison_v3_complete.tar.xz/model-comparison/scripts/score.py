import json, pathlib, subprocess, sys, csv, re, hashlib, statistics
ROOT=pathlib.Path(__file__).resolve().parents[1]
def read(p):return json.loads((ROOT/p).read_text())
plan=read('run_plan_extended.json'); key=read('answer_key.json'); cases=read('code_cases.json')
records=[]; itemrows=[]; stylerows=[]; code_details={}; errors=[]
for run in plan:
 p=ROOT/'raw'/f"{run['run_id']}.json"
 if not p.exists():continue
 try:data=json.loads(p.read_text())
 except Exception as e:
  errors.append({'run_id':run['run_id'],'error':str(e)});continue
 rec={**run,'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 answers=data.get('answers',{}); confidences=data.get('confidence',{})
 scores=[]; briers=[]; wronghigh=0
 for q in [f'Q{i:02}' for i in range(1,13)]:
  if q=='Q11':
   try:
    proc=subprocess.run([sys.executable,'-I',str(ROOT/'scripts/code_runner.py')],input=json.dumps({'source':answers.get(q,''),'cases':cases}),capture_output=True,text=True,timeout=5)
    detail=json.loads(proc.stdout)
    score=sum(t['passed'] for t in detail['outcomes'])/len(cases)
   except Exception as e:detail={'error':str(e),'outcomes':[]};score=0
   code_details[run['run_id']]=detail
  else:score=float(answers.get(q)==key[q])
  confidence=confidences.get(q)
  valid_conf=type(confidence)==int and 0<=confidence<=100
  complete=int(score==1)
  brier=(confidence/100-complete)**2 if valid_conf else None
  if brier is not None:briers.append(brier)
  if not complete and valid_conf and confidence>=90:wronghigh+=1
  scores.append(score)
  itemrows.append({'run_id':run['run_id'],'model':run['model'],'effort':run['effort'],'repeat':run['repeat'],'question':q,'score':score,'complete_correct':complete,'confidence':confidence,'brier':brier,'answer_json':json.dumps(answers.get(q),ensure_ascii=False)})
 rec.update(score_100=sum(scores)/12*100,complete_correct=sum(s==1 for s in scores),brier=statistics.mean(briers) if briers else None,high_confidence_wrong=wronghigh)
 for sid in ['S01','S02','S03']:
  s=data.get('style',{}).get(sid,'')
  nonspace=len(re.sub(r'\s','',s));han=len(re.findall(r'[\u3400-\u9fff]',s));sentences=len(re.findall(r'[。！？!?]+',s))
  lists=len(re.findall(r'^\s*(?:[-*•]|\d+[.)、])\s*',s,re.M)); headings=len(re.findall(r'^\s*#{1,6}\s+',s,re.M))
  hedges=sum(s.count(w) for w in ['可能','也许','未必','不一定','或许','建议','我会','我更','可以考虑'])
  metric={'run_id':run['run_id'],'model':run['model'],'effort':run['effort'],'repeat':run['repeat'],'style_id':sid,'nonspace_chars':nonspace,'han_chars':han,'sentences':sentences,'chars_per_sentence':nonspace/max(1,sentences),'paragraphs':len([p for p in re.split(r'\n\s*\n',s) if p.strip()]),'list_markers':lists,'heading_markers':headings,'question_marks':s.count('？')+s.count('?'),'exclamation_marks':s.count('！')+s.count('!'),'hedge_markers':hedges,'bold_markers':s.count('**')//2,'length_compliant':(nonspace<=600 if sid=='S01' else 60<=nonspace<=140 if sid=='S02' else 80<=nonspace<=160),'text':s}
  stylerows.append(metric)
 records.append(rec)
def savecsv(name,rows):
 if not rows:return
 with (ROOT/'analysis'/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
savecsv('runs.csv',records);savecsv('items.csv',itemrows);savecsv('style_metrics.csv',stylerows)
(ROOT/'analysis/code_test_details.json').write_text(json.dumps(code_details,ensure_ascii=False,indent=2)+'\n')
cells=[]
for avail in read('availability_extended.json'):
 rs=[r for r in records if r['model']==avail['model'] and r['effort']==avail['effort']]
 cell={**avail,'completed_runs':len(rs),'r1_score':next((r['score_100'] for r in rs if r['repeat']==1),None),'r2_score':next((r['score_100'] for r in rs if r['repeat']==2),None),'mean_score':statistics.mean(r['score_100'] for r in rs) if rs else None,'min_score':min((r['score_100'] for r in rs),default=None),'max_score':max((r['score_100'] for r in rs),default=None),'mean_brier':statistics.mean(r['brier'] for r in rs) if rs else None,'high_confidence_wrong':sum(r['high_confidence_wrong'] for r in rs)}
 for sid in ['S01','S02','S03']:
  ss=[s for s in stylerows if s['model']==avail['model'] and s['effort']==avail['effort'] and s['style_id']==sid]
  cell[sid+'_mean_chars']=statistics.mean(s['nonspace_chars'] for s in ss) if ss else None
 cells.append(cell)
savecsv('cells.csv',cells)
(ROOT/'analysis/summary.json').write_text(json.dumps({'completed':len(records),'expected':70,'errors':errors,'cells':cells,'records':records},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'completed':len(records),'errors':errors,'runs':[{'id':r['run_id'],'score':r['score_100']} for r in records]},ensure_ascii=False))
