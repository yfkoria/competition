import pathlib,json,csv,collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
read=lambda p:json.loads((ROOT/'analysis'/p).read_text())
a={r['id']:r for r in read('blind_judge_a.json')};b={r['id']:r for r in read('blind_judge_b.json')};mapping=read('blind_mapping.json')
plan={r['run_id']:r for r in json.loads((ROOT/'run_plan_extended.json').read_text())}
fields=['s01_mode','s01_randomization','s02_stance','s03_fidelity']
def compare(a,b):
 assert set(a)==set(b)==set(mapping)
 agreement={f:{'agree':sum(a[k][f]==b[k][f] for k in a),'total':len(a),'rate':sum(a[k][f]==b[k][f] for k in a)/len(a)} for f in fields}
 consensus={f:dict(collections.Counter(a[k][f] if a[k][f]==b[k][f] else 'disagreement' for k in a)) for f in fields}
 per_model={}
 for model in dict.fromkeys(p['model'] for p in plan.values()):
  ids=[k for k,rid in mapping.items() if plan[rid]['model']==model]
  per_model[model]={f:dict(collections.Counter(a[k][f] if a[k][f]==b[k][f] else 'disagreement' for k in ids)) for f in fields}
 return {'agreement':agreement,'pooled_consensus':consensus,'by_model':per_model}
out=compare(a,b)
out['reviewers']={'a':{'requested_model':'gpt-6-astra','effort':'high'},'b':{'requested_model':'gpt-6.1-sol','effort':'high'}}
rows=[]
for k,rid in mapping.items():
 for f in fields:rows.append({'blind_id':k,'run_id':rid,'model':plan[rid]['model'],'effort':plan[rid]['effort'],'field':f,'judge_a':a[k][f],'judge_b':b[k][f],'agree':a[k][f]==b[k][f],'evidence_a':a[k]['evidence'],'evidence_b':b[k]['evidence']})
with (ROOT/'analysis/blind_reviews.csv').open('w',encoding='utf-8-sig',newline='') as file:
 w=csv.DictWriter(file,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
if (ROOT/'analysis/blind_judge_a_recovered.json').exists() and (ROOT/'analysis/blind_judge_b_recovered.json').exists():
 ar={r['id']:r for r in read('blind_judge_a_recovered.json')};br={r['id']:r for r in read('blind_judge_b_recovered.json')}
 out['recovered_sensitivity']=compare({**a,**ar},{**b,**br})
(ROOT/'analysis/blind_summary.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
