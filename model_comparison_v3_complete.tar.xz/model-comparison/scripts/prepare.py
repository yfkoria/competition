import itertools, json, math, random, hashlib, pathlib, datetime
from fractions import Fraction
from functools import lru_cache
ROOT=pathlib.Path(__file__).resolve().parents[1]
def write(name,obj):
    (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
perms=[]
for p in itertools.permutations('ABCDEFG'):
    ix={c:p.index(c)+1 for c in p}
    if ix['A']<ix['D'] and ix['F']==ix['C']+1 and ix['B'] in (2,5) and ix['E']<ix['A'] and abs(ix['G']-ix['D'])!=1 and ix['D']<ix['F']:
        perms.append(''.join(p))
den=num=0
for r in range(5):
 for b in range(4):
  for g in range(3):
   if r+b+g==4 and sum(t>0 for t in (r,b,g))==2 and g>=1:
    w=math.comb(4,r)*math.comb(3,b)*math.comb(2,g)
    den+=w
    if r==2:num+=w
@lru_cache(None)
def paths(x,y,d):
    if x>4 or y>4 or d>1 or (x,y) in ((2,2),(1,3)):return 0
    if (x,y)==(4,4):return int(d==1)
    return paths(x+1,y,d)+paths(x,y+1,d)+paths(x+1,y+1,d+1)
crt=[n for n in range(1000,10000) if n%7==5 and n%9==4 and n%11==3 and len(set(str(n)))==4]
def f(x,bag=[]):
 bag.append(x)
 return len(bag),sum(bag)
fs=[lambda z:z+i for i in range(3)]
out=[f(fs[0](1)),f(fs[1](2),[]),f(fs[2](3)),f(0)]
sets=[('A',{1,2,4},4),('B',{2,3,5},3),('C',{4,5,6},4),('D',{1,6,7},5),('E',{3,7},2),('F',{2,4,7},3),('G',{1,3,5,6},6)]
covers=[]
for mask in range(1,128):
 chosen=[s for i,s in enumerate(sets) if mask>>i&1]
 if set.union(*(s[1] for s in chosen))==set(range(1,8)):
  covers.append((sum(s[2] for s in chosen),len(chosen),[s[0] for s in chosen]))
cover=min(covers)
key={'Q01':{'count':len(perms),'first':min(perms)},'Q02':str(Fraction(num,den)),'Q03':paths(0,0,0),'Q04':min(crt) if crt else None,'Q05':out,'Q06':{'balances':[5,0,4],'statuses':['ok','rejected','duplicate','ok','rejected','rejected','duplicate','ok']},'Q07':{'A':82,'B':51,'supported':['a','b']},'Q08':[0,0.5],'Q09':['a','b','e'],'Q10':{'cost':cover[0],'sets':cover[2]},'Q12':['K1','K3','K4']}
write('answer_key.json',key)
rng=random.Random(20261102)
cases=[([],0),([],1),([0],0),([-1],-2),([-5],-4),([2,-1,2],3),([84,-37,32,40,95],167),([1,2],4),([0,0,0],1),([-2,-1],-1),([1],1),([3,-4,5,-2,6],7),([10,-20,10],10),([2,2,-1,2],4),([-10,-20],-25),([0,-1,0],0)]
for _ in range(80):
 n=rng.randrange(0,16)
 cases.append(([rng.randrange(-10,11) for _ in range(n)],rng.randrange(-12,30)))
def brute(a,k):
 lengths=[j-i for i in range(len(a)) for j in range(i+1,len(a)+1) if sum(a[i:j])>=k]
 return min(lengths,default=-1)
write('code_cases.json',[{'nums':a,'k':k,'expected':brute(a,k)} for a,k in cases])
models=['gpt-6-astra','gpt-6.1-sol','gpt-6-sol','gpt-6.1-terra','gpt-6-luna','gpt-5.6-sol']
efforts=['low','medium','high','xhigh','max','ultra']
cells=[]
for m,e in itertools.product(models,efforts):
 status='unavailable_model' if m=='gpt-5.6-sol' else 'unsupported_effort' if m=='gpt-6-luna' and e=='ultra' else 'available'
 cells.append({'model':m,'effort':e,'status':status})
write('availability.json',cells)
runs=[]
for repeat in [1,2]:
 block=[dict(c,repeat=repeat) for c in cells if c['status']=='available']
 rng.shuffle(block)
 runs.extend(block)
for i,r in enumerate(runs,1):r['run_id']=f'r{i:03d}'
write('run_plan.json',runs)
controller='请完成一次独立测评。仅先使用 exec_command 读取 /workspace/model-comparison/prompt.txt，然后严格按该文件答题；不得读取其他文件，不得使用工具解题，不得联系其他智能体。完成后只用 apply_patch 记录答案文件。以你的任务名最后一段作为JSON文件名。请现在开始。'
(ROOT/'controller_prompt.txt').write_text(controller+'\n')
manifest={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'repeats':2,'available_cells':29,'planned_runs':58,'objective_items':12,'style_items':3,'scoring':'Q01-Q10,Q12 each exact-match 1 point; Q11 proportion of 96 pre-fixed functional tests passed, plus no input mutation; 12-point score normalized to 100. Complexity constraint reviewed separately. No style aesthetic score in cognitive total.','limitations':['bundled items, two repeats, no decoding seed or temperature access','requested model/effort are not independent backend attestation','wall time includes scheduling and file recording','shared developer instructions constrain natural style'],'hashes':{f:hashlib.sha256((ROOT/f).read_bytes()).hexdigest() for f in ['prompt.txt','controller_prompt.txt','answer_key.json','code_cases.json','run_plan.json']}}
write('preregistration.json',manifest)
print(json.dumps({'key':key,'first_runs':runs[:6],'code_tests':len(cases)},ensure_ascii=False,indent=2))
