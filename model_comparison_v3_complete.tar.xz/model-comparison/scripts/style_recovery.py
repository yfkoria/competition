import json,pathlib,csv,re,statistics
ROOT=pathlib.Path(__file__).resolve().parents[1]
original=list(csv.DictReader((ROOT/'analysis/style_metrics.csv').open(encoding='utf-8-sig')))
mapping=json.loads((ROOT/'analysis/blind_mapping.json').read_text());reverse={v:k for k,v in mapping.items()}
flags=[];samples=[]
for rid in ['r018','r057']:
 raw=json.loads((ROOT/'raw'/f'{rid}.json').read_text())
 flags.append({'run_id':rid,'issue':'style正文放在answers.S01—S03；协议指定的style字段仅含摘要或标签','primary_analysis':'unchanged, reads style.S01—S03','sensitivity_analysis':'reads answers.S01—S03, without rewriting raw data'})
 samples.append({'id':reverse[rid],**{k:raw['answers'][k] for k in ['S01','S02','S03']}})
 for row in original:
  if row['run_id']!=rid:continue
  s=raw['answers'][row['style_id']];n=len(re.sub(r'\s','',s));sentences=len(re.findall(r'[。！？!?]+',s))
  row.update(text=s,nonspace_chars=n,han_chars=len(re.findall(r'[\u3400-\u9fff]',s)),sentences=sentences,chars_per_sentence=n/max(1,sentences),paragraphs=len([p for p in re.split(r'\n\s*\n',s) if p.strip()]),list_markers=len(re.findall(r'^\s*(?:[-*•]|\d+[.)、])\s*',s,re.M)),heading_markers=len(re.findall(r'^\s*#{1,6}\s+',s,re.M)),question_marks=s.count('？')+s.count('?'),exclamation_marks=s.count('！')+s.count('!'),hedge_markers=sum(s.count(w) for w in ['可能','也许','未必','不一定','或许','建议','我会','我更','可以考虑']),bold_markers=s.count('**')//2,length_compliant=(n<=600 if row['style_id']=='S01' else 60<=n<=140 if row['style_id']=='S02' else 80<=n<=160))
for row in original:row['source_field']='answers.'+row['style_id'] if row['run_id'] in ['r018','r057'] else 'style.'+row['style_id']
with (ROOT/'analysis/style_metrics_recovered.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(original[0]));w.writeheader();w.writerows(original)
models=[]
for m in dict.fromkeys(x['model'] for x in original):
 ss=[x for x in original if x['model']==m and x['effort']!='ultra']
 models.append({'model':m,**{sid+'_mean_chars':statistics.mean(int(x['nonspace_chars']) for x in ss if x['style_id']==sid) for sid in ['S01','S02','S03']}})
cells=[]
for m in dict.fromkeys(x['model'] for x in original):
 for e in ['low','medium','high','xhigh','max','ultra']:
  ss=[x for x in original if x['model']==m and x['effort']==e]
  if ss:cells.append({'model':m,'effort':e,**{sid+'_mean_chars':statistics.mean(int(x['nonspace_chars']) for x in ss if x['style_id']==sid) for sid in ['S01','S02','S03']}})
for name,obj in [('schema_flags.json',flags),('blind_recovered_samples.json',samples),('style_recovery_summary.json',{'models_common_five':models,'cells':cells,'remaining_length_failures':[{'run_id':x['run_id'],'style_id':x['style_id'],'chars':x['nonspace_chars']} for x in original if str(x['length_compliant'])!='True']})]:
 (ROOT/'analysis'/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'flags':flags,'luna_recovered':next(m for m in models if m['model']=='gpt-6-luna'),'recovered_ids':[s['id'] for s in samples]},ensure_ascii=False))
