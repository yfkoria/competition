import pathlib,json,csv,statistics,collections
ROOT=pathlib.Path(__file__).resolve().parents[1]
def rows(name):return list(csv.DictReader((ROOT/'analysis'/name).open(encoding='utf-8-sig')))
runs=rows('runs.csv'); items=rows('items.csv'); styles=rows('style_metrics.csv')
models=['gpt-6-astra','gpt-6.1-sol','gpt-6-sol','gpt-6.1-terra','gpt-6-luna','gpt-5.6-sol']
efforts=['low','medium','high','xhigh','max','ultra']
out={'models':[],'efforts_balanced_excluding_luna':[],'questions':[]}
for m in models:
 rs=[r for r in runs if r['model']==m and r['effort']!='ultra']
 ss=[s for s in styles if s['model']==m and s['effort']!='ultra']
 if not rs:continue
 x={'model':m,'runs_common_five_efforts':len(rs),'score_common_five_efforts':statistics.mean(float(r['score_100']) for r in rs),'brier':statistics.mean(float(r['brier']) for r in rs),'high_confidence_wrong':sum(int(r['high_confidence_wrong']) for r in rs),'perfect_runs':sum(float(r['score_100'])==100 for r in rs)}
 for sid in ['S01','S02','S03']:
  sp=[s for s in ss if s['style_id']==sid]
  x[sid+'_chars_mean']=statistics.mean(int(s['nonspace_chars']) for s in sp)
  x[sid+'_chars_min']=min(int(s['nonspace_chars']) for s in sp)
  x[sid+'_chars_max']=max(int(s['nonspace_chars']) for s in sp)
  x[sid+'_length_pass_rate']=sum(s['length_compliant']=='True' for s in sp)/len(sp)
  x[sid+'_lists']=sum(int(s['list_markers'])>0 for s in sp)
  x[sid+'_bold']=sum(int(s['bold_markers'])>0 for s in sp)
 out['models'].append(x)
for e in efforts:
 rs=[r for r in runs if r['effort']==e and r['model']!='gpt-6-luna']
 if rs:out['efforts_balanced_excluding_luna'].append({'effort':e,'n':len(rs),'mean_score':statistics.mean(float(r['score_100']) for r in rs)})
for q in [f'Q{i:02}' for i in range(1,13)]:
 xs=[x for x in items if x['question']==q]
 out['questions'].append({'question':q,'n':len(xs),'complete_correct':sum(int(x['complete_correct']) for x in xs),'mean_credit':statistics.mean(float(x['score']) for x in xs),'high_confidence_wrong':sum(int(x['complete_correct'])==0 and int(x['confidence'])>=90 for x in xs),'failed_run_ids':[x['run_id'] for x in xs if int(x['complete_correct'])==0]})
out['total_runs']=len(runs);out['perfect_runs']=sum(float(r['score_100'])==100 for r in runs)
out['total_incomplete_items']=sum(int(x['complete_correct'])==0 for x in items)
out['total_high_confidence_wrong']=sum(int(r['high_confidence_wrong']) for r in runs)
out['style_length_failures']=[{'run_id':s['run_id'],'style_id':s['style_id'],'chars':int(s['nonspace_chars'])} for s in styles if s['length_compliant']!='True']
(ROOT/'analysis/aggregate.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False,indent=2))
