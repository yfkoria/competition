import pathlib,json,csv,html,base64,statistics,hashlib,datetime
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parents[1];OUT=ROOT/'delivery';OUT.mkdir(exist_ok=True)
def read(p):return json.loads((ROOT/p).read_text())
def csvrows(p):return list(csv.DictReader((ROOT/p).open(encoding='utf-8-sig')))
def esc(s):return html.escape(str(s))
summary=read('analysis/summary.json');agg=read('analysis/aggregate.json');plan=read('run_plan_extended.json')
cells=summary['cells'];items=csvrows('analysis/items.csv');styles=csvrows('analysis/style_metrics.csv')
models=['gpt-6-astra','gpt-6.1-sol','gpt-6-sol','gpt-6.1-terra','gpt-6-luna','gpt-5.6-sol'];efforts=['low','medium','high','xhigh','max','ultra']
names=['6Astra','6.1sol','6sol','6.1terra','6luna','5.6sol*'];labels=dict(zip(models,names))
lookup={(c['model'],c['effort']):c for c in cells}
for field,title,filename,vmax in [('mean_score','Objective score: mean of two runs (0-100)','scores',100),('S01_mean_chars','S01 explanation length: non-whitespace characters','style_length',None)]:
 a=np.array([[lookup[m,e][field] if lookup[m,e][field] is not None else np.nan for e in efforts] for m in models],dtype=float)
 fig,ax=plt.subplots(figsize=(10,5.9),layout='constrained');fig.set_layout_engine('constrained',rect=(0,0.065,1,0.935));im=ax.imshow(a,cmap='Blues',vmin=0,vmax=vmax or np.nanmax(a))
 ax.set_xticks(range(6),efforts);ax.set_yticks(range(6),names);ax.set_title(title,pad=15)
 for i in range(6):
  for j in range(6):
   val=a[i,j];t='N/A' if np.isnan(val) else f'{val:.1f}'
   ax.text(j,i,t,ha='center',va='center',color='white' if not np.isnan(val) and val>0.65*(vmax or np.nanmax(a)) else '#172338',fontsize=11)
 fig.colorbar(im,ax=ax,shrink=.8)
 fig.text(.01,.005,'* Requested gpt-5.6-sol accepted, backend identity unverified. Luna ultra explicitly rejected.',fontsize=8)
 fig.savefig(OUT/f'{filename}.png',dpi=170);fig.savefig(OUT/f'{filename}.svg');plt.close(fig)
raw=[]
for r in plan:
 p=ROOT/'raw'/f"{r['run_id']}.json"
 if p.exists():raw.append({**r,'response':json.loads(p.read_text()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(OUT/'all_raw.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in raw))
(OUT/'all_raw.txt').write_text('\n\n'.join(f"===== {r['run_id']} | {r['model']} | {r['effort']} | repeat {r['repeat']} =====\n"+json.dumps(r['response'],ensure_ascii=False,indent=2) for r in raw)+'\n')
def table(head,rows):return '<div class="table-wrap"><table><thead><tr>'+''.join('<th>'+esc(h)+'</th>' for h in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(v)+'</td>' for v in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def matrix(field):
 rows=[]
 for m in models:
  row=[esc(labels[m])]
  for e in efforts:
   c=lookup[m,e];x=c[field]
   row.append('不支持' if x is None else f'<strong>{x:.1f}</strong>'+ (f'<small>{c["r1_score"]:.1f} / {c["r2_score"]:.1f}</small>' if field=='mean_score' and c['completed_runs']==2 else ''))
  rows.append(row)
 return table(['请求模型名']+efforts,rows)
question_names=['约束排列','条件概率','禁点路径','同余与数码','Python语义','账本状态','观察与因果','依赖关系边界','量词逻辑','最小费用覆盖','非空子数组代码','提取与注入干扰']
model_rows=[]
for m in agg['models']:
 model_rows.append([labels[m['model']],f"{m['score_common_five_efforts']:.2f}",f"{m['perfect_runs']}/{m['runs_common_five_efforts']}",f"{m['brier']:.4f}",m['high_confidence_wrong'],f"{m['S01_chars_mean']:.1f}",f"{m['S02_chars_mean']:.1f}",f"{m['S03_chars_mean']:.1f}"])
question_rows=[[q['question']+' '+question_names[i],f"{q['complete_correct']}/{q['n']}",q['high_confidence_wrong'],', '.join(q['failed_run_ids']) or '—'] for i,q in enumerate(agg['questions'])]
wrong_rows=[]
for it in items:
 if int(it['complete_correct'])==0:
  wrong_rows.append([esc(it['run_id']),labels[it['model']],it['effort'],it['question'],it['confidence'],f'<code>{esc(it["answer_json"])}</code>'])
cell_rows=[]
for c in cells:
 cell_rows.append([labels[c['model']],c['effort'],c['completed_runs'],*['—' if c[k] is None else f'{c[k]:.2f}' for k in ['r1_score','r2_score','mean_score','S01_mean_chars','S02_mean_chars','S03_mean_chars']],c['high_confidence_wrong']])
narrative=read('analysis/narrative.json') if (ROOT/'analysis/narrative.json').exists() else {'findings':['报告正在汇总。'],'style_findings':[]}
findings=''.join('<p>'+esc(p)+'</p>' for p in narrative['findings'])
style_findings=''.join('<p>'+esc(p)+'</p>' for p in narrative.get('style_findings',[]))
examples=''.join('<blockquote><b>'+esc(ex['label'])+'</b><p>'+esc(ex['quote'])+'</p><small>'+esc(ex['interpretation'])+'</small></blockquote>' for ex in narrative.get('examples',[]))
review_html=''
if (ROOT/'analysis/blind_summary.json').exists():
 br=read('analysis/blind_summary.json')
 review_html='<p>两个独立机器审阅者只读取随机编号原文，不知道模型、强度和成绩。标签属于描述性判断，未计入客观题分数；分歧保留。</p><h4>原协议字段的一致率</h4>'+table(['标签','一致数','总数','一致率'],[[k,v['agree'],v['total'],f"{v['rate']*100:.1f}%"] for k,v in br['agreement'].items()])
 review_html+='<p>原字段审阅：46篇通知忠实、22篇有额外承诺、2篇字段内容不足。补充提取两篇完整正文并独立复评后：48篇忠实、22篇有额外承诺，0篇实质性错误；S02立场分类一致率升为70/70（100%），其余一致率不变。两套结果均归档，未静默覆盖。下表使用补充提取正文的口径。</p>'
 bm=br['recovered_sensitivity']['by_model']
 review_html+=table(['请求模型','正文篇数','具体咖啡情境','开头直接反对','通知忠实','通知额外承诺'],[[labels[m],sum(bm[m]['s03_fidelity'].values()),bm[m]['s01_mode'].get('coffee_example',0),bm[m]['s02_stance'].get('direct_disagree',0),bm[m]['s03_fidelity'].get('faithful',0),bm[m]['s03_fidelity'].get('minor_addition',0)] for m in models])
 review_html+='<p>审阅者请求参数：6Astra high 与6.1sol high。此为事后探索性机器编码，不是人工评价，也不提供审美优劣排名。解释方式分类仍有1处分歧（具体咖啡情境与概括说明），未强行合并。</p>'
recovery=read('analysis/style_recovery_summary.json')
recmodels={x['model']:x for x in recovery['models_common_five']}
recovery_table=table(['请求模型','原字段S01均长','实际正文S01均长','实际正文S02均长','实际正文S03均长'],[[labels[x['model']],f"{x['S01_chars_mean']:.1f}",*[f"{recmodels[x['model']][sid+'_mean_chars']:.1f}" for sid in ['S01','S02','S03']]] for x in agg['models']])
recovery_note='<div class="note">两份6luna答卷正文错位。下面同时报告原字段与实际正文；补充提取是事后敏感性分析，未修改任何原始字节或客观分数。完整来源在style_metrics_recovered.csv的source_field列。</div>'+recovery_table
images={k:base64.b64encode((OUT/f'{k}.png').read_bytes()).decode() for k in ['scores','style_length']}
data=json.dumps({'raw':raw,'records':summary['records']},ensure_ascii=False).replace('<','\\u003c')
content=f'''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>模型与思考强度对照实验</title><style>
:root{{color-scheme:light;--ink:#172338;--muted:#58677e;--line:#d8e1ee;--accent:#164f87}}*{{box-sizing:border-box}}body{{margin:0;background:#f4f7fb;color:var(--ink);font:16px/1.75 system-ui,-apple-system,"Noto Sans CJK SC","Microsoft Yahei",sans-serif}}main{{max-width:1160px;margin:auto;padding:36px 28px 80px}}h1{{font-size:34px;line-height:1.3}}h2{{font-size:23px;margin-top:42px}}h3{{font-size:18px}}p{{max-width:94ch}}.muted,small{{color:var(--muted)}}small{{display:block;font-size:12px}}.pill{{display:inline-block;border:1px solid var(--line);border-radius:20px;padding:4px 13px;margin:4px;background:white}}.panel{{padding:22px;background:white;border:1px solid var(--line);border-radius:14px;margin:18px 0}}.note{{border-left:4px solid #b67a17;padding:12px 18px;background:#fff8e9}}.table-wrap{{overflow:auto;margin:18px 0}}table{{width:100%;border-collapse:collapse;background:white;font-size:14px}}th,td{{padding:10px 12px;border:1px solid var(--line);text-align:left;vertical-align:top}}th{{background:#eaf0f8;white-space:nowrap}}td:first-child{{font-weight:600}}img{{max-width:100%;height:auto;background:white;border-radius:10px}}code,pre{{font:13px/1.6 ui-monospace,monospace}}pre{{white-space:pre-wrap;overflow-wrap:anywhere;background:#f3f5f8;padding:16px;border-radius:8px}}td code{{overflow-wrap:anywhere}}blockquote{{border-left:3px solid #5698c4;padding:8px 20px;margin:20px 0;background:white}}select{{padding:8px;border:1px solid var(--line);border-radius:6px;margin:4px;font:inherit}}details{{background:white;border:1px solid var(--line);padding:12px 18px;margin:8px 0;border-radius:8px}}summary{{cursor:pointer;font-weight:600}}nav a{{margin-right:18px;color:var(--accent)}}.rawtext{{white-space:pre-wrap}}@media print{{body{{background:white}}main{{padding:0}}nav,.filters{{display:none}}details{{break-inside:avoid}}}}
</style></head><body><main>
<p class="muted">2026-11-02 · 固定题包 · 两次重复 · 请求参数级别比较</p>
<h1>6 个模型名 × 思考强度：原始数据与分析</h1>
<p><span class="pill">35 个可执行配置</span><span class="pill">{summary['completed']} / 70 次正式运行</span><span class="pill">12 道客观题</span><span class="pill">210 段中文表达</span></p>
<nav><a href="#results">完整矩阵</a><a href="#style">表达风格</a><a href="#method">控制条件</a><a href="#raw">原始回答</a></nav>
<div class="note">5.6sol 未列在接口说明中，但 gpt-5.6-sol 的 low、ultra 探测和后续正式请求均可执行；真实后端版本、别名或回退无法核验。6luna ultra 被接口明确拒绝。以下名称均指请求参数，不能视为后端身份认证。</div>
<section class="panel"><h2 style="margin-top:0">这批样本说明了什么</h2>{findings}</section>
<h2 id="results">完整成绩矩阵</h2><p>单元格主数字为两次平均分；小字是“第一次 / 第二次”。每道客观题等权，满分100。分差是此题包上的观察值，未做总体能力显著性推断。</p>{matrix('mean_score')}
<img src="data:image/png;base64,{images['scores']}" alt="全部配置客观题均分热图">
<h3>模型汇总：仅比较共同的 low—max 五档</h3><p>每个模型均为5档×2次，避免6luna没有ultra造成样本组成不一致。Brier越低，提交的置信度与正确性越一致。高置信错误为置信度≥90且未完整答对。</p>{table(['请求模型名','客观均分','满分运行','Brier','高置信错误数','S01均长','S02均长','S03均长'],model_rows)}
<h3>错误集中在哪里</h3>{table(['题目','完整正确','高置信错误','未完整答对的运行ID'],question_rows)}
<details><summary>展开全部错误答案</summary>{table(['运行','请求模型','强度','题号','置信度','提交答案'],wrong_rows)}</details>
<h2 id="style">中文表达的差异</h2>{style_findings}{recovery_note}<p>长度按去除空白后的Unicode字符数计算，含标点；另在CSV中给出汉字数。S01上限600字，S02要求60—140字，S03要求80—160字，因此这是相同任务约束下的表达，不是无提示的模型人格。主协议字段共有5条长度不合要求；按实际正文补充提取后只剩r007的S03为78字符，低于要求的80。两处字段错位本身另行标记。</p>
<h3>S01：按协议指定字段统计的完整矩阵</h3><p>此矩阵刻意保留两处错位字段的影响：6luna medium/max原均长75.5/98.5，补充提取正文后分别为151.0/153.0，其余格不变。</p>{matrix('S01_mean_chars')}<img src="data:image/png;base64,{images['style_length']}" alt="概念解释平均篇幅热图，按指定字段含两处错位">{examples}
<h3>匿名独立审阅</h3>{review_html}
<h2 id="method">实验方法与控制边界</h2>
<p>正式测评共71次尝试、70份成功答案。r058（6luna low第二次）在写出答案前失败，接口未提供原因；使用相同参数和提示、全新上下文补跑，提交字节原样存档。失败未计为认知错误，记录见 execution_events.json。</p>
<p>每个配置启动两个独立子智能体，fork_turns=none；所有实例收到字节相同的启动消息，读取同一份题包。题目顺序、语言、输出JSON协议、工具限制及共同上级指令一致。只允许读取题包和提交最终答案，不允许工具解题或互相联系。此限制通过提示实施，未获得逐调用轨迹来独立审计。</p>
<p>最初按接口列表规划29格58次，并在首个正式请求前冻结题包、答案、96个代码用例、评分规则和随机运行顺序。前34个请求启动后，对未列出5.6sol的调用探测成功，追加6格12次，并随机化剩余请求的顺序。原计划及哈希保留，扩展过程见 protocol_amendment.json。5.6sol存在时段不均衡；探测不计分。</p>
<p>Q01—Q10、Q12按JSON语义精确比对；对象键顺序无关，数组顺序有关。Q11按96个预置功能用例的通过比例计0—1分，并检查输入未被修改；总分为12题得分之和除以12乘100。功能用例不证明时间复杂度，另作静态审阅。标准答案已由另一位子智能体独立核验。表达审阅不进入客观分数。</p>
<p>无法统一或核验的变量包括温度、模型随机种子、实际思考预算、输出token上限、服务端路由与后端版本。没有token成本或纯推理耗时数据，因此不比较价格效率或速度。同名强度不意味着跨模型消耗相同的推理资源。</p>
<p>每格只有两次重复，且重复使用同一组题；不能把它当作24道独立试题。不计算智商、通用能力排名或可靠的显著性结论。题目主要覆盖短中文任务、离散推理与一题Python算法，未测视觉、长上下文、检索、长程代理、真实项目协作。大量满分造成上限效应。Q10没有最优并列，Q12仅输出id无法检验“选择最新记录”的过程。</p>
<details><summary>展开原始题包</summary><pre>{esc((ROOT/'prompt.txt').read_text())}</pre></details>
<details><summary>展开完整36格数字表</summary>{table(['模型','强度','次数','第一次','第二次','平均分','S01长度','S02长度','S03长度','高置信错误'],cell_rows)}</details>
<h2 id="raw">逐次原始回答浏览器</h2><p>以下内容来自原始JSON，包含答案、提交置信度和中文原文。完整压缩包同时提供70份独立JSON、合并JSONL/TXT、评分CSV、逐用例结果、输入哈希和复算脚本；不包含不可见的内部思维链或服务端日志。</p>
<div class="filters"><label>模型 <select id="modelFilter"><option value="">全部</option>{''.join('<option value="'+m+'">'+esc(labels[m])+'</option>' for m in models)}</select></label><label>强度 <select id="effortFilter"><option value="">全部</option>{''.join('<option>'+e+'</option>' for e in efforts)}</select></label></div><div id="rawContainer"></div>
<p class="muted">报告数据文件：analysis/cells.csv、analysis/items.csv、analysis/style_metrics.csv、analysis/aggregate.json。完整性可用SHA256SUMS.txt核验。</p>
<script type="application/json" id="payload">{data}</script><script>
const data=JSON.parse(document.getElementById('payload').textContent);const scores=Object.fromEntries(data.records.map(r=>[r.run_id,r.score_100]));
function render(){{const m=document.getElementById('modelFilter').value,e=document.getElementById('effortFilter').value,box=document.getElementById('rawContainer');box.replaceChildren();for(const r of data.raw){{if(m&&m!==r.model||e&&e!==r.effort)continue;const d=document.createElement('details'),s=document.createElement('summary');s.textContent=`${{r.run_id}} · ${{r.model}} · ${{r.effort}} · 重复${{r.repeat}} · ${{scores[r.run_id].toFixed(2)}}分`;d.appendChild(s);for(const [sid,t] of Object.entries(r.response.style)){{const h=document.createElement('h3');h.textContent=sid;const p=document.createElement('p');p.className='rawtext';p.textContent=t;d.append(h,p);}}const pre=document.createElement('pre');pre.textContent=JSON.stringify({{answers:r.response.answers,confidence:r.response.confidence}},null,2);d.append(pre);box.append(d);}}}}document.getElementById('modelFilter').onchange=render;document.getElementById('effortFilter').onchange=render;render();
</script></main></body></html>'''
(OUT/'report.html').write_text(content)
print(json.dumps({'report_bytes':len(content.encode()),'raw_runs':len(raw),'report':str(OUT/'report.html')},ensure_ascii=False))
