import ast, builtins, collections, json, sys, resource
resource.setrlimit(resource.RLIMIT_CPU,(3,3))
resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,256*1024*1024))
payload=json.load(sys.stdin)
source=payload['source']
try:
 tree=ast.parse(source)
 for n in ast.walk(tree):
  if isinstance(n,ast.Import) and any(a.name!='collections' for a in n.names):raise ValueError('Only collections import allowed')
  if isinstance(n,ast.ImportFrom) and (n.module!='collections' or n.level):raise ValueError('Only collections import allowed')
  if isinstance(n,ast.Attribute) and n.attr.startswith('__'):raise ValueError('dunder access disallowed')
 def safe_import(name,*args,**kw):
  if name=='collections':return collections
  raise ImportError(name)
 allowed=['abs','all','any','bool','dict','enumerate','float','int','isinstance','len','list','max','min','range','reversed','set','sorted','str','sum','tuple','zip','ValueError','Exception']
 env={'__builtins__':{k:getattr(builtins,k) for k in allowed},'__name__':'benchmark'}
 env['__builtins__']['__import__']=safe_import
 exec(compile(tree,'<submission>','exec'),env)
 outcomes=[]
 for i,c in enumerate(payload['cases']):
  nums=list(c['nums'])
  try:
   got=env['shortest'](nums,c['k'])
   outcomes.append({'case':i,'passed':type(got)==int and got==c['expected'] and nums==c['nums'],'got':repr(got),'expected':c['expected'],'input_mutated':nums!=c['nums']})
  except Exception as e:outcomes.append({'case':i,'passed':False,'error':type(e).__name__+': '+str(e)})
 print(json.dumps({'outcomes':outcomes}))
except Exception as e:
 print(json.dumps({'error':type(e).__name__+': '+str(e),'outcomes':[]}))
