import pathlib,json,random
ROOT=pathlib.Path(__file__).resolve().parents[1]
plan=json.loads((ROOT/'run_plan_extended.json').read_text())
assert all((ROOT/'raw'/f"{r['run_id']}.json").exists() for r in plan)
random.Random(20261104).shuffle(plan)
samples=[];mapping={}
for i,r in enumerate(plan,1):
 sid=f'B{i:03d}'
 data=json.loads((ROOT/'raw'/f"{r['run_id']}.json").read_text())
 samples.append({'id':sid,**data['style']})
 mapping[sid]=r['run_id']
(ROOT/'analysis/blind_samples.json').write_text(json.dumps(samples,ensure_ascii=False,indent=2)+'\n')
(ROOT/'analysis/blind_mapping.json').write_text(json.dumps(mapping,ensure_ascii=False,indent=2)+'\n')
codes=[{'run_id':r['run_id'],'source':json.loads((ROOT/'raw'/f"{r['run_id']}.json").read_text())['answers']['Q11']} for r in plan]
(ROOT/'analysis/code_sources.json').write_text(json.dumps(codes,ensure_ascii=False,indent=2)+'\n')
print('Prepared',len(samples),'anonymous samples')
