模型 × 思考强度受控小样本实验

范围：用户指定6个模型名、接口列出的6种思考强度，共36格。
初始列表可用29格，每格2次，原计划58次。随后对未列出的gpt-5.6-sol进行
low和ultra实调用均成功，追加6格12次；最终35格70次。它的真实后端版本及是否回退未核验。
gpt-6-luna的ultra实调用被接口明确拒绝，唯一未测格没有模拟数据。

文件说明：
prompt.txt                 所有测评实例读取的完全相同题包
controller_prompt.txt      所有实例收到的相同启动消息
run_plan.json              预先随机化的启动顺序、模型/强度/重复次数映射
availability.json          完整36格的可用状态
run_plan_extended.json     扩展后的70次请求映射
availability_extended.json 扩展后的36格状态
protocol_amendment.json    可用性探测原文、追加原因、时间和顺序变更记录
remaining_launch_schedule.json  扩展时重新随机化的剩余36次启动顺序
execution_events.json      一次无答案运行失败与全新上下文补跑记录，及原样文件改名的哈希
preregistration.json       启动前固定的评分规则和关键输入SHA-256
answer_key.json            11道非代码题的标准答案
code_cases.json            代码题的96个固定功能用例
raw/rNNN.json              逐实例原始答案、逐题置信度、三段中文表达原文
scripts/prepare.py         生成参考答案、固定用例和随机运行顺序的脚本
scripts/code_runner.py     受限执行代码答案的功能检查器
scripts/score.py           逐题评分与风格指标生成脚本
analysis/*.csv             每次运行、每道题、每段表达与每个配置的结构化结果
analysis/style_metrics_recovered.csv  对两处错位正文单独补充提取的风格指标，source_field保留来源
analysis/schema_flags.json  r018/r057字段错位说明，不改原始答卷或认知成绩
analysis/blind_*.json/csv   两位匿名机器审阅者的独立标签、原匿名映射、分歧和补充审阅
analysis/technical_audit.json  独立逐run代码审阅、评分复算、哈希与最终报告审计
analysis/code_test_details.json  每次代码题运行的逐用例结果
analysis/summary.json      结构化汇总
delivery/report.html      分析报告及完整结果表
delivery/report.txt       纯文本分析报告
delivery/all_raw.jsonl     合并原始数据（带请求元数据），原始字节文件仍在raw目录
delivery/all_raw.txt       可直接阅读的合并原始答卷
delivery/scores.png/svg    可分享或导出的成绩热图
delivery/style_length.png/svg  按协议指定字段计量的篇幅热图，报告另列正文恢复分析

复算：在提供Python3的环境中运行 python scripts/score.py，再运行 python scripts/aggregate.py。
脚本自动识别解压目录。重新出图/HTML还需matplotlib、numpy，运行scripts/report.py。
补充风格统计由scripts/style_recovery.py生成；盲评汇总由scripts/aggregate_reviews.py生成。
不要重新运行prepare.py覆盖已经冻结的实验输入。模型输出无法由脚本离线重新生成。
raw中的JSON为模型提交的最终答案原文；不包含不可见的内部推理过程、token用量或服务端轨迹。

控制条件：相同题包、顺序、语言、输出协议、工具限制和共同上级指令；fork_turns=none。
仅允许读取题包和写出最终答案。工具禁用通过提示词约束；没有逐调用轨迹来独立审计其执行。
模型名与强度是spawn_agent请求参数；不是底层部署版本或实际推理预算的独立证明。
温度、随机种子、输出token上限、服务端路由未暴露，不能声称这些变量已受控。
不同配置交错启动，同一轮内预先随机排序；最大同时运行6个测评实例。
相同题包的两次重复不等于24道独立试题；本实验不能估计总体智能或生产效率。
gpt-5.6-sol在前34个请求发起后追加，存在时段不均衡，不能忽略此设计偏差。
r058原始运行在写出任何答案前失败，原因未提供；r058_retry使用相同参数和全新上下文补跑。
成功提交的文件仅改名为r058.json，字节未修改。共71次正式尝试、70次成功答案；失败不作认知计分。

计分：Q01—Q10、Q12严格按JSON语义比对，每题1分；对象键顺序不影响，数组顺序影响。
Q11按96个固定用例通过比例计0—1分，不修改输入也是通过条件。
总分=sum(12题得分)/12*100；不把写作审美混入总分。
代码时间复杂度由静态审阅单列，功能通过不能证明O(n)。
Brier以“该题完整正确”为1，否则为0，衡量提交的置信度误差；越低越好。
高置信错误指置信度>=90而未完整答对。
文字长度按去除空白后的Unicode字符数统计，另列汉字数；标点也计入前者。
缓和措辞等指标是固定关键词匹配，不代表完整语义识别或表达质量评价。
两位风格审阅者请求配置为gpt-6-astra high和gpt-6.1-sol high，均fork_turns=none，
只读取匿名原文及相同分类协议；没有看到模型/强度/成绩映射。
这些事后探索性标签不构成人工审美评价，也不混入客观得分。
r018/r057的完整表达错误放入answers.S01—S03，指定style字段只有摘要/英文标签。
原字段计量与盲评保留；恢复正文结果、来源和补充盲评单列，不做静默替换。

标准答案独立核验：另一位子智能体独立程序复算Q01/Q02/Q03/Q04/Q05/Q06/Q10/Q12，
逻辑核对Q07/Q08/Q09，并用独立前缀和枚举算法复核96个代码用例期望值，均一致。
Q03独立计数：140个步序减72个经过(2,2)、减24个经过(1,3)，两禁点不能同时经过，得44。
Q10最优F,G费用9，次优A,C,E费用10，无最优并列。
已知题目局限：Q10没有实际测到并列择优；Q12仅输出id，无法检验是否选中最新记录，
也无法区分先筛选再去重和先去重再筛选。测试启动后未据此改变题包或评分。
